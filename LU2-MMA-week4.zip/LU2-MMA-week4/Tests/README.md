# Testsuite Medicine Management Application (week 4)

Geautomatiseerde acceptatietests voor de opgeleverde versie in `LU2-MMA-week4`.
De suite start de echte applicatie in het testproces (ASP.NET Core `WebApplicationFactory`) met een eigen, lege
SQL Server LocalDB-database per run en bedient haar via HTTP zoals een browser.

## Uitvoeren

```powershell
.\run-tests.ps1                       # alle testcases
.\run-tests.ps1 -Filter "Story=25"    # één story (nummering deel 1)
.\run-tests.ps1 -Filter "AC=AC-4.1"   # één acceptatiecriterium
.\run-tests.ps1 -Open                 # rapport na afloop openen
```

Of zonder script: `dotnet test MMA.Tests`. Vereist: .NET 9 runtime en SQL Server LocalDB (`(localdb)\mssqllocaldb`).

## Resultaten

Per run in `TestResults\<datum_tijd>\`:

| Bestand | Inhoud |
|---|---|
| `rapport.html` | resultaat per user story en acceptatiecriterium, testcases met stappen, bevindingen met historie |
| `testlog.txt` | per testcase elke stap, elk HTTP-verzoek en elke controle (verwacht / werkelijk) |
| `resultaten.json` | alle resultaten machineleesbaar |
| `testrun.trx` | standaarduitvoer van de testrunner (alleen via `run-tests.ps1`) |

`TestResults\historie.csv` krijgt één regel per run. Elke run legt de geteste versie vast (git-commit, lokale
wijzigingen, assemblyversie en een SHA-256-vingerafdruk van de gebouwde applicatie).

## Opbouw

| Map / bestand | Doel |
|---|---|
| `MMA.Tests\Testcases\` | testlogica, één klasse per user story; elke test heeft `[Testcase(ID, criterium, titel)]` |
| `MMA.Tests\Infrastructure\` | testomgeving: applicatie starten, sessies (`MmaClient`), logging, rapport |
| `MMA.Tests\TestData\` | testaccounts en medicijnen, acceptatiecriteria, bevindingenregister |
| `MMA.Tests\testsettings.json` | configuratie: database, versienaam |

Een criterium is *voldaan* als alle gekoppelde testcases slagen. Testcases met ID `EXT-…` vallen buiten de
acceptatiecriteria (beveiliging, verkenning); soort *Observatie* legt gedrag vast zonder te falen.

Na een fix: voeg in `TestData\bevindingen.json` een regel toe aan de `historie` van de bevinding; het rapport laat
per run zien of een bevinding nog wordt gereproduceerd.
