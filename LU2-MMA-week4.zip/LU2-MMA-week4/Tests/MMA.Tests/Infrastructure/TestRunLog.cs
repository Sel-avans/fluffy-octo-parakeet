using System.Text;

namespace MMA.Tests.Infrastructure;

public enum Uitkomst
{
    Geslaagd,
    Gefaald,
    Fout,
    Observatie
}

public sealed class StepRecord
{
    public DateTime Tijd { get; init; }
    public string Type { get; init; } = "";   // STAP, HTTP, CONTROLE, INFO, OBSERVATIE
    public string Tekst { get; init; } = "";
    public bool? Ok { get; init; }
}

public sealed class TestRecord
{
    public string Id { get; init; } = "";
    public string Criterium { get; init; } = "";
    public int Story { get; init; }
    public string Titel { get; init; } = "";
    public string Scenario { get; init; } = "";
    public Soort Soort { get; init; }
    public string Methode { get; init; } = "";
    public DateTime Start { get; init; }
    public TimeSpan Duur { get; set; }
    public Uitkomst Uitkomst { get; set; }
    public string Melding { get; set; } = "";
    public List<StepRecord> Stappen { get; } = new();
    public int Controles => Stappen.Count(s => s.Type == "CONTROLE");
    public int ControlesOk => Stappen.Count(s => s.Type == "CONTROLE" && s.Ok == true);
}

/// <summary>
/// Houdt alle testresultaten van één run bij en schrijft tegelijk een leesbare logging (testlog.txt)
/// met per testcase de stappen, HTTP-verzoeken, controles en uitkomst.
/// </summary>
public sealed class TestRunLog : IDisposable
{
    private readonly StreamWriter _writer;
    private readonly object _lock = new();

    public TestRunLog(string runId, string resultsDir)
    {
        RunId = runId;
        ResultsDir = resultsDir;
        Started = DateTime.Now;
        Directory.CreateDirectory(resultsDir);
        _writer = new StreamWriter(Path.Combine(resultsDir, "testlog.txt"), append: false, new UTF8Encoding(false)) { AutoFlush = true };
    }

    public string RunId { get; }
    public string ResultsDir { get; }
    public DateTime Started { get; }
    public DateTime Finished { get; private set; }
    public List<TestRecord> Records { get; } = new();

    public void Line(string text = "")
    {
        lock (_lock) _writer.WriteLine(text);
    }

    public void Header(SutVersion sut, string database)
    {
        Line(new string('=', 100));
        Line($"TESTRUN {RunId}  -  Medicine Management Application");
        Line(new string('=', 100));
        Line($"Gestart          : {Started:yyyy-MM-dd HH:mm:ss}");
        Line($"Geteste versie   : {sut.Label}");
        Line($"Git commit       : {sut.GitCommit} \"{sut.GitCommitMessage}\" ({sut.GitCommitDate}, branch {sut.GitBranch})");
        Line($"Lokale wijziging : {sut.LocalChanges} bestand(en) gewijzigd t.o.v. de commit");
        Line($"Assembly         : {sut.AssemblyName} {sut.AssemblyVersion}");
        Line($"Build            : vingerafdruk {sut.BuildFingerprint}, gebouwd {sut.BuildTime:yyyy-MM-dd HH:mm:ss}");
        Line($"Testdatabase     : {database}");
        Line($"Machine / .NET   : {Environment.MachineName} / {Environment.Version}");
        Line(new string('=', 100));
        Line();
    }

    public TestRecord Begin(TestcaseAttribute meta, string method)
    {
        var record = new TestRecord
        {
            Id = meta.Id,
            Criterium = meta.Criterium,
            Story = meta.StoryNumber,
            Titel = meta.Titel,
            Scenario = meta.Scenario,
            Soort = meta.Soort,
            Methode = method,
            Start = DateTime.Now
        };
        lock (_lock) Records.Add(record);
        Line(new string('-', 100));
        Line($"[{record.Start:HH:mm:ss}] {meta.Id}  ({meta.Criterium}, {meta.Soort})  {meta.Titel}");
        if (!string.IsNullOrEmpty(meta.Scenario)) Line($"           Scenario: {meta.Scenario}");
        return record;
    }

    public void Step(TestRecord record, string type, string text, bool? ok = null)
    {
        var step = new StepRecord { Tijd = DateTime.Now, Type = type, Tekst = text, Ok = ok };
        lock (_lock) record.Stappen.Add(step);
        var marker = ok switch { true => " [OK] ", false => " [NOK]", null => "      " };
        Line($"  {step.Tijd:HH:mm:ss.fff} {type,-10}{marker} {text}");
    }

    public void End(TestRecord record)
    {
        Line($"  => UITKOMST: {record.Uitkomst.ToString().ToUpperInvariant()} ({record.Duur.TotalMilliseconds:0} ms)"
             + (string.IsNullOrEmpty(record.Melding) ? "" : $"  -  {record.Melding}"));
        Line();
    }

    public void Finish()
    {
        Finished = DateTime.Now;
        var groups = Records.GroupBy(r => r.Uitkomst).ToDictionary(g => g.Key, g => g.Count());
        Line(new string('=', 100));
        Line($"EINDE TESTRUN {RunId} om {Finished:yyyy-MM-dd HH:mm:ss} (duur {(Finished - Started).TotalSeconds:0.0} s)");
        Line($"Totaal {Records.Count} testcases: " + string.Join(", ",
            Enum.GetValues<Uitkomst>().Select(u => $"{u.ToString().ToLowerInvariant()} {groups.GetValueOrDefault(u)}")));
        Line(new string('=', 100));
    }

    public void Dispose() => _writer.Dispose();
}
