using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using LU2_software_testen.Models;
using Xunit;

namespace MMA.Tests.Infrastructure;

/// <summary>Een controle die niet klopt: de testcase faalt (bevinding), in tegenstelling tot een technische fout.</summary>
public sealed class CheckFailedException(string message) : Exception(message);

/// <summary>
/// Wat een testcase tijdens het uitvoeren gebruikt: stappen loggen, controles doen, sessies openen.
/// </summary>
public sealed class TestCaseContext : IDisposable
{
    private readonly List<MmaClient> _sessions = new();

    public TestCaseContext(TestEnvironment env, TestRecord record)
    {
        Env = env;
        Record = record;
    }

    public TestEnvironment Env { get; }
    public TestRecord Record { get; }
    public TestDataFile Data => Env.Data;

    public void Step(string text) => Env.Log.Step(Record, "STAP", text);
    public void Info(string text) => Env.Log.Step(Record, "INFO", text);

    /// <summary>Legt verkennend vastgesteld gedrag vast zonder de test te laten falen.</summary>
    public void Observe(string text) => Env.Log.Step(Record, "OBSERVATIE", text);

    /// <summary>Controle: bij een afwijking faalt de testcase met verwacht en werkelijk resultaat.</summary>
    public void Check(bool ok, string what, string expected, string actual)
    {
        var text = $"{what} | verwacht: {expected} | werkelijk: {actual}";
        Env.Log.Step(Record, "CONTROLE", text, ok);
        if (!ok) throw new CheckFailedException($"{what}: verwacht {expected}, werkelijk {actual}");
    }

    public void CheckRedirectedAwayFrom(HtmlPage page, string forbiddenPath, string what)
    {
        var blocked = page.IsRedirect && page.Location != null &&
                      !page.Location.StartsWith(forbiddenPath, StringComparison.OrdinalIgnoreCase)
                      || page.StatusCode is 401 or 403 or 404;
        Check(blocked, what, "geen toegang (doorverwijzing naar inlog/geen toegang of 401/403)", page.Describe());
    }

    public MmaClient Session(string name)
    {
        var client = Env.NewSession(Record, name);
        _sessions.Add(client);
        return client;
    }

    /// <summary>Opent een sessie en logt in; controleert dat het inloggen lukt.</summary>
    public async Task<MmaClient> LoggedInAs(TestAccount account, string? name = null)
    {
        var session = Session(name ?? account.Username);
        Step($"Inloggen als {account.Username} ({account.Role})");
        var result = await session.LoginAsync(account);
        Check(result.IsRedirect && result.Location?.Contains("loginError") != true,
            $"Inloggen {account.Username} gelukt", "doorverwijzing zonder loginError", result.Describe());
        return session;
    }

    public Task<TestAccount> NewPatient(string prefix = "patient") => NewUser(prefix, UserRoleType.patient);

    public async Task<TestAccount> NewUser(string prefix, UserRoleType role)
    {
        var account = await Env.CreateUserAsync(prefix, role);
        Info($"Testgebruiker klaargezet: {account.Username} (id {account.Id}, rol {role})");
        return account;
    }

    public void Dispose()
    {
        foreach (var s in _sessions) s.Dispose();
    }
}

[Collection(MmaCollection.Name)]
public abstract class MmaTestBase
{
    protected MmaTestBase(TestEnvironment env) => Env = env;

    protected TestEnvironment Env { get; }

    /// <summary>
    /// Voert een testcase uit en registreert stappen, controles en uitkomst.
    /// De metadata (ID, criterium, titel) komt uit het [Testcase]-attribuut van de aanroepende methode.
    /// </summary>
    protected async Task Run(Func<TestCaseContext, Task> body, [CallerMemberName] string method = "")
    {
        var meta = GetType().GetMethod(method)?.GetCustomAttribute<TestcaseAttribute>()
                   ?? throw new InvalidOperationException($"{GetType().Name}.{method} mist een [Testcase]-attribuut");
        var record = Env.Log.Begin(meta, $"{GetType().Name}.{method}");
        var watch = Stopwatch.StartNew();
        using var t = new TestCaseContext(Env, record);
        try
        {
            await body(t);
            record.Uitkomst = meta.Soort == Soort.Observatie ? Uitkomst.Observatie : Uitkomst.Geslaagd;
        }
        catch (CheckFailedException ex)
        {
            record.Uitkomst = Uitkomst.Gefaald;
            record.Melding = ex.Message;
            throw;
        }
        catch (Exception ex)
        {
            record.Uitkomst = Uitkomst.Fout;
            record.Melding = $"{ex.GetType().Name}: {ex.Message}";
            Env.Log.Step(record, "FOUT", ex.ToString().Split(Environment.NewLine).First());
            throw;
        }
        finally
        {
            record.Duur = watch.Elapsed;
            Env.Log.End(record);
        }
    }
}
