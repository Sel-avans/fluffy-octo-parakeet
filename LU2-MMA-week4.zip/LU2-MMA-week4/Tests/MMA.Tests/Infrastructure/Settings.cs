using System.Text.Json;
using System.Text.Json.Serialization;

namespace MMA.Tests.Infrastructure;

/// <summary>Configuratie van de testomgeving (testsettings.json).</summary>
public sealed class TestSettings
{
    public SutSettings Sut { get; set; } = new();
    public DatabaseSettings Database { get; set; } = new();
    public ResultSettings Results { get; set; } = new();

    public sealed class SutSettings
    {
        public string ProjectFile { get; set; } = "";
        public string VersionLabel { get; set; } = "";
        public string Environment { get; set; } = "Development";
    }

    public sealed class DatabaseSettings
    {
        public string ConnectionStringTemplate { get; set; } = "";
        public string NamePrefix { get; set; } = "MMA_Test";
        public bool KeepAfterRun { get; set; }
    }

    public sealed class ResultSettings
    {
        public string FolderName { get; set; } = "TestResults";
    }
}

/// <summary>Testdata (TestData/testdata.json).</summary>
public sealed class TestDataFile
{
    public Dictionary<string, AccountData> Accounts { get; set; } = new();
    public NewUserTemplate NieuweGebruiker { get; set; } = new();
    public Dictionary<string, string> Medicijnen { get; set; } = new();

    public sealed class AccountData
    {
        public string Username { get; set; } = "";
        public string Password { get; set; } = "";
        public string Email { get; set; } = "";
        public string Phone { get; set; } = "";
        public string Role { get; set; } = "";
        public bool SeededBySut { get; set; }
    }

    public sealed class NewUserTemplate
    {
        public string Password { get; set; } = "";
        public string Phone { get; set; } = "";
        public string EmailDomain { get; set; } = "";
    }

    public string Medicijn(string key) =>
        Medicijnen.TryGetValue(key, out var name) ? name : throw new KeyNotFoundException($"Medicijn '{key}' staat niet in testdata.json");
}

/// <summary>Acceptatiecriteria per user story (TestData/acceptatiecriteria.json).</summary>
public sealed class AcceptanceCatalog
{
    public List<Story> Stories { get; set; } = new();

    public sealed class Story
    {
        public int Deel1 { get; set; }
        public int Opdracht { get; set; }
        public string Titel { get; set; } = "";
        public string Rol { get; set; } = "";
        public string Tekst { get; set; } = "";
        public List<Criterion> Criteria { get; set; } = new();
    }

    public sealed class Criterion
    {
        public string Id { get; set; } = "";
        public string Tekst { get; set; } = "";
    }
}

/// <summary>Geregistreerde bevindingen (TestData/bevindingen.json).</summary>
public sealed class DefectRegister
{
    public List<Defect> Bevindingen { get; set; } = new();

    public sealed class Defect
    {
        public string Id { get; set; } = "";
        public string Titel { get; set; } = "";
        public string Story { get; set; } = "";
        public string Beschrijving { get; set; } = "";
        public string Reproductie { get; set; } = "";
        public string Verwacht { get; set; } = "";
        public string Werkelijk { get; set; } = "";
        public string Ernst { get; set; } = "";
        public string Prioriteit { get; set; } = "";
        public List<StakeholderImpact> Stakeholders { get; set; } = new();
        public List<string> Testcases { get; set; } = new();
        public string Status { get; set; } = "";
        public List<HistoryEntry> Historie { get; set; } = new();
    }

    public sealed class StakeholderImpact
    {
        public string Stakeholder { get; set; } = "";
        public string Belang { get; set; } = "";
    }

    public sealed class HistoryEntry
    {
        public string Datum { get; set; } = "";
        public string Status { get; set; } = "";
        public string Opmerking { get; set; } = "";
    }
}

public static class JsonFiles
{
    public static readonly JsonSerializerOptions Options = new()
    {
        PropertyNameCaseInsensitive = true,
        ReadCommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = true,
        WriteIndented = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
        Converters = { new JsonStringEnumConverter() }
    };

    public static T Load<T>(string relativePath)
    {
        var path = Path.Combine(AppContext.BaseDirectory, relativePath);
        if (!File.Exists(path))
            throw new FileNotFoundException($"Bestand voor de testomgeving ontbreekt: {path}");
        return JsonSerializer.Deserialize<T>(File.ReadAllText(path), Options)
               ?? throw new InvalidDataException($"Bestand is leeg of ongeldig: {path}");
    }
}

public static class Paths
{
    /// <summary>Map van het testproject (MMA.Tests), gevonden vanaf de outputmap.</summary>
    public static string TestProjectDir => FindUp(AppContext.BaseDirectory, d => File.Exists(Path.Combine(d, "MMA.Tests.csproj")))
        ?? throw new DirectoryNotFoundException("MMA.Tests.csproj niet gevonden boven " + AppContext.BaseDirectory);

    /// <summary>Map Tests\ (bevat testproject, run-script en testresultaten).</summary>
    public static string TestsRoot => Directory.GetParent(TestProjectDir)!.FullName;

    public static string SutDir(string projectFile) => FindUp(TestsRoot, d => File.Exists(Path.Combine(d, projectFile)))
        ?? throw new DirectoryNotFoundException($"{projectFile} niet gevonden boven {TestsRoot}");

    private static string? FindUp(string start, Func<string, bool> match)
    {
        var dir = new DirectoryInfo(start);
        while (dir != null)
        {
            if (match(dir.FullName)) return dir.FullName;
            dir = dir.Parent;
        }
        return null;
    }
}
