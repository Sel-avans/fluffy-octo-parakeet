using MMA.Tests.Infrastructure;
using Xunit;

namespace MMA.Tests.Testcases;

/// <summary>Opdracht nr. 5 / deel 1 nr. 5: Als patiënt wil ik mijn voorgeschreven medicatie kunnen inzien.</summary>
public sealed class US05_MedicatieInzien(TestEnvironment env) : MmaTestBase(env)
{
    [Fact, Testcase("TC-5.1-01", "AC-5.1", "Patiënt ziet actuele medicatie met naam, sterkte, instructies en periode",
        Scenario = "TS-5.1 Actuele medicatie bekijken (hoofdflow)")]
    public Task TC_5_1_01() => Run(async t =>
    {
        var patient = await t.NewPatient("inzien");
        var trade = t.Data.Medicijn("antibioticum");
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today.AddDays(-2), DateTime.Today.AddDays(5),
            (trade, 21, "1 capsule 3x per dag om 08:00, 14:00, 20:00"));

        var s = await t.LoggedInAs(patient);
        var overview = await s.GetMyPrescriptionsAsync();
        t.Info("Kolommen: " + string.Join(", ", overview.Headers));
        foreach (var h in new[] { "Medicine", "Strength", "Instructions", "Start Date", "End Date" })
            t.Check(overview.Headers.Contains(h), $"Kolom '{h}'", "aanwezig", overview.Headers.Contains(h) ? "aanwezig" : "ontbreekt");
        var row = overview.Find(trade);
        t.Check(row != null, "Medicijn in overzicht", trade, row?.Medicine ?? "niet gevonden");
        t.Check(row!.Strength == "500mg", "Sterkte", "500mg", row.Strength);
        t.Check(row.Instructions == "1 capsule 3x per dag om 08:00, 14:00, 20:00", "Dosering en innametijden", "1 capsule 3x per dag om 08:00, 14:00, 20:00", row.Instructions);
    });

    [Fact, Testcase("TC-5.1-02", "AC-5.1", "Patiënt zonder voorschriften krijgt een duidelijke melding",
        Soort = Soort.Alternatief, Scenario = "TS-5.2 Geen medicatie")]
    public Task TC_5_1_02() => Run(async t =>
    {
        var patient = await t.NewPatient("leeg");
        var s = await t.LoggedInAs(patient);
        var overview = await s.GetMyPrescriptionsAsync();
        t.Check(overview.Rows.Count == 0 && overview.ShowsNoPrescriptionsMessage, "Lege lijst met melding",
            "'You have no current prescriptions.'", overview.ShowsNoPrescriptionsMessage ? "melding getoond" : $"{overview.Rows.Count} regels, geen melding");
    });

    [Fact, Testcase("TC-5.1-03", "AC-5.1", "Alleen actuele medicatie: verlopen voorschrift niet zichtbaar, voorschrift dat vandaag eindigt wel",
        Soort = Soort.Alternatief, Scenario = "TS-5.3 Grenzen van 'actueel'")]
    public Task TC_5_1_03() => Run(async t =>
    {
        var patient = await t.NewPatient("actueel");
        var expired = t.Data.Medicijn("ontstekingsremmer");
        var endsToday = t.Data.Medicijn("maagbeschermer");
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today.AddDays(-10), DateTime.Today.AddDays(-1), (expired, 10, "verlopen"));
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today.AddDays(-10), DateTime.Today, (endsToday, 10, "eindigt vandaag"));

        var s = await t.LoggedInAs(patient);
        var overview = await s.GetMyPrescriptionsAsync();
        t.Check(!overview.HasMedicine(expired), "Verlopen voorschrift (einddatum gisteren)", "niet zichtbaar", overview.HasMedicine(expired) ? "zichtbaar" : "niet zichtbaar");
        t.Check(overview.HasMedicine(endsToday), "Voorschrift met einddatum vandaag", "zichtbaar", overview.HasMedicine(endsToday) ? "zichtbaar" : "niet zichtbaar");
    });

    [Fact, Testcase("TC-5.1-04", "AC-5.1", "Medicatieoverzicht is alleen-lezen: de patiënt kan niets wijzigen",
        Soort = Soort.Negatief, Scenario = "TS-5.4 Patiënt probeert medicatie aan te passen")]
    public Task TC_5_1_04() => Run(async t =>
    {
        var patient = await t.NewPatient("alleen_lezen");
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today, DateTime.Today.AddDays(3), (t.Data.Medicijn("pijnstiller"), 6, "2x per dag"));
        var s = await t.LoggedInAs(patient);
        var overview = await s.GetMyPrescriptionsAsync();
        var editable = overview.Page.QA("main input:not([type=hidden]), main textarea, main select, main form").Count();
        t.Check(editable == 0, "Invoervelden of formulieren in het overzicht", "geen", editable.ToString());
        var post = await s.PostRawAsync("/Prescriptions/MyPrescriptions", new Dictionary<string, string> { ["Instructions"] = "aangepast" }, overview.Page.AntiforgeryToken);
        t.Check(post.StatusCode is 400 or 404 or 405 || post.IsRedirect || !post.Contains("aangepast"), "Wijziging via POST", "niet mogelijk", post.Describe());
    });

    [Fact, Testcase("TC-5.2-01", "AC-5.2", "Voorschrift dat de arts via het scherm vastlegt, verschijnt bij de patiënt (end-to-end)",
        Scenario = "TS-5.5 Nieuw voorschrift verschijnt bij patiënt (end-to-end)")]
    public Task TC_5_2_01() => Run(async t =>
    {
        var patient = await t.NewPatient("e2e");
        var trade = t.Data.Medicijn("ontstekingsremmer");

        var before = await (await t.LoggedInAs(patient, "patient-voor")).GetMyPrescriptionsAsync();
        t.Check(!before.HasMedicine(trade), "Voor het voorschrift", $"{trade} niet zichtbaar", before.HasMedicine(trade) ? "zichtbaar" : "niet zichtbaar");

        var doctor = await t.LoggedInAs(Env.Huisarts);
        t.Step("Arts legt voorschrift vast");
        await doctor.PrescribeAsync(new PrescriptionInput { PatientId = patient.Id.ToString() },
            new MedicineLine(await Env.MedicineIdAsync(trade), 20, "1 tablet 2x per dag om 08:00 en 20:00"));

        var after = await (await t.LoggedInAs(patient, "patient-na")).GetMyPrescriptionsAsync();
        t.Check(after.HasMedicine(trade), "Na het voorschrift", $"{trade} zichtbaar", after.HasMedicine(trade) ? "zichtbaar" : "niet zichtbaar");
    });

    [Fact, Testcase("TC-5.2-02", "AC-5.2", "Alle medicijnen van een voorschrift met meerdere medicijnen zijn zichtbaar",
        Soort = Soort.Alternatief, Scenario = "TS-5.6 Voorschrift met meerdere medicijnen")]
    public Task TC_5_2_02() => Run(async t =>
    {
        var patient = await t.NewPatient("e2e_meer");
        var a = t.Data.Medicijn("ontstekingsremmer");
        var b = t.Data.Medicijn("maagbeschermer");
        var doctor = await t.LoggedInAs(Env.Specialist);
        await doctor.PrescribeAsync(new PrescriptionInput { PatientId = patient.Id.ToString() },
            new MedicineLine(await Env.MedicineIdAsync(a), 30, "1 tablet 3x per dag"),
            new MedicineLine(await Env.MedicineIdAsync(b), 30, "1 capsule voor het ontbijt"));

        var overview = await (await t.LoggedInAs(patient)).GetMyPrescriptionsAsync();
        t.Check(overview.HasMedicine(a) && overview.HasMedicine(b), "Beide medicijnen zichtbaar", $"{a} en {b}", string.Join(", ", overview.Rows.Select(r => r.Medicine)));
    });

    [Fact, Testcase("TC-5.2-03", "AC-5.2", "Voorschrift voor een andere patiënt verschijnt niet in mijn overzicht",
        Soort = Soort.Negatief, Scenario = "TS-5.7 Voorschrift van een ander")]
    public Task TC_5_2_03() => Run(async t =>
    {
        var me = await t.NewPatient("ik");
        var other = await t.NewPatient("ander");
        var trade = t.Data.Medicijn("antibioticum");
        var doctor = await t.LoggedInAs(Env.Huisarts);
        await doctor.PrescribeAsync(new PrescriptionInput { PatientId = other.Id.ToString() },
            new MedicineLine(await Env.MedicineIdAsync(trade), 21, "3x per dag"));

        var overview = await (await t.LoggedInAs(me)).GetMyPrescriptionsAsync();
        t.Check(!overview.HasMedicine(trade), "Voorschrift andere patiënt", "niet zichtbaar", overview.HasMedicine(trade) ? "zichtbaar" : "niet zichtbaar");
    });

    [Fact, Testcase("EXT-5-01", ReportWriter.Extra, "Voorschrift met een startdatum in de toekomst is nog niet zichtbaar voor de patiënt",
        Story = 5, Soort = Soort.Observatie, Scenario = "Verkennend: interpretatie van 'actuele medicatie'")]
    public Task EXT_5_01() => Run(async t =>
    {
        var patient = await t.NewPatient("toekomst");
        var trade = t.Data.Medicijn("pijnstiller");
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today.AddDays(1), DateTime.Today.AddDays(8), (trade, 10, "start morgen"));
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today, DateTime.Today.AddDays(8), (t.Data.Medicijn("maagbeschermer"), 8, "loopt al"));
        var overview = await (await t.LoggedInAs(patient)).GetMyPrescriptionsAsync();
        t.Observe(overview.HasMedicine(trade)
            ? "Een voorschrift dat morgen ingaat is al zichtbaar."
            : "Een voorschrift dat morgen ingaat is nog niet zichtbaar; de patiënt ziet het pas op de startdatum.");
        t.Observe($"Kolommen in het overzicht: {string.Join(", ", overview.Headers)}. De voorgeschreven hoeveelheid (Quantity) wordt niet getoond.");
    });
}
