using Microsoft.EntityFrameworkCore;
using LU2_software_testen.Models;
using LU2_software_testen.Data;

namespace LU2_software_testen
{
    // This class can be used to manually seed the database
    // Run from Package Manager Console: 
    // var context = new AppDbContext(new DbContextOptionsBuilder<AppDbContext>().UseSqlServer("your-connection-string").Options);
    // LU2_software_testen.Data.DbInitializer.Seed(context);
    public class DatabaseSeeder
    {
        public static void SeedFromConsole()
        {
            var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
            optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=LU2SoftwareTesten;Trusted_Connection=True;MultipleActiveResultSets=true");

            using var context = new AppDbContext(optionsBuilder.Options);
            DbInitializer.Seed(context);
            Console.WriteLine("Database seeded successfully!");
        }
    }
}
