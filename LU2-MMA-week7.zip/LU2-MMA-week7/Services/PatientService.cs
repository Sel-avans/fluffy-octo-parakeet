using LU2_software_testen.Models;
using Microsoft.EntityFrameworkCore;

namespace LU2_software_testen.Services
{
    public class PatientService : IPatientService
    {
        private readonly AppDbContext _context;

        public PatientService(AppDbContext context)
        {
            _context = context;
        }

        public List<User> GetPatients(string? searchName = null)
        {
            var patientsQuery = _context.Users
                .Include(u => u.UserRoleNavigation)
                .Where(u => u.UserRoleID == (int)UserRoleType.patient);

            if (!string.IsNullOrWhiteSpace(searchName))
            {
                var searchLower = searchName.ToLower().Trim();
                patientsQuery = patientsQuery.Where(u => 
                    u.Username.ToLower().Contains(searchLower) ||
                    u.Email.ToLower().Contains(searchLower));
            }

            return patientsQuery
                .OrderBy(u => u.Username)
                .ToList();
        }

        public User? GetPatientById(int patientId)
        {
            return _context.Users
                .Include(u => u.UserRoleNavigation)
                .FirstOrDefault(u => u.UserID == patientId && u.UserRoleID == (int)UserRoleType.patient);
        }

        public List<Prescription> GetActivePrescriptionsForPatient(int patientId)
        {
            var today = DateTime.Today;

            return _context.Prescriptions
                .Where(p => p.PatientID == patientId
                    && p.PrescriptionStartDate <= today
                    && p.PrescriptionEndDate >= today)
                .OrderByDescending(p => p.PrescriptionDate)
                .ToList();
        }

        public List<PrescriptionMedicineDetail> GetPrescriptionMedicines(int prescriptionId)
        {
            return (from pm in _context.PrescriptionMedicines
                    join m in _context.Medicines on pm.MedicineID equals m.MedicineID
                    where pm.PrescriptionID == prescriptionId && !m.IsDeleted
                    select new PrescriptionMedicineDetail
                    {
                        MedicineID = m.MedicineID,
                        TradeName = m.TradeName,
                        Strength = m.Strength,
                        Quantity = pm.Quantity,
                        Instructions = pm.Instructions
                    })
                    .OrderBy(pm => pm.TradeName)
                    .ToList();
        }

        public bool PrescriptionHasSoftDeletedMedicine(int prescriptionId)
        {
            // Check if there exist prescription_medicines entries for this prescription
            // that reference a medicine where IsDeleted == true
            return (from pm in _context.PrescriptionMedicines
                    join m in _context.Medicines on pm.MedicineID equals m.MedicineID
                    where pm.PrescriptionID == prescriptionId && m.IsDeleted
                    select pm).Any();
        }
    }
}
