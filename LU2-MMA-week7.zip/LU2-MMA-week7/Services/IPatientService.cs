using LU2_software_testen.Models;

namespace LU2_software_testen.Services
{
    public interface IPatientService
    {
        /// <summary>
        /// Gets all patients, optionally filtered by name (searches both first and last name)
        /// </summary>
        /// <param name="searchName">Optional search term for first name or last name</param>
        /// <returns>List of users with patient role</returns>
        List<User> GetPatients(string? searchName = null);

        /// <summary>
        /// Gets a specific patient by ID
        /// </summary>
        /// <param name="patientId">The patient's user ID</param>
        /// <returns>The patient user or null if not found</returns>
        User? GetPatientById(int patientId);

        /// <summary>
        /// Gets all active prescriptions for a specific patient
        /// </summary>
        /// <param name="patientId">The patient's user ID</param>
        /// <returns>List of active prescriptions</returns>
        List<Prescription> GetActivePrescriptionsForPatient(int patientId);

        /// <summary>
        /// Gets medicines associated with a specific prescription
        /// </summary>
        /// <param name="prescriptionId">The prescription ID</param>
        /// <returns>List of prescription medicine details</returns>
        List<PrescriptionMedicineDetail> GetPrescriptionMedicines(int prescriptionId);

        /// <summary>
        /// Returns true when a prescription references any medicine that is soft-deleted
        /// </summary>
        /// <param name="prescriptionId">The prescription ID</param>
        /// <returns>True if any linked medicine is soft-deleted</returns>
        bool PrescriptionHasSoftDeletedMedicine(int prescriptionId);
    }

    /// <summary>
    /// DTO for prescription medicine details
    /// </summary>
    public class PrescriptionMedicineDetail
    {
        public int MedicineID { get; set; }
        public string TradeName { get; set; } = string.Empty;
        public string Strength { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public string Instructions { get; set; } = string.Empty;
    }
}
