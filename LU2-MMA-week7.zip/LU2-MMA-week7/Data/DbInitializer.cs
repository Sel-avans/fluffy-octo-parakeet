﻿using LU2_software_testen.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LU2_software_testen.Data
{
    public static class DbInitializer
    {
        public static void Seed(DbContext context)
        {
            Console.WriteLine("DbInitializer.Seed() called");

            // Ensure database is created and migrations are applied
            Console.WriteLine("Applying migrations...");
            context.Database.Migrate();
            Console.WriteLine("Migrations applied");

            // Detach all tracked entities to avoid conflicts
            context.ChangeTracker.Clear();

            // 1. Seed DosageForms
            Console.WriteLine("Checking DosageForms...");
            if (!context.Set<DosageForm>().Any())
            {
                Console.WriteLine("Seeding DosageForms...");
                context.Database.ExecuteSqlRaw(@"
                    SET IDENTITY_INSERT DosageForms ON;
                    INSERT INTO DosageForms (DosageFormID, Name) VALUES (1, 'Tablet');
                    INSERT INTO DosageForms (DosageFormID, Name) VALUES (2, 'Capsule');
                    INSERT INTO DosageForms (DosageFormID, Name) VALUES (3, 'Injectie');
                    INSERT INTO DosageForms (DosageFormID, Name) VALUES (4, 'Zalf');
                    SET IDENTITY_INSERT DosageForms OFF;
                ");
                context.ChangeTracker.Clear();
                Console.WriteLine("✓ Seeded 4 DosageForms");
            }
            else
            {
                Console.WriteLine("DosageForms already exist, skipping");
            }

            // 2. Seed StockStatus
            Console.WriteLine("Checking StockStatus...");
            try
            {
                if (!context.Set<StockStatus>().Any())
                {
                    Console.WriteLine("Seeding StockStatus...");
                    // Try both possible table names
                    try
                    {
                        context.Database.ExecuteSqlRaw(@"
                            SET IDENTITY_INSERT StockStatus ON;
                            INSERT INTO StockStatus (StockStatusID, Name) VALUES (1, 'Op voorraad');
                            INSERT INTO StockStatus (StockStatusID, Name) VALUES (2, 'Gelimiteerd');
                            INSERT INTO StockStatus (StockStatusID, Name) VALUES (3, 'Niet beschikbaar');
                            SET IDENTITY_INSERT StockStatus OFF;
                        ");
                    }
                    catch (Exception ex1)
                    {
                        Console.WriteLine($"StockStatus table failed, trying StockStatuses: {ex1.Message}");
                        context.Database.ExecuteSqlRaw(@"
                            SET IDENTITY_INSERT StockStatuses ON;
                            INSERT INTO StockStatuses (StockStatusID, Name) VALUES (1, 'Op voorraad');
                            INSERT INTO StockStatuses (StockStatusID, Name) VALUES (2, 'Gelimiteerd');
                            INSERT INTO StockStatuses (StockStatusID, Name) VALUES (3, 'Niet beschikbaar');
                            SET IDENTITY_INSERT StockStatuses OFF;
                        ");
                    }
                    context.ChangeTracker.Clear();
                    Console.WriteLine("✓ Seeded 3 StockStatus records");
                }
                else
                {
                    Console.WriteLine("StockStatus already exist, skipping");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"✗ ERROR seeding StockStatus: {ex.Message}");
                throw;
            }

            // 3. Seed UserRoles
            Console.WriteLine("Checking UserRoles...");
            try
            {
                var userRoleCount = context.Set<UserRole>().Count();
                Console.WriteLine($"Current UserRole count: {userRoleCount}");

                if (userRoleCount == 0)
                {
                    Console.WriteLine("Seeding UserRoles...");
                    context.Database.ExecuteSqlRaw(@"
                        SET IDENTITY_INSERT UserRoles ON;
                        INSERT INTO UserRoles (UserRoleID, RoleName) VALUES (1, 'apothecary');
                        INSERT INTO UserRoles (UserRoleID, RoleName) VALUES (2, 'administrator');
                        INSERT INTO UserRoles (UserRoleID, RoleName) VALUES (3, 'healthInsurer');
                        INSERT INTO UserRoles (UserRoleID, RoleName) VALUES (4, 'patient');
                        INSERT INTO UserRoles (UserRoleID, RoleName) VALUES (5, 'generalPractitioner');
                        INSERT INTO UserRoles (UserRoleID, RoleName) VALUES (6, 'specialist');
                        SET IDENTITY_INSERT UserRoles OFF;
                    ");
                    context.ChangeTracker.Clear();
                    Console.WriteLine("✓ Seeded 6 UserRoles");
                }
                else if (userRoleCount < 6)
                {
                    Console.WriteLine($"⚠ WARNING: Only {userRoleCount} UserRoles found, expected 6. Database may be corrupted.");
                }
                else
                {
                    Console.WriteLine($"UserRoles already exist ({userRoleCount} records), skipping");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"✗ ERROR seeding UserRoles: {ex.Message}");
                Console.WriteLine($"Inner Exception: {ex.InnerException?.Message}");
                throw;
            }

            // 4. Seed Users
            Console.WriteLine("Checking Users...");
            if (!context.Set<User>().Any())
            {
                Console.WriteLine("Seeding Users...");
                context.Database.ExecuteSqlRaw(@"
                    SET IDENTITY_INSERT Users ON;
                    INSERT INTO Users (UserID, Username, PasswordHash, Email, CreatedAt, UserRoleID, PhoneNumber) 
                    VALUES (6, 'admin', 'JfQ7FIatlaE5jj7rPYO8QBABX8yb7bNbQy4AKY1QIfc=', 'admin@admin.com', '2025-09-23 18:04:41', 2, '0612345678');
                    SET IDENTITY_INSERT Users OFF;
                ");
                context.ChangeTracker.Clear();
                Console.WriteLine("✓ Seeded admin user");
            }
            else
            {
                Console.WriteLine("Users already exist, skipping");
            }

            // 5. Seed Medicines
            Console.WriteLine("Checking Medicines...");
            if (!context.Set<Medicine>().Any())
            {
                Console.WriteLine("Seeding Medicines...");
                // ActiveSubstances is stored as semicolon-separated string in database
                context.Database.ExecuteSqlRaw(@"
                    SET IDENTITY_INSERT Medicines ON;
                    INSERT INTO Medicines (MedicineID, TradeName, ActiveSubstances, DosageForm, StockStatus, Strength) VALUES
                    (1, 'Panadol', 'Paracetamol', 1, 1, '500mg'),
                    (2, 'Ibuprofen', 'Ibuprofen', 1, 1, '200mg'),
                    (3, 'Amoxicillin', 'Amoxicillin', 2, 1, '500mg'),
                    (4, 'Ciprofloxacin', 'Ciprofloxacin', 1, 1, '250mg'),
                    (5, 'Lisinopril', 'Lisinopril', 1, 1, '10mg'),
                    (6, 'Metformin', 'Metformin Hydrochloride', 1, 1, '850mg'),
                    (7, 'Omeprazole', 'Omeprazole', 2, 1, '20mg'),
                    (8, 'Simvastatin', 'Simvastatin', 1, 1, '40mg'),
                    (9, 'Prednisone', 'Prednisone', 1, 1, '5mg'),
                    (10, 'Levothyroxine', 'Levothyroxine Sodium', 1, 1, '100mcg'),
                    (11, 'Ventolin', 'Salbutamol', 3, 1, '100mcg/dose'),
                    (12, 'Crestor', 'Rosuvastatin', 1, 1, '10mg'),
                    (13, 'Zithromax', 'Azithromycin', 2, 1, '250mg'),
                    (14, 'Norvasc', 'Amlodipine', 1, 1, '5mg'),
                    (15, 'Voltaren', 'Diclofenac', 4, 1, '1%'),
                    (16, 'Benadryl', 'Diphenhydramine', 2, 1, '25mg'),
                    (17, 'Xanax', 'Alprazolam', 1, 1, '0.5mg'),
                    (18, 'Synthroid', 'Levothyroxine', 1, 1, '50mg'),
                    (19, 'Cozaar', 'Losartan Potassium', 3, 1, '50mg'),
                    (20, 'Zoloft', 'Sertraline', 2, 1, '50mg');
                    SET IDENTITY_INSERT Medicines OFF;
                ");
                context.ChangeTracker.Clear();
                Console.WriteLine("✓ Seeded 20 Medicines");
            }
            else
            {
                Console.WriteLine("Medicines already exist, skipping");
            }

            Console.WriteLine("=== SEEDING COMPLETED SUCCESSFULLY ===");
        }
    }
}