﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LU2_software_testen.Migrations
{
    /// <inheritdoc />
    public partial class AddIsDeletedToMedicine : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsDeleted",
                table: "Medicines",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsDeleted",
                table: "Medicines");
        }
    }
}
