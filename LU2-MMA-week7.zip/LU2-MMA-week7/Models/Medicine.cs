using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LU2_software_testen.Models
{
    [Table("Medicines")]
    public class Medicine
    {
        [Key]
        public int MedicineID { get; set; }

        [Required]
        public string TradeName { get; set; } = string.Empty;

        [Required]
        public List<string> ActiveSubstances { get; set; } = new List<string>();

        // Foreign key properties
        public int? StockStatus { get; set; }

        public int? DosageForm { get; set; }

        [Required]
        public string Strength { get; set; } = string.Empty;

        // Soft delete flag
        public bool IsDeleted { get; set; } = false;

        // Navigation properties (optional but recommended)
        [ForeignKey("StockStatus")]
        public StockStatus? StockStatusNavigation { get; set; }

        [ForeignKey("DosageForm")]
        public DosageForm? DosageFormNavigation { get; set; }
    }
}
