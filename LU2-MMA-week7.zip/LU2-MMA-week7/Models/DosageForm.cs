using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LU2_software_testen.Models
{
    [Table("DosageForms")]
    public class DosageForm
    {
        [Key]
        public int DosageFormID { get; set; }

        [Required, MaxLength(50)]
        public string Name { get; set; } = string.Empty;
    }

    // Keep enum for easy reference in code
    public enum DosageFormType
    {
        Tablet = 1,
        Capsule = 2,
        Injection = 3,
        Salve = 4
    }
}