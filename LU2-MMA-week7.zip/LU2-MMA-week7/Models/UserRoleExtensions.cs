using System.Security.Claims;

namespace LU2_software_testen.Models
{
    public static class ClaimsPrincipalExtensions
    {
        public static bool IsInUserRole(this ClaimsPrincipal user, UserRoleType role)
        {
            // Get the role name from the standard Role claim
            var roleClaim = user.FindFirst(ClaimTypes.Role)?.Value;

            if (string.IsNullOrEmpty(roleClaim))
            {
                return false;
            }

            // Compare the role name from the claim with the enum value's name
            return roleClaim.Equals(role.ToString(), StringComparison.OrdinalIgnoreCase);
        }
    }
}