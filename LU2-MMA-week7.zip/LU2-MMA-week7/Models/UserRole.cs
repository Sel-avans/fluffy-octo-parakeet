using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LU2_software_testen.Models
{
    [Table("UserRoles")]
    public class UserRole
    {
        [Key]
        public int UserRoleID { get; set; }

        [MaxLength(45)]
        public string? RoleName { get; set; }
    }

    // Keep enum for easy reference in code
    public enum UserRoleType
    {
        apothecary = 1,
        administrator = 2,
        healthInsurer = 3,
        patient = 4,
        generalPractitioner = 5,
        specialist = 6
    }

    public static class UserRoleExtensions
    {
        public static string ToDisplayString(this UserRoleType role)
        {
            return role switch
            {
                UserRoleType.apothecary => "Apotheek",
                UserRoleType.administrator => "Administrator",
                UserRoleType.healthInsurer => "Verzekeraar",
                UserRoleType.patient => "Patient",
                UserRoleType.generalPractitioner => "Huisarts",
                UserRoleType.specialist => "Specialist",
                _ => "Unknown"
            };
        }
    }
}