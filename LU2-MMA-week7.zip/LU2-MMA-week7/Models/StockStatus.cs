using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LU2_software_testen.Models
{
    [Table("StockStatus")]
    public class StockStatus
    {
        [Key]
        public int StockStatusID { get; set; }

        [Required, MaxLength(50)]
        public string Name { get; set; } = string.Empty;
    }

    // Keep enum for easy reference in code
    public enum StockStatusType
    {
        Available = 1,
        Limited = 2,
        Unavailable = 3
    }
}