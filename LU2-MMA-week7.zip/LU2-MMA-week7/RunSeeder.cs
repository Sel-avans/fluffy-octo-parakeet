using Microsoft.EntityFrameworkCore;
using LU2_software_testen.Models;
using LU2_software_testen.Data;

namespace LU2_software_testen
{
    /// <summary>
    /// Standalone utility to seed the database.
    /// Uncomment the Main method below and change Program.cs temporary to run this.
    /// </summary>
    public class RunSeeder
    {
        // Uncomment this to use as entry point
        /*
        public static void Main(string[] args)
        {
            Console.WriteLine("Starting database seeding...");

            var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
            optionsBuilder.UseSqlServer(
                "Server=(localdb)\\mssqllocaldb;Database=LU2SoftwareTesten;Trusted_Connection=True;MultipleActiveResultSets=true"
            );

            using var context = new AppDbContext(optionsBuilder.Options);

            try
            {
                DbInitializer.Seed(context);
                Console.WriteLine("✓ Database seeded successfully!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"✗ Error seeding database: {ex.Message}");
                Console.WriteLine($"Stack trace: {ex.StackTrace}");
                if (ex.InnerException != null)
                {
                    Console.WriteLine($"Inner exception: {ex.InnerException.Message}");
                }
            }

            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
        */
    }
}
