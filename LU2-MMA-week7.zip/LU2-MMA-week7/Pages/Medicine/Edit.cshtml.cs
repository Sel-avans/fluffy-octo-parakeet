using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using LU2_software_testen.Models;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Pages.Medicine
{
    [Authorize(Roles = "apothecary")]
    public class EditModel : PageModel
    {
        private readonly AppDbContext _context;

        public EditModel(AppDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public LU2_software_testen.Models.Medicine Medicine { get; set; } = new LU2_software_testen.Models.Medicine();

        [BindProperty]
        public string ActiveSubstancesInput { get; set; } = string.Empty;

        public List<SelectListItem> StockStatusOptions { get; set; } = new List<SelectListItem>();
        public List<SelectListItem> DosageFormOptions { get; set; } = new List<SelectListItem>();

        // Store original values for change detection
        public string OriginalValuesJson { get; set; } = string.Empty;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            Medicine = await _context.Medicines
                .Include(m => m.StockStatusNavigation)
                .Include(m => m.DosageFormNavigation)
                .FirstOrDefaultAsync(m => m.MedicineID == id && !m.IsDeleted);

            if (Medicine == null)
            {
                return NotFound();
            }

            ActiveSubstancesInput = string.Join(", ", Medicine.ActiveSubstances);

            // Store original values for JavaScript change detection
            OriginalValuesJson = System.Text.Json.JsonSerializer.Serialize(new
            {
                tradeName = Medicine.TradeName,
                activeSubstances = ActiveSubstancesInput,
                strength = Medicine.Strength,
                dosageForm = Medicine.DosageForm,
                stockStatus = Medicine.StockStatus
            });

            await LoadDropdownData();

            return Page();
        }

        public async Task<IActionResult> OnPostSaveAsync()
        {
            // Parse active substances
            Medicine.ActiveSubstances = ActiveSubstancesInput?
               .Split(',')
               .Select(s => s.Trim())
               .Where(s => !string.IsNullOrEmpty(s))
               .ToList() ?? new List<string>();

            // Manual validation
            if (Medicine.ActiveSubstances == null || !Medicine.ActiveSubstances.Any())
            {
                ModelState.AddModelError("ActiveSubstancesInput", "At least one active substance is required.");
            }
            else
            {
                ModelState.Remove("Medicine.ActiveSubstances");
                ModelState.Remove("ActiveSubstances");
            }

            if (!ModelState.IsValid)
            {
                await LoadDropdownData();
                return Page();
            }

            // Retrieve the existing medicine from the database
            var existingMedicine = await _context.Medicines.FindAsync(Medicine.MedicineID);
            if (existingMedicine == null || existingMedicine.IsDeleted)
            {
                return NotFound();
            }

            // Update properties
            existingMedicine.TradeName = Medicine.TradeName;
            existingMedicine.ActiveSubstances = Medicine.ActiveSubstances;
            existingMedicine.Strength = Medicine.Strength;
            existingMedicine.DosageForm = Medicine.DosageForm;
            existingMedicine.StockStatus = Medicine.StockStatus;

            await _context.SaveChangesAsync();
            return RedirectToPage("Details", new { id = Medicine.MedicineID });
        }

        public async Task<IActionResult> OnPostDeleteAsync(int id)
        {
            var medicine = await _context.Medicines.FindAsync(id);
            if (medicine == null)
            {
                return NotFound();
            }

            // Soft delete
            medicine.IsDeleted = true;
            await _context.SaveChangesAsync();

            return RedirectToPage("Index");
        }

        private async Task LoadDropdownData()
        {
            var stockStatuses = await _context.StockStatuses.AsNoTracking().ToListAsync();
            StockStatusOptions = stockStatuses
                .Select(s => new SelectListItem { Value = s.StockStatusID.ToString(), Text = s.Name })
                .ToList();

            var dosageForms = await _context.DosageForms.AsNoTracking().ToListAsync();
            DosageFormOptions = dosageForms
                .Select(d => new SelectListItem { Value = d.DosageFormID.ToString(), Text = d.Name })
                .ToList();
        }
    }
}
