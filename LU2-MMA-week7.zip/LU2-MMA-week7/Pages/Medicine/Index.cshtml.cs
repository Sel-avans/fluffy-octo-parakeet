using LU2_software_testen.Models;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using System.Linq;
using Microsoft.AspNetCore.Mvc;

namespace Pages.Medicine
{
    [Authorize(Roles = "apothecary")]
    public class IndexModel : PageModel
    {
        private readonly AppDbContext _context;

        public IndexModel(AppDbContext context)
        {
            _context = context;
        }

        public IList<LU2_software_testen.Models.Medicine> Medicines { get; set; } = new List<LU2_software_testen.Models.Medicine>();

        [BindProperty(SupportsGet = true)]
        public string? TradeNameFilter { get; set; }

        [BindProperty(SupportsGet = true)]
        public string? ActiveSubstancesFilter { get; set; }

        public async Task OnGetAsync()
        {
            // Start with base query - only non-deleted medicines
            var query = _context.Medicines
                .Include(m => m.StockStatusNavigation)
                .Where(m => !m.IsDeleted)
                .AsQueryable();

            // Apply Trade Name filter if provided
            if (!string.IsNullOrWhiteSpace(TradeNameFilter))
            {
                query = query.Where(m => m.TradeName.Contains(TradeNameFilter));
            }

            // Execute query and load into memory for client-side filtering
            var medicines = await query
                .OrderBy(m => m.TradeName)
                .AsNoTracking()
                .ToListAsync();

            // Apply Active Substances filter on client side if provided
            if (!string.IsNullOrWhiteSpace(ActiveSubstancesFilter))
            {
                medicines = medicines
                    .Where(m => m.ActiveSubstances.Any(a => a.Contains(ActiveSubstancesFilter, StringComparison.OrdinalIgnoreCase)))
                    .ToList();
            }

            Medicines = medicines;
        }
    }
}
