using Microsoft.AspNetCore.Mvc.RazorPages;
using LU2_software_testen.Models;
using Microsoft.EntityFrameworkCore;

namespace LU2_software_testen.Pages.Admin
{
    public class DatabaseStatusModel : PageModel
    {
        private readonly AppDbContext _context;

        public DatabaseStatusModel(AppDbContext context)
        {
            _context = context;
        }

        public int UserRolesCount { get; set; }
        public int UsersCount { get; set; }
        public int DosageFormsCount { get; set; }
        public int StockStatusCount { get; set; }
        public int MedicinesCount { get; set; }
        public List<UserRole> UserRoles { get; set; } = new();

        public void OnGet()
        {
            UserRolesCount = _context.UserRoles.Count();
            UsersCount = _context.Users.Count();
            DosageFormsCount = _context.DosageForms.Count();
            StockStatusCount = _context.StockStatuses.Count();
            MedicinesCount = _context.Medicines.Count();

            UserRoles = _context.UserRoles.ToList();
        }
    }
}
