using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using LU2_software_testen.Models;
using LU2_software_testen.Services;

namespace Pages.Patients
{
    [Authorize(Roles = "apothecary")]
    public class IndexModel : PageModel
    {
        private readonly IPatientService _patientService;

        public IndexModel(IPatientService patientService)
        {
            _patientService = patientService;
        }

        public List<User> Patients { get; set; } = new List<User>();

        [BindProperty(SupportsGet = true)]
        public string? SearchName { get; set; }

        public void OnGet()
        {
            Patients = _patientService.GetPatients(SearchName);
        }
    }
}
