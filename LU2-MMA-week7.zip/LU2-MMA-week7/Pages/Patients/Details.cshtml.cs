using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using LU2_software_testen.Models;
using LU2_software_testen.Services;

namespace Pages.Patients
{
    [Authorize(Roles = "apothecary")]
    public class DetailsModel : PageModel
    {
        private readonly IPatientService _patientService;

        public DetailsModel(IPatientService patientService)
        {
            _patientService = patientService;
        }

        public User? Patient { get; set; }
        public List<Prescription> ActivePrescriptions { get; set; } = new List<Prescription>();

        // Maps PrescriptionID to a list of medicine details for that prescription
        public Dictionary<int, List<PrescriptionMedicineDetail>> PrescriptionMedicines { get; set; } 
            = new Dictionary<int, List<PrescriptionMedicineDetail>>();

        [BindProperty(SupportsGet = true)]
        public int PatientId { get; set; }

        public IActionResult OnGet()
        {
            Patient = _patientService.GetPatientById(PatientId);

            if (Patient == null)
            {
                return NotFound();
            }

            // Only display the single most relevant active prescription (the first returned)
            var active = _patientService.GetActivePrescriptionsForPatient(PatientId);
            ActivePrescriptions = active.Take(1).ToList();

            // Load medicines for the single prescription (if any)
            foreach (var prescription in ActivePrescriptions)
            {
                // If the prescription references a soft-deleted medicine, return 409 Conflict
                if (_patientService.PrescriptionHasSoftDeletedMedicine(prescription.Id))
                {
                    return StatusCode(409);
                }

                var medicines = _patientService.GetPrescriptionMedicines(prescription.Id);
                PrescriptionMedicines[prescription.Id] = medicines;
            }

            return Page();
        }
    }
}
