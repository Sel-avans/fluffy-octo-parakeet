using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Security.Claims;

namespace Pages.Account
{
    public class AccessDeniedModel : PageModel
    {
        [FromQuery(Name = "ReturnUrl")]
        public string? ReturnUrl { get; set; }

        public string UserRole { get; set; } = "None";

        public void OnGet()
        {
            // Get the user's role for debugging
            if (User.Identity?.IsAuthenticated == true)
            {
                var roleClaim = User.FindFirst(ClaimTypes.Role);
                UserRole = roleClaim?.Value ?? "No role claim found";
            }
        }
    }
}
