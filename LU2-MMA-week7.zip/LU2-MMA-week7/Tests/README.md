# Testomgeving Medicine Management Application (week 7)

Geautomatiseerde acceptatietests voor de opgeleverde versie in `LU2-MMA-week7`: de nieuwe stories 16 (apotheker
bekijkt voorschriften) en 28 (medicijnen beheren), plus alle testcases van week 4 als regressietest.

Open `MMA-Testomgeving.sln` (in de map `LU2-MMA-week7`): die bevat de applicatie en het testproject.

## Twee soorten testcases in één project

| Soort | ID | Hoe | Waarvoor |
|---|---|---|---|
| Selenium (browser) | `UI-…` | Echte Chrome (headless) via Selenium WebDriver. De applicatie draait als echte webserver (Kestrel) op een vrije poort. | Gebruikersflows door de schermen: klikken, typen, kiezen, JavaScript, browservalidatie, dialogen |
| HTTP | `TC-…`, `EXT-…` | De applicatie draait in het testproces (`WebApplicationFactory`); verzoeken gaan via HTTP zoals een browser ze stuurt. | Snelle functionele tests, grensgevallen en beveiligingstests met verzoeken die een browser niet stuurt (direct POST, andere rol, path traversal) |

Beide soorten gebruiken dezelfde testdatabase, testaccounts, logging en rapportage. Elk acceptatiecriterium heeft
minimaal één Selenium-testcase en meerdere HTTP-testcases.

## Vereisten

- .NET 9 SDK
- SQL Server LocalDB (`(localdb)\mssqllocaldb`)
- Google Chrome. Selenium Manager downloadt bij de eerste run automatisch een passende ChromeDriver.

## Uitvoeren

```powershell
.\run-tests.ps1                       # alle testcases
.\run-tests.ps1 -Filter "TC~UI-"      # alleen de Selenium-testcases
.\run-tests.ps1 -Filter "Story=16"    # één story (nummering deel 1)
.\run-tests.ps1 -Filter "AC=AC-4.1"   # één acceptatiecriterium
.\run-tests.ps1 -Open                 # rapport na afloop openen
```

Of zonder script: `dotnet test MMA-Testomgeving.sln`. Zet in `MMA.Tests\testsettings.json` `Browser.Headless` op
`false` om de browser mee te zien klikken.

## Reset van data en configuratie

- **Data:** elke run maakt een nieuwe, lege database (`MMA_Test_<datum_tijd>`). De applicatie vult die zelf met haar
  seed-data; de testomgeving voegt de testaccounts toe. Na afloop wordt de database verwijderd
  (`Database.KeepAfterRun` op `true` om hem te bewaren). Testcases maken hun eigen patiënten en medicijnen aan,
  zodat ze onafhankelijk zijn en in elke volgorde kunnen draaien.
- **Configuratie:** alle instellingen staan in `MMA.Tests\testsettings.json` (projectbestand, versienaam, database,
  browser). Testdata staat los daarvan in `MMA.Tests\TestData\`.

## Resultaten per run

In `TestResults\<datum_tijd>\`:

| Bestand | Inhoud |
|---|---|
| `rapport.html` | resultaat per user story en acceptatiecriterium, testcases met stappen, bevindingen met historie |
| `testlog.txt` | per testcase elke stap, elk HTTP-verzoek, elke browseractie en elke controle (verwacht / werkelijk) |
| `screenshots\` | schermafdruk van elk browservenster bij een gefaalde Selenium-testcase |
| `applicatie-output.log` | console-uitvoer van de applicatie die voor de browsertests draaide |
| `resultaten.json` | alle resultaten machineleesbaar |
| `testrun.trx` | standaarduitvoer van de testrunner (alleen via `run-tests.ps1`) |

`TestResults\historie.csv` krijgt één regel per run. Elke run legt de geteste versie vast met vingerafdrukken van
de build en van de broncode (de oplevering bevat geen git-geschiedenis).

## Opbouw

| Map / bestand | Doel |
|---|---|
| `MMA.Tests\Testcases\` | HTTP-testcases, één klasse per user story |
| `MMA.Tests\Testcases\Selenium\` | Selenium-testcases voor de stories van week 4 en week 7 |
| `MMA.Tests\Infrastructure\` | testomgeving: applicatie starten (`AppHost`, `MmaApplicationFactory`), browser (`BrowserSession`), HTTP-sessie (`MmaClient`), logging, rapport |
| `MMA.Tests\TestData\` | testaccounts en medicijnen, acceptatiecriteria, bevindingenregister |
| `MMA.Tests\testsettings.json` | configuratie |

Elke testcase heeft `[Testcase(ID, criterium, titel)]`. Een criterium is *voldaan* als alle gekoppelde testcases
slagen. Testcases met ID `EXT-…` vallen buiten de acceptatiecriteria (beveiliging, verkenning); soort *Observatie*
legt gedrag vast zonder te falen.

Na een fix: voeg in `TestData\bevindingen.json` een regel toe aan de `historie` van de bevinding; het rapport laat
per run zien of een bevinding nog wordt gereproduceerd.
