<#
  Voert de volledige testsuite van de Medicine Management Application uit.

  Resultaat per run in Tests\TestResults\<datum_tijd>\ :
    rapport.html     overzicht per user story en acceptatiecriterium, met bevindingen
    testlog.txt      stappen, HTTP-verzoeken en controles per testcase
    resultaten.json  alle resultaten machineleesbaar
    testrun.trx      resultaat van de testrunner (o.a. te openen in Visual Studio)
  en een regel in Tests\TestResults\historie.csv.

  Gebruik:
    .\run-tests.ps1                      # alle testcases
    .\run-tests.ps1 -Filter "Story=25"   # alleen story 25 (deel 1-nummering)
    .\run-tests.ps1 -Filter "AC=AC-4.1"  # alleen testcases van één criterium
    .\run-tests.ps1 -Open                # rapport na afloop openen
#>
param(
    [string]$Filter = "",
    [switch]$Open
)

$ErrorActionPreference = "Stop"
$testsRoot = $PSScriptRoot
$project = Join-Path $testsRoot "MMA.Tests\MMA.Tests.csproj"
$runId = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
$resultsDir = Join-Path $testsRoot "TestResults\$runId"

$env:MMA_RUN_ID = $runId
$arguments = @("test", $project, "--logger", "trx;LogFileName=testrun.trx", "--results-directory", $resultsDir)
if ($Filter) { $arguments += @("--filter", $Filter) }

Write-Host "Testrun $runId starten..." -ForegroundColor Cyan
& dotnet @arguments
$exitCode = $LASTEXITCODE

$report = Join-Path $resultsDir "rapport.html"
if (Test-Path $report) {
    Write-Host ""
    Write-Host "Rapport: $report" -ForegroundColor Cyan
    if ($Open) { Start-Process $report }
}

# Exitcode 1 betekent dat er testcases zijn gefaald (bevindingen); het rapport is dan wel gemaakt.
exit $exitCode
