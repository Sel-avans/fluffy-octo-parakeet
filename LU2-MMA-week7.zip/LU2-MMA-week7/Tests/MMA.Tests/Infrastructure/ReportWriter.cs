using System.Net;
using System.Text;
using System.Text.Json;

namespace MMA.Tests.Infrastructure;

/// <summary>
/// Schrijft na elke testrun in TestResults\&lt;run-id&gt;\:
///  - rapport.html     : overzicht per user story en acceptatiecriterium, met bevindingen
///  - resultaten.json  : alle resultaten machineleesbaar
///  - testlog.txt      : (al tijdens de run geschreven) stappen en controles per testcase
/// en voegt een regel toe aan TestResults\historie.csv (één regel per run).
/// </summary>
public static class ReportWriter
{
    public const string Extra = "EXTRA";

    public static void Write(TestEnvironment env)
    {
        var run = env.Log;
        var summary = Summarize(env);
        File.WriteAllText(Path.Combine(run.ResultsDir, "resultaten.json"), JsonSerializer.Serialize(summary, JsonFiles.Options), new UTF8Encoding(false));
        File.WriteAllText(Path.Combine(run.ResultsDir, "rapport.html"), Html(env, summary), new UTF8Encoding(false));
        AppendHistory(env, summary);
    }

    // ---------- samenvatting ----------

    public sealed record CriterionResult(string Id, string Tekst, string Status, int Tests, int Geslaagd, int Gefaald, int Fout, List<string> Testcases);
    public sealed record StoryResult(string Oplevering, int Deel1, int Opdracht, string Titel, string Rol, string Tekst, string Status, int CriteriaVoldaan, int CriteriaTotaal, List<CriterionResult> Criteria);
    public sealed record DefectResult(string Id, string Titel, string Story, string Ernst, string Prioriteit, string Status, string DezeRun, List<string> Testcases);
    public sealed record RunSummary(string RunId, DateTime Start, DateTime Einde, SutVersion Versie, string Database,
        int Totaal, int Geslaagd, int Gefaald, int Fout, int Observaties,
        List<StoryResult> Stories, List<DefectResult> Bevindingen, List<string> NietGeregistreerd, List<TestRecord> Testcases);

    public static RunSummary Summarize(TestEnvironment env)
    {
        var records = env.Log.Records.OrderBy(r => SortKey(r.Id)).ToList();
        var stories = new List<StoryResult>();
        foreach (var s in env.Catalog.Stories)
        {
            var criteria = s.Criteria.Select(c =>
            {
                var tests = records.Where(r => r.Criterium == c.Id).ToList();
                var passed = tests.Count(r => r.Uitkomst == Uitkomst.Geslaagd);
                var failed = tests.Count(r => r.Uitkomst == Uitkomst.Gefaald);
                var errors = tests.Count(r => r.Uitkomst == Uitkomst.Fout);
                var status = tests.Count == 0 ? "Niet getest"
                    : failed > 0 ? "Niet voldaan"
                    : errors > 0 ? "Onbepaald"
                    : "Voldaan";
                return new CriterionResult(c.Id, c.Tekst, status, tests.Count, passed, failed, errors, tests.Select(t => t.Id).ToList());
            }).ToList();
            var ok = criteria.Count(c => c.Status == "Voldaan");
            var storyStatus = ok == criteria.Count ? "Voldoet" : ok == 0 ? "Voldoet niet" : "Voldoet gedeeltelijk";
            stories.Add(new StoryResult(s.Oplevering, s.Deel1, s.Opdracht, s.Titel, s.Rol, s.Tekst, storyStatus, ok, criteria.Count, criteria));
        }

        var defects = env.Defects.Bevindingen.Select(d =>
        {
            var linked = records.Where(r => d.Testcases.Contains(r.Id)).ToList();
            var dezeRun = linked.Count == 0 ? "Niet uitgevoerd"
                : linked.Any(r => r.Uitkomst == Uitkomst.Gefaald) ? "Gereproduceerd"
                : linked.All(r => r.Uitkomst is Uitkomst.Geslaagd or Uitkomst.Observatie) ? "Niet meer gereproduceerd (hertest geslaagd)"
                : "Onbepaald";
            return new DefectResult(d.Id, d.Titel, d.Story, d.Ernst, d.Prioriteit, d.Status, dezeRun, d.Testcases);
        }).ToList();

        var registered = env.Defects.Bevindingen.SelectMany(d => d.Testcases).ToHashSet();
        var unregistered = records.Where(r => r.Uitkomst == Uitkomst.Gefaald && !registered.Contains(r.Id)).Select(r => r.Id).ToList();

        return new RunSummary(env.RunId, env.Log.Started, env.Log.Finished, env.Sut, env.DatabaseName,
            records.Count,
            records.Count(r => r.Uitkomst == Uitkomst.Geslaagd),
            records.Count(r => r.Uitkomst == Uitkomst.Gefaald),
            records.Count(r => r.Uitkomst == Uitkomst.Fout),
            records.Count(r => r.Uitkomst == Uitkomst.Observatie),
            stories, defects, unregistered, records);
    }

    private static string SortKey(string id)
    {
        // TC-4.1-01 -> 004.1-01 zodat de volgorde numeriek klopt
        var parts = id.Split('-');
        return parts.Length >= 3 && parts[1].Split('.') is var p && int.TryParse(p[0], out var n)
            ? $"{parts[0]}-{n:000}.{(p.Length > 1 ? p[1] : "")}-{parts[2]}"
            : id;
    }

    // ---------- historie ----------

    private static void AppendHistory(TestEnvironment env, RunSummary s)
    {
        var file = Path.Combine(env.ResultsRoot, "historie.csv");
        var isNew = !File.Exists(file);
        using var w = new StreamWriter(file, append: true, new UTF8Encoding(true));
        if (isNew) w.WriteLine("run;start;versie;commit;lokale_wijzigingen;build;broncode;totaal;geslaagd;gefaald;fout;observatie;criteria_voldaan;criteria_totaal");
        var acOk = s.Stories.Sum(x => x.CriteriaVoldaan);
        var acAll = s.Stories.Sum(x => x.CriteriaTotaal);
        w.WriteLine(string.Join(";", s.RunId, s.Start.ToString("yyyy-MM-dd HH:mm:ss"), s.Versie.Label, s.Versie.GitCommit,
            s.Versie.LocalChanges, s.Versie.BuildFingerprint, s.Versie.SourceFingerprint, s.Totaal, s.Geslaagd, s.Gefaald, s.Fout, s.Observaties, acOk, acAll));
    }

    // ---------- HTML ----------

    private static string E(string? s) => WebUtility.HtmlEncode(s ?? "");

    private static string Badge(string status) => status switch
    {
        "Voldaan" or "Voldoet" or "Geslaagd" => $"<span class='b ok'>{E(status)}</span>",
        "Niet voldaan" or "Voldoet niet" or "Gefaald" => $"<span class='b nok'>{E(status)}</span>",
        "Voldoet gedeeltelijk" or "Onbepaald" or "Fout" => $"<span class='b warn'>{E(status)}</span>",
        "Observatie" => $"<span class='b info'>{E(status)}</span>",
        _ => $"<span class='b'>{E(status)}</span>"
    };

    private static string RunBadge(string dezeRun) => dezeRun switch
    {
        "Gereproduceerd" => $"<span class='b nok'>{E(dezeRun)}</span>",
        _ when dezeRun.StartsWith("Niet meer") => $"<span class='b ok'>{E(dezeRun)}</span>",
        _ => $"<span class='b'>{E(dezeRun)}</span>"
    };

    private static string SeverityBadge(string ernst) => ernst switch
    {
        "Kritiek" => "<span class='b nok'>Kritiek</span>",
        "Hoog" => "<span class='b high'>Hoog</span>",
        "Middel" => "<span class='b warn'>Middel</span>",
        _ => $"<span class='b'>{E(ernst)}</span>"
    };

    private static string Html(TestEnvironment env, RunSummary s)
    {
        var defectByTc = env.Defects.Bevindingen
            .SelectMany(d => d.Testcases.Select(tc => (tc, d.Id)))
            .GroupBy(x => x.tc).ToDictionary(g => g.Key, g => string.Join(", ", g.Select(x => x.Id)));

        var sb = new StringBuilder();
        sb.Append($$"""
        <!doctype html><html lang="nl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Testrapport {{E(s.RunId)}}</title>
        <style>
        :root{--fg:#1d2433;--muted:#5b6475;--bg:#fff;--line:#d9dde5;--ok:#1f7a3d;--okbg:#e3f4e8;--nok:#a4161a;--nokbg:#fbe4e4;--warn:#8a5a00;--warnbg:#fff1d6;--info:#1d4f91;--infobg:#e3edfb;--high:#b4430c;--highbg:#fde8dc}
        body{font-family:Segoe UI,Arial,sans-serif;color:var(--fg);background:var(--bg);margin:0 auto;max-width:1150px;padding:24px 16px;line-height:1.45}
        h1{margin:0 0 4px}h2{margin-top:36px;border-bottom:2px solid var(--line);padding-bottom:4px}h3{margin:24px 0 6px}
        .muted{color:var(--muted)}table{border-collapse:collapse;width:100%;margin:8px 0 16px;font-size:14px}
        th,td{border:1px solid var(--line);padding:6px 8px;text-align:left;vertical-align:top;overflow-wrap:anywhere}th{background:#f3f5f8}
        .b{display:inline-block;padding:1px 8px;border-radius:10px;font-size:12px;font-weight:600;background:#eceff3;white-space:nowrap}
        .ok{background:var(--okbg);color:var(--ok)}.nok{background:var(--nokbg);color:var(--nok)}.warn{background:var(--warnbg);color:var(--warn)}
        .info{background:var(--infobg);color:var(--info)}.high{background:var(--highbg);color:var(--high)}
        .tiles{display:flex;gap:12px;flex-wrap:wrap;margin:16px 0}.tile{border:1px solid var(--line);border-radius:8px;padding:10px 16px;min-width:120px}
        .tile b{display:block;font-size:26px}.ac{background:#f8f9fb;border-left:4px solid var(--line);padding:6px 10px;margin:6px 0}
        details{margin:2px 0}summary{cursor:pointer}pre{white-space:pre-wrap;font-size:12px;background:#f6f7f9;padding:8px;margin:4px 0}
        </style></head><body>
        <h1>Testrapport Medicine Management Application</h1>
        <div class="muted">Testrun {{E(s.RunId)}} &middot; {{s.Start:yyyy-MM-dd HH:mm:ss}} tot {{s.Einde:HH:mm:ss}} ({{(s.Einde - s.Start).TotalSeconds:0.0}} s)</div>

        <h2>Geteste versie</h2>
        <table>
        <tr><th>Versie</th><td>{{E(s.Versie.Label)}}</td></tr>
        {{(s.Versie.GitCommit == "onbekend"
            ? "<tr><th>Git commit</th><td>geen git-repository meegeleverd; de versie is herleidbaar via de vingerafdrukken van build en broncode</td></tr>"
            : $"<tr><th>Git commit</th><td>{E(s.Versie.GitCommit)} &ldquo;{E(s.Versie.GitCommitMessage)}&rdquo; ({E(s.Versie.GitCommitDate)}, branch {E(s.Versie.GitBranch)})</td></tr>")}}
        <tr style="{{(s.Versie.GitCommit == "onbekend" ? "display:none" : "")}}"><th>Lokale wijzigingen</th><td>{{s.Versie.LocalChanges}} bestand(en) gewijzigd t.o.v. de commit (getest is de map zoals opgeleverd){{(s.Versie.LocalChanges > 0 ? "<details><summary>toon bestanden</summary><pre>" + E(string.Join("\n", s.Versie.LocalChangedFiles)) + "</pre></details>" : "")}}</td></tr>
        <tr><th>Assembly</th><td>{{E(s.Versie.AssemblyName)}} {{E(s.Versie.AssemblyVersion)}}</td></tr>
        <tr><th>Build</th><td>vingerafdruk {{E(s.Versie.BuildFingerprint)}}, gebouwd {{s.Versie.BuildTime:yyyy-MM-dd HH:mm:ss}}</td></tr>
        <tr><th>Broncode</th><td>vingerafdruk {{E(s.Versie.SourceFingerprint)}} over {{s.Versie.SourceFiles}} bestanden (.cs, .cshtml, .csproj, appsettings)</td></tr>
        <tr><th>Testdatabase</th><td>{{E(s.Database)}} (na afloop {{(env.Settings.Database.KeepAfterRun ? "bewaard" : "verwijderd")}})</td></tr>
        </table>

        <h2>Samenvatting</h2>
        <div class="tiles">
          <div class="tile"><b>{{s.Totaal}}</b>testcases</div>
          <div class="tile"><b style="color:var(--ok)">{{s.Geslaagd}}</b>geslaagd</div>
          <div class="tile"><b style="color:var(--nok)">{{s.Gefaald}}</b>gefaald</div>
          <div class="tile"><b style="color:var(--warn)">{{s.Fout}}</b>technische fout</div>
          <div class="tile"><b style="color:var(--info)">{{s.Observaties}}</b>observaties</div>
          <div class="tile"><b>{{s.Stories.Sum(x => x.CriteriaVoldaan)}}/{{s.Stories.Sum(x => x.CriteriaTotaal)}}</b>criteria voldaan</div>
        </div>
        <table><tr><th>Oplevering</th><th>Opdracht</th><th>Deel 1</th><th>User story</th><th>Criteria voldaan</th><th>Status</th></tr>
        """);
        foreach (var st in s.Stories)
            sb.Append($"<tr><td>{E(st.Oplevering)}</td><td>{(st.Opdracht == 0 ? "-" : st.Opdracht.ToString())}</td><td>{st.Deel1}</td><td>{E(st.Titel)}</td><td>{st.CriteriaVoldaan}/{st.CriteriaTotaal} &nbsp; "
                      + string.Join(" ", st.Criteria.Select(c => $"{E(c.Id)} {Badge(c.Status)}")) + $"</td><td>{Badge(st.Status)}</td></tr>");
        sb.Append("</table>");

        sb.Append("<h2>Resultaten per user story</h2><p class='muted'>Een criterium is <i>voldaan</i> als alle gekoppelde testcases slagen. " +
                  "Eén gefaalde testcase betekent <i>niet voldaan</i>. Klik op een testcase voor de uitgevoerde stappen.</p>");
        foreach (var st in s.Stories)
        {
            sb.Append($"<h3>{E(st.Titel)} ({E(st.Oplevering)}{(st.Opdracht == 0 ? "" : $", opdracht {st.Opdracht}")}, deel 1 nr. {st.Deel1}) {Badge(st.Status)}</h3><div class='muted'>{E(st.Tekst)}</div>");
            foreach (var c in st.Criteria)
            {
                sb.Append($"<div class='ac'><b>{E(c.Id)}</b> {Badge(c.Status)} &nbsp;{E(c.Tekst)} <span class='muted'>({c.Geslaagd}/{c.Tests} geslaagd)</span></div>");
                TestTable(sb, s.Testcases.Where(r => r.Criterium == c.Id), defectByTc);
            }
            var extra = s.Testcases.Where(r => r.Criterium == Extra && r.Story == st.Deel1).ToList();
            if (extra.Count > 0)
            {
                sb.Append("<div class='ac'><b>Aanvullend</b> &nbsp;Tests buiten de acceptatiecriteria (beveiliging, robuustheid, verkenning)</div>");
                TestTable(sb, extra, defectByTc);
            }
        }

        var other = s.Testcases.Where(r => r.Criterium == Extra && s.Stories.All(st => st.Deel1 != r.Story)).ToList();
        if (other.Count > 0)
        {
            sb.Append("<h3>Overige aanvullende tests</h3>");
            TestTable(sb, other, defectByTc);
        }

        sb.Append("<h2>Bevindingen</h2><p class='muted'>Uit TestData/bevindingen.json. &lsquo;Deze run&rsquo; laat zien of de bevinding in deze testrun opnieuw is aangetoond.</p>");
        sb.Append("<table><tr><th>ID</th><th>Bevinding</th><th>Story</th><th>Ernst</th><th>Prioriteit</th><th>Status</th><th>Deze run</th><th>Testcases</th></tr>");
        foreach (var d in s.Bevindingen)
        {
            var full = env.Defects.Bevindingen.First(x => x.Id == d.Id);
            var detail = $"<details><summary>{E(d.Titel)}</summary><div>{E(full.Beschrijving)}</div>" +
                         $"<div><b>Reproductie:</b> {E(full.Reproductie)}</div><div><b>Verwacht:</b> {E(full.Verwacht)}</div><div><b>Werkelijk:</b> {E(full.Werkelijk)}</div>" +
                         "<div><b>Belang per stakeholder:</b><ul>" + string.Concat(full.Stakeholders.Select(x => $"<li>{E(x.Stakeholder)}: {E(x.Belang)}</li>")) + "</ul></div>" +
                         "<div><b>Historie:</b><ul>" + string.Concat(full.Historie.Select(h => $"<li>{E(h.Datum)} &ndash; {E(h.Status)}: {E(h.Opmerking)}</li>")) +
                         $"<li>{s.Start:yyyy-MM-dd} &ndash; testrun {E(s.RunId)}: {E(d.DezeRun)}</li></ul></div></details>";
            sb.Append($"<tr><td>{E(d.Id)}</td><td>{detail}</td><td>{E(d.Story)}</td><td>{SeverityBadge(d.Ernst)}</td><td>{E(d.Prioriteit)}</td><td>{E(d.Status)}</td>" +
                      $"<td>{RunBadge(d.DezeRun)}</td>" +
                      $"<td>{E(string.Join(", ", d.Testcases))}</td></tr>");
        }
        sb.Append("</table>");
        if (s.NietGeregistreerd.Count > 0)
            sb.Append($"<p><span class='b nok'>Let op</span> Gefaalde testcases zonder geregistreerde bevinding: {E(string.Join(", ", s.NietGeregistreerd))}</p>");

        sb.Append("<h2>Bestanden van deze run</h2><ul><li><a href='testlog.txt'>testlog.txt</a> &ndash; stappen, HTTP-verzoeken en controles per testcase</li>" +
                  "<li><a href='resultaten.json'>resultaten.json</a> &ndash; alle resultaten machineleesbaar</li>" +
                  "<li>testrun.trx &ndash; resultaat van de testrunner (als gestart via run-tests.ps1)</li>" +
                  "<li>../historie.csv &ndash; één regel per testrun</li></ul>");
        sb.Append("</body></html>");
        return sb.ToString();
    }

    private static void TestTable(StringBuilder sb, IEnumerable<TestRecord> tests, Dictionary<string, string> defectByTc)
    {
        sb.Append("<table><tr><th style='width:95px'>Testcase</th><th>Titel</th><th style='width:85px'>Soort</th><th style='width:90px'>Uitkomst</th><th style='width:80px'>Bevinding</th></tr>");
        foreach (var r in tests)
        {
            var steps = string.Join("\n", r.Stappen.Select(st =>
                $"{st.Tijd:HH:mm:ss} {st.Type,-10}{(st.Ok == true ? " [OK] " : st.Ok == false ? " [NOK]" : "      ")} {st.Tekst}"));
            sb.Append($"<tr><td>{E(r.Id)}</td><td><details><summary>{E(r.Titel)}</summary>" +
                      (string.IsNullOrEmpty(r.Scenario) ? "" : $"<div class='muted'>Scenario: {E(r.Scenario)}</div>") +
                      (string.IsNullOrEmpty(r.Melding) ? "" : $"<div><b>Melding:</b> {E(r.Melding)}</div>") +
                      $"<pre>{E(steps)}</pre></details></td><td>{r.Soort}</td><td>{Badge(r.Uitkomst.ToString())}</td>" +
                      $"<td>{E(defectByTc.GetValueOrDefault(r.Id, ""))}</td></tr>");
        }
        sb.Append("</table>");
    }
}
