namespace MMA.Tests.Infrastructure;

/// <summary>
/// Herbruikbare acties voor de schermen van de apotheker (week 7): patiënten zoeken, voorschriften
/// van een patiënt bekijken en medicijnen beheren. Zelfde aanpak als de acties in MmaClient.
/// </summary>
public static class ApothekerSchermen
{
    // ---------- patiënten ----------

    public static async Task<PatientList> GetPatientsAsync(this MmaClient s, string? search = null) =>
        new(await s.GetAsync(string.IsNullOrEmpty(search) ? "/Patients/Index" : $"/Patients/Index?searchName={Uri.EscapeDataString(search)}"));

    public static async Task<PatientDetails> GetPatientDetailsAsync(this MmaClient s, int patientId) =>
        new(await s.GetAsync($"/Patients/Details?patientId={patientId}"));

    // ---------- medicijnen ----------

    public static async Task<MedicineList> GetMedicinesAsync(this MmaClient s, string? tradeName = null, string? substance = null)
    {
        var query = new List<string>();
        if (!string.IsNullOrEmpty(tradeName)) query.Add("TradeNameFilter=" + Uri.EscapeDataString(tradeName));
        if (!string.IsNullOrEmpty(substance)) query.Add("ActiveSubstancesFilter=" + Uri.EscapeDataString(substance));
        return new MedicineList(await s.GetAsync("/Medicine/Index" + (query.Count > 0 ? "?" + string.Join("&", query) : "")));
    }

    /// <summary>Verstuurt het formulier 'Create Medicine' met precies de velden die het scherm aanbiedt, plus eventuele extra velden.</summary>
    public static async Task<HtmlPage> CreateMedicineAsync(this MmaClient s, string tradeName, string activeSubstances,
        Dictionary<string, string>? extra = null)
    {
        var fields = new Dictionary<string, string>
        {
            ["Medicine.TradeName"] = tradeName,
            ["ActiveSubstancesInput"] = activeSubstances
        };
        foreach (var (k, v) in extra ?? new()) fields[k] = v;
        return await s.PostFormAsync("/Medicine/Create", fields);
    }

    public static async Task<HtmlPage> EditMedicineAsync(this MmaClient s, int id, string tradeName, string activeSubstances,
        string strength, string? dosageForm = "1", string? stockStatus = "1", string? tokenFrom = null) =>
        await s.PostFormAsync($"/Medicine/Edit/{id}?handler=Save", new Dictionary<string, string>
        {
            ["Medicine.MedicineID"] = id.ToString(),
            ["Medicine.TradeName"] = tradeName,
            ["ActiveSubstancesInput"] = activeSubstances,
            ["Medicine.Strength"] = strength,
            ["Medicine.DosageForm"] = dosageForm ?? "",
            ["Medicine.StockStatus"] = stockStatus ?? ""
        }, tokenFrom: tokenFrom ?? $"/Medicine/Edit/{id}");

    public static async Task<HtmlPage> DeleteMedicineAsync(this MmaClient s, int id, string? tokenFrom = null) =>
        await s.PostFormAsync($"/Medicine/Edit/{id}?handler=Delete", Array.Empty<KeyValuePair<string, string>>(),
            tokenFrom: tokenFrom ?? $"/Medicine/Edit/{id}");

    /// <summary>Handelsnamen in de keuzelijst van het scherm 'Add Medicine to Prescription' (arts).</summary>
    public static async Task<List<string>> PrescribableMedicinesAsync(this MmaClient s)
    {
        var page = await s.GetAsync("/Prescriptions/AddMedicineToPrescription");
        return page.QA("select[name=SelectedMedicineId] option")
            .Where(o => !string.IsNullOrEmpty(o.GetAttribute("value")))
            .Select(o => o.TextContent.Trim().Split(" (")[0])
            .ToList();
    }
}

public sealed class PatientList
{
    public PatientList(HtmlPage page)
    {
        Page = page;
        Rows = page.QA("table tbody tr")
            .Select(tr => tr.QuerySelectorAll("td").Select(td => td.TextContent.Trim()).ToArray())
            .Where(c => c.Length >= 4)
            .Select(c => new Row(int.TryParse(c[0], out var id) ? id : 0, c[1], c[2], c[3]))
            .ToList();
    }

    public HtmlPage Page { get; }
    public List<Row> Rows { get; }
    public bool Contains(TestAccount a) => Rows.Any(r => r.Id == a.Id);
    public string Names => Rows.Count == 0 ? "(geen)" : string.Join(", ", Rows.Select(r => r.Name));

    public sealed record Row(int Id, string Name, string Email, string Phone);
}

public sealed class PatientDetails
{
    public PatientDetails(HtmlPage page)
    {
        Page = page;
        var header = page.QA(".card-header h5").Select(h => h.TextContent.Trim()).FirstOrDefault(t => t.StartsWith("Active Prescriptions")) ?? "";
        var m = System.Text.RegularExpressions.Regex.Match(header, @"\((\d+)\)");
        PrescriptionCount = m.Success ? int.Parse(m.Groups[1].Value) : 0;
        Prescriptions = page.QA(".prescription-card").Select(card => new Prescription(
            card.QuerySelectorAll(".row p.text-muted").Select(p => p.TextContent.Trim()).ToArray(),
            card.QuerySelectorAll("tbody tr")
                .Select(tr => tr.QuerySelectorAll("td").Select(td => td.TextContent.Trim()).ToArray())
                .Where(c => c.Length >= 4)
                .Select(c => new Line(c[0], c[1], c[2], c[3]))
                .ToList())).ToList();
    }

    public HtmlPage Page { get; }
    public int PrescriptionCount { get; }
    public List<Prescription> Prescriptions { get; }
    public IEnumerable<Line> AllLines => Prescriptions.SelectMany(p => p.Lines);
    public bool HasMedicine(string tradeName) => AllLines.Any(l => l.Medicine == tradeName);
    public Line? Find(string tradeName) => AllLines.FirstOrDefault(l => l.Medicine == tradeName);
    public string MedicineNames => AllLines.Any() ? string.Join(", ", AllLines.Select(l => l.Medicine)) : "(geen)";

    public sealed record Prescription(string[] Dates, List<Line> Lines);
    public sealed record Line(string Medicine, string Strength, string Quantity, string Instructions);
}

public sealed class MedicineList
{
    public MedicineList(HtmlPage page)
    {
        Page = page;
        Rows = page.QA("table.medicine-table tbody tr")
            .Select(tr => tr.QuerySelectorAll("td").Select(td => td.TextContent.Trim()).ToArray())
            .Where(c => c.Length >= 3)
            .Select(c => new Row(c[0], c[1], c[2]))
            .ToList();
    }

    public HtmlPage Page { get; }
    public List<Row> Rows { get; }
    public bool Contains(string tradeName) => Rows.Any(r => r.TradeName == tradeName);
    public string Names => Rows.Count == 0 ? "(geen)" : string.Join(", ", Rows.Select(r => r.TradeName));

    public sealed record Row(string TradeName, string ActiveSubstances, string StockStatus);
}
