using System.Net;
using AngleSharp.Dom;
using AngleSharp.Html.Parser;

namespace MMA.Tests.Infrastructure;

/// <summary>Een HTTP-antwoord van de applicatie, met de HTML al geparsed.</summary>
public sealed class HtmlPage
{
    private static readonly HtmlParser Parser = new();

    public HtmlPage(string method, string url, HttpStatusCode status, string? location, string body)
    {
        Method = method;
        Url = url;
        Status = status;
        Location = location;
        Body = body;
        Document = Parser.ParseDocument(body);
    }

    public string Method { get; }
    public string Url { get; }
    public HttpStatusCode Status { get; }
    public int StatusCode => (int)Status;
    public string? Location { get; }
    public string Body { get; }
    public IDocument Document { get; }

    public bool IsRedirect => StatusCode is >= 300 and < 400;
    public string Text => Document.Body?.TextContent ?? Body;
    public bool Contains(string text) => Text.Contains(text, StringComparison.OrdinalIgnoreCase);
    public IElement? Q(string selector) => Document.QuerySelector(selector);
    public IHtmlCollection<IElement> QA(string selector) => Document.QuerySelectorAll(selector);

    /// <summary>Gebruikersnaam rechtsboven in de navigatiebalk (leeg als niet ingelogd).</summary>
    public string LoggedInUser => Q("[name=user_name]")?.TextContent.Trim() ?? "";

    public string? AntiforgeryToken => Q("input[name=__RequestVerificationToken]")?.GetAttribute("value");

    public string Describe() => IsRedirect ? $"{StatusCode} -> {Location}" : $"{StatusCode}";
}

/// <summary>
/// Simuleert één browsersessie (eigen cookies en sessie) en biedt herbruikbare acties per scherm,
/// zodat testcases niet steeds dezelfde stappen hoeven te herhalen. Elk verzoek komt in de testlogging.
/// </summary>
public sealed class MmaClient : IDisposable
{
    private readonly HttpClient _http;
    private readonly Action<string> _log;

    public MmaClient(HttpClient http, Action<string> log, string sessionName)
    {
        _http = http;
        _log = log;
        Name = sessionName;
    }

    public string Name { get; }
    public TestAccount? Account { get; private set; }

    // ---------- basis ----------

    public async Task<HtmlPage> GetAsync(string url)
    {
        using var response = await _http.GetAsync(url);
        var page = await ToPage("GET", url, response);
        _log($"[{Name}] GET  {url}  => {page.Describe()}");
        return page;
    }

    /// <summary>GET met het volgen van redirects (zoals een browser), maximaal 5 stappen.</summary>
    public async Task<HtmlPage> BrowseAsync(string url)
    {
        var page = await GetAsync(url);
        for (var i = 0; i < 5 && page.IsRedirect && page.Location != null; i++)
            page = await GetAsync(page.Location);
        return page;
    }

    /// <summary>
    /// Verstuurt een formulier zoals de browser dat doet: eerst wordt de pagina opgehaald voor het
    /// antiforgery-token, daarna worden de velden gepost.
    /// </summary>
    public async Task<HtmlPage> PostFormAsync(string url, IEnumerable<KeyValuePair<string, string>> fields,
        string? tokenFrom = null)
    {
        var source = await BrowseAsync(tokenFrom ?? StripQuery(url));
        var token = source.AntiforgeryToken
                    ?? throw new InvalidOperationException($"Geen antiforgery-token gevonden op {tokenFrom ?? url}");
        return await PostRawAsync(url, fields, token);
    }

    public async Task<HtmlPage> PostRawAsync(string url, IEnumerable<KeyValuePair<string, string>> fields, string? token)
    {
        var all = fields.ToList();
        if (token != null) all.Add(new("__RequestVerificationToken", token));
        using var content = new FormUrlEncodedContent(all);
        using var response = await _http.PostAsync(url, content);
        var page = await ToPage("POST", url, response);
        var shown = string.Join(", ", all.Where(f => f.Key != "__RequestVerificationToken")
            .Select(f => $"{f.Key}={(f.Key.Contains("Password") ? "***" : Shorten(f.Value))}"));
        _log($"[{Name}] POST {url}  [{shown}]  => {page.Describe()}");
        return page;
    }

    public async Task<HtmlPage> SendAsync(HttpMethod method, string url)
    {
        using var response = await _http.SendAsync(new HttpRequestMessage(method, url));
        var page = await ToPage(method.Method, url, response);
        _log($"[{Name}] {method.Method} {url}  => {page.Describe()}");
        return page;
    }

    // ---------- inloggen / uitloggen ----------

    public async Task<HtmlPage> LoginAsync(TestAccount account) => await LoginAsync(account.Username, account.Password, account);

    public async Task<HtmlPage> LoginAsync(string username, string password, TestAccount? account = null)
    {
        var result = await PostFormAsync("/Account/Login",
            new Dictionary<string, string> { ["Username"] = username, ["Password"] = password },
            tokenFrom: "/");
        if (result.IsRedirect && result.Location?.Contains("loginError") != true) Account = account;
        return result;
    }

    public async Task<HtmlPage> LogoutAsync()
    {
        var home = await BrowseAsync("/");
        var result = await PostRawAsync("/Account/Logout", Array.Empty<KeyValuePair<string, string>>(), home.AntiforgeryToken);
        Account = null;
        return result;
    }

    // ---------- patiënt: medicatieoverzicht ----------

    public async Task<MedicationOverview> GetMyPrescriptionsAsync()
    {
        var page = await GetAsync("/Prescriptions/MyPrescriptions");
        return new MedicationOverview(page);
    }

    // ---------- arts: voorschrijven ----------

    public async Task<HtmlPage> StartPrescriptionAsync(PrescriptionInput input) =>
        await PostFormAsync("/Prescriptions/New?handler=AddMedicine", input.Fields(), tokenFrom: "/Prescriptions/New");

    public async Task<HtmlPage> AddMedicineAsync(string? medicineId, string quantity, string instructions)
    {
        var fields = new Dictionary<string, string>
        {
            ["SelectedMedicineId"] = medicineId ?? "",
            ["Quantity"] = quantity,
            ["Instructions"] = instructions,
            ["action"] = "add"
        };
        return await PostFormAsync("/Prescriptions/AddMedicineToPrescription", fields);
    }

    public async Task<HtmlPage> ConfirmPrescriptionAsync(PrescriptionInput input) =>
        await PostFormAsync("/Prescriptions/New", input.Fields());

    /// <summary>Volledige flow: voorschrift openen, medicijnen toevoegen, bevestigen.</summary>
    public async Task<HtmlPage> PrescribeAsync(PrescriptionInput input, params MedicineLine[] medicines)
    {
        await StartPrescriptionAsync(input);
        foreach (var m in medicines)
            await AddMedicineAsync(m.MedicineId.ToString(), m.Quantity.ToString(), m.Instructions);
        return await ConfirmPrescriptionAsync(input);
    }

    // ---------- beheerder: gebruikers ----------

    public async Task<HtmlPage> ChangeRoleAsync(int userId, string newRole) =>
        await PostFormAsync("/Users?handler=ChangeRole",
            new Dictionary<string, string> { ["UserId"] = userId.ToString(), ["NewRole"] = newRole },
            tokenFrom: "/Users");

    public async Task<HtmlPage> DeleteUserAsync(int userId) =>
        await PostFormAsync("/Users?handler=Delete",
            new Dictionary<string, string> { ["UserId"] = userId.ToString() },
            tokenFrom: "/Users");

    public void Dispose() => _http.Dispose();

    private static async Task<HtmlPage> ToPage(string method, string url, HttpResponseMessage response)
    {
        var body = await response.Content.ReadAsStringAsync();
        return new HtmlPage(method, url, response.StatusCode, response.Headers.Location?.ToString(), body);
    }

    private static string StripQuery(string url) => url.Split('?')[0];

    private static string Shorten(string value) => value.Length > 40 ? value[..37] + "..." : value;
}

public sealed record MedicineLine(int MedicineId, int Quantity, string Instructions);

public sealed class PrescriptionInput
{
    public string PatientId { get; init; } = "";
    public DateTime Start { get; init; } = DateTime.Today;
    public DateTime End { get; init; } = DateTime.Today.AddDays(14);
    public string Description { get; init; } = "Voorschrift aangemaakt door testsuite";

    public Dictionary<string, string> Fields() => new()
    {
        ["Prescription.PatientID"] = PatientId,
        ["Prescription.PrescriptionStartDate"] = Start.ToString("yyyy-MM-dd"),
        ["Prescription.PrescriptionEndDate"] = End.ToString("yyyy-MM-dd"),
        ["Prescription.Description"] = Description
    };
}

/// <summary>Het medicatieoverzicht van de patiënt (MyPrescriptions), als lijst regels.</summary>
public sealed class MedicationOverview
{
    public MedicationOverview(HtmlPage page)
    {
        Page = page;
        Rows = page.QA("table table tbody tr")
            .Select(tr => tr.QuerySelectorAll("td").Select(td => td.TextContent.Trim()).ToArray())
            .Where(c => c.Length >= 5 && c[0] != "No medicines")
            .Select(c => new Row(c[0], c[1], c[2], c[3], c[4]))
            .ToList();
        Headers = page.QA("table table thead th").Select(th => th.TextContent.Trim()).Distinct().ToList();
    }

    public HtmlPage Page { get; }
    public List<Row> Rows { get; }
    public List<string> Headers { get; }
    public bool ShowsNoPrescriptionsMessage => Page.Contains("You have no current prescriptions");
    public bool HasMedicine(string tradeName) => Rows.Any(r => r.Medicine == tradeName);
    public Row? Find(string tradeName) => Rows.FirstOrDefault(r => r.Medicine == tradeName);

    public sealed record Row(string Medicine, string Strength, string Instructions, string Start, string End);
}
