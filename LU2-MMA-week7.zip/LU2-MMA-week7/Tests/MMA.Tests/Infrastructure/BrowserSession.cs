using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace MMA.Tests.Infrastructure;

/// <summary>
/// Eén browservenster (headless Chrome via Selenium) met acties zoals een gebruiker ze uitvoert:
/// pagina openen, typen, kiezen, klikken. Elke actie komt in de testlogging.
/// </summary>
public sealed class BrowserSession : IDisposable
{
    private readonly ChromeDriver _driver;
    private readonly WebDriverWait _wait;
    private readonly Action<string> _log;

    public BrowserSession(string baseUrl, TestSettings.BrowserSettings settings, Action<string> log, string name)
    {
        BaseUrl = baseUrl;
        Name = name;
        _log = log;
        var options = new ChromeOptions();
        if (settings.Headless) options.AddArgument("--headless=new");
        options.AddArguments($"--window-size={settings.WindowWidth},{settings.WindowHeight}", "--disable-gpu", "--no-first-run",
            "--disable-search-engine-choice-screen", "--lang=en-US");
        var service = ChromeDriverService.CreateDefaultService();
        service.HideCommandPromptWindow = true;
        service.SuppressInitialDiagnosticInformation = true;
        _driver = new ChromeDriver(service, options);
        _wait = new WebDriverWait(_driver, TimeSpan.FromSeconds(settings.TimeoutSeconds));
        _wait.IgnoreExceptionTypes(typeof(NoSuchElementException), typeof(StaleElementReferenceException));
    }

    public string BaseUrl { get; }
    public string Name { get; }
    public IWebDriver Driver => _driver;
    public string Path => new Uri(_driver.Url).PathAndQuery;
    public string Title => _driver.Title;

    // ---------- navigatie en acties ----------

    public void Open(string path)
    {
        _driver.Navigate().GoToUrl(BaseUrl + path);
        _log($"[{Name}] OPEN  {path}  => {Path} \"{Title}\"");
    }

    public void Type(string css, string text, string? label = null)
    {
        var e = Find(css);
        e.Clear();
        if (text.Length > 0) e.SendKeys(text);
        _log($"[{Name}] TYPE  {label ?? css} = \"{(css.Contains("Password", StringComparison.OrdinalIgnoreCase) ? "***" : text)}\"");
    }

    public void Select(string css, string value, string? label = null)
    {
        new SelectElement(Find(css)).SelectByValue(value);
        _log($"[{Name}] KIES  {label ?? css} = {value}");
    }

    public void SelectText(string css, string textStart, string? label = null)
    {
        var select = new SelectElement(Find(css));
        var option = select.Options.First(o => o.Text.Trim().StartsWith(textStart));
        select.SelectByText(option.Text);
        _log($"[{Name}] KIES  {label ?? css} = \"{option.Text.Trim()}\"");
    }

    /// <summary>Klik zonder paginawissel (bijvoorbeeld een dialoog openen).</summary>
    public void Click(IWebElement element, string label)
    {
        _wait.Until(_ => element.Displayed && element.Enabled);
        ScrollIntoView(element);
        element.Click();
        _log($"[{Name}] KLIK  {label}");
    }

    public void Click(string css, string? label = null) => Click(Find(css), label ?? css);

    /// <summary>Klik die een nieuwe pagina laadt; wacht tot de oude pagina weg is.</summary>
    public void ClickAndWait(IWebElement element, string label)
    {
        var html = _driver.FindElement(By.TagName("html"));
        _wait.Until(_ => element.Displayed && element.Enabled);
        ScrollIntoView(element);
        element.Click();
        _wait.Until(_ => IsStale(html));
        _wait.Until(d => ((IJavaScriptExecutor)d).ExecuteScript("return document.readyState")?.ToString() == "complete");
        _log($"[{Name}] KLIK  {label}  => {Path} \"{Title}\"");
    }

    public void ClickAndWait(string css, string? label = null) => ClickAndWait(Find(css), label ?? css);

    public IWebElement ButtonWithText(string text, string scope = "") =>
        _wait.Until(d => d.FindElements(By.XPath($"{scope}//*[self::button or self::a][normalize-space()='{text}']")).FirstOrDefault(e => e.Displayed));

    // ---------- lezen ----------

    public IWebElement Find(string css) => _wait.Until(d => d.FindElement(By.CssSelector(css)));
    public IWebElement FindXPath(string xpath) => _wait.Until(d => d.FindElement(By.XPath(xpath)));
    public bool Exists(string css) => _driver.FindElements(By.CssSelector(css)).Any(e => e.Displayed);
    public IReadOnlyCollection<IWebElement> All(string css) => _driver.FindElements(By.CssSelector(css));
    public string Text(string css) => Exists(css) ? Find(css).Text.Trim() : "";
    public string Value(string css) => Find(css).GetDomProperty("value") ?? "";
    public bool WaitUntil(Func<bool> condition)
    {
        try { return _wait.Until(_ => condition()); }
        catch (WebDriverTimeoutException) { return false; }
    }

    /// <summary>Rijen van de eerste tabel die aan de selector voldoet, als tekst per cel.</summary>
    public List<string[]> Rows(string tableCss) =>
        _driver.FindElements(By.CssSelector($"{tableCss} tbody tr"))
            .Select(tr => tr.FindElements(By.TagName("td")).Select(td => td.Text.Trim()).ToArray())
            .Where(c => c.Length > 0)
            .ToList();

    // ---------- vaste gebruikersacties ----------

    public void Login(string username, string password)
    {
        Open("/");
        Type("#Username", username, "Username");
        Type("#Password", password, "Password");
        ClickAndWait("button[name=btn-login]", "Login");
    }

    public string LoggedInUser => Text("[name=user_name]");

    public void Logout() => ClickAndWait("button[name=btn_logout]", "Log Out");

    public void Screenshot(string file)
    {
        Directory.CreateDirectory(System.IO.Path.GetDirectoryName(file)!);
        _driver.GetScreenshot().SaveAsFile(file);
    }

    public void Dispose()
    {
        try { _driver.Quit(); } catch { /* browser al gesloten */ }
        _driver.Dispose();
    }

    /// <summary>De vaste voettekst kan knoppen onderaan bedekken; daarom eerst naar het midden scrollen.</summary>
    private void ScrollIntoView(IWebElement element) =>
        ((IJavaScriptExecutor)_driver).ExecuteScript("arguments[0].scrollIntoView({block: 'center'});", element);

    private static bool IsStale(IWebElement element)
    {
        try
        {
            _ = element.Enabled;
            return false;
        }
        catch (StaleElementReferenceException)
        {
            return true;
        }
        catch (WebDriverException)
        {
            // Chrome meldt een element van een vervangen pagina soms als "Node ... does not belong to the document"
            return true;
        }
    }
}
