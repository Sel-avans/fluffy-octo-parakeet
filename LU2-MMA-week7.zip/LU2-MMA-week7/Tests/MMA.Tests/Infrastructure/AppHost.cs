using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace MMA.Tests.Infrastructure;

/// <summary>
/// Start de opgeleverde applicatie als echte webserver (Kestrel, eigen proces) voor de Selenium-tests.
/// Een browser kan niet met de in-process testserver praten, daarom draait de applicatie hier op een vrije poort.
/// De applicatie gebruikt dezelfde testdatabase als de rest van de testrun en wordt na de run gestopt.
/// </summary>
public sealed class AppHost : IDisposable
{
    private readonly Process _process;
    private readonly StringBuilder _output = new();
    private readonly string _outputFile;

    private AppHost(Process process, string baseUrl, string outputFile)
    {
        _process = process;
        BaseUrl = baseUrl;
        _outputFile = outputFile;
    }

    public string BaseUrl { get; }

    public static async Task<AppHost> StartAsync(string sutDir, string assemblyName, string connectionString,
        string environment, string resultsDir, Action<string> log)
    {
        var dll = FindBuiltApplication(sutDir, assemblyName);
        var port = FreePort();
        var baseUrl = $"http://127.0.0.1:{port}";
        var psi = new ProcessStartInfo("dotnet", $"\"{dll}\" --urls {baseUrl} --contentRoot \"{sutDir}\"")
        {
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true,
            WorkingDirectory = sutDir
        };
        psi.Environment["ConnectionStrings__DefaultConnection"] = connectionString;
        psi.Environment["ASPNETCORE_ENVIRONMENT"] = environment;

        log($"Applicatie starten voor browsertests: {Path.GetFileName(dll)} op {baseUrl}");
        var process = Process.Start(psi) ?? throw new InvalidOperationException("Kon de applicatie niet starten");
        var host = new AppHost(process, baseUrl, Path.Combine(resultsDir, "applicatie-output.log"));
        process.OutputDataReceived += (_, e) => { if (e.Data != null) lock (host._output) host._output.AppendLine(e.Data); };
        process.ErrorDataReceived += (_, e) => { if (e.Data != null) lock (host._output) host._output.AppendLine(e.Data); };
        process.BeginOutputReadLine();
        process.BeginErrorReadLine();

        using var http = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false }) { Timeout = TimeSpan.FromSeconds(5) };
        var deadline = DateTime.Now.AddSeconds(90);
        while (DateTime.Now < deadline)
        {
            if (process.HasExited)
                throw new InvalidOperationException($"De applicatie stopte direct (exitcode {process.ExitCode}):\n{host.Output}");
            try
            {
                var response = await http.GetAsync(baseUrl + "/");
                if ((int)response.StatusCode < 500)
                {
                    log($"Applicatie bereikbaar op {baseUrl} (proces {process.Id})");
                    return host;
                }
            }
            catch (HttpRequestException) { }
            catch (TaskCanceledException) { }
            await Task.Delay(500);
        }
        host.Dispose();
        throw new TimeoutException($"De applicatie werd niet bereikbaar op {baseUrl}:\n{host.Output}");
    }

    public string Output
    {
        get { lock (_output) return _output.ToString(); }
    }

    public void Dispose()
    {
        try
        {
            if (!_process.HasExited) _process.Kill(entireProcessTree: true);
            _process.WaitForExit(10_000);
        }
        catch { /* proces is al gestopt */ }
        try { File.WriteAllText(_outputFile, Output); } catch { /* logging is best effort */ }
        _process.Dispose();
    }

    /// <summary>De gebouwde applicatie (bin\...\&lt;naam&gt;.dll) met runtimeconfig, zodat 'dotnet &lt;dll&gt;' werkt.</summary>
    private static string FindBuiltApplication(string sutDir, string assemblyName) =>
        Directory.EnumerateFiles(Path.Combine(sutDir, "bin"), assemblyName + ".dll", SearchOption.AllDirectories)
            .Where(f => File.Exists(Path.ChangeExtension(f, ".runtimeconfig.json")))
            .OrderByDescending(File.GetLastWriteTime)
            .FirstOrDefault()
        ?? throw new FileNotFoundException($"{assemblyName}.dll niet gevonden onder {sutDir}\\bin; bouw eerst de solution.");

    private static int FreePort()
    {
        var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        var port = ((IPEndPoint)listener.LocalEndpoint).Port;
        listener.Stop();
        return port;
    }
}
