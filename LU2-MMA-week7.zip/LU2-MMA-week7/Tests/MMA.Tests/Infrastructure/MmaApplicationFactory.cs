using LU2_software_testen.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;

namespace MMA.Tests.Infrastructure;

/// <summary>
/// Start de echte applicatie (Program.cs, middleware, Razor Pages, EF Core) in het testproces,
/// gekoppeld aan een eigen, lege SQL Server LocalDB-database per testrun.
/// De applicatiecode wordt niet aangepast: alleen de connection string en de omgeving worden overschreven.
/// </summary>
public sealed class MmaApplicationFactory : WebApplicationFactory<AppDbContext>
{
    private readonly string _connectionString;
    private readonly string _environment;

    public MmaApplicationFactory(string connectionString, string environment)
    {
        _connectionString = connectionString;
        _environment = environment;
        // Program.cs leest de connection string tijdens het opbouwen van de host; een omgevingsvariabele
        // is daarom de betrouwbaarste manier om de applicatie naar de testdatabase te laten wijzen.
        Environment.SetEnvironmentVariable("ConnectionStrings__DefaultConnection", connectionString);
    }

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment(_environment);
        builder.UseSetting("ConnectionStrings:DefaultConnection", _connectionString);
    }

    public HttpClient CreateBrowserClient() => CreateClient(new WebApplicationFactoryClientOptions
    {
        AllowAutoRedirect = false,
        HandleCookies = true,
        BaseAddress = new Uri("http://localhost")
    });
}
