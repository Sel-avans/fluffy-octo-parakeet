using System.Diagnostics;
using System.Reflection;
using System.Security.Cryptography;

namespace MMA.Tests.Infrastructure;

/// <summary>
/// Legt per testrun vast welke versie van de software is getest:
/// label, git-commit (plus lokale wijzigingen), assemblyversie en een vingerafdruk van de gebouwde DLL.
/// </summary>
public sealed class SutVersion
{
    public string Label { get; init; } = "";
    public string GitCommit { get; init; } = "onbekend";
    public string GitCommitMessage { get; init; } = "";
    public string GitCommitDate { get; init; } = "";
    public string GitBranch { get; init; } = "";
    public int LocalChanges { get; init; }
    public List<string> LocalChangedFiles { get; init; } = new();
    public string AssemblyName { get; init; } = "";
    public string AssemblyVersion { get; init; } = "";
    public string BuildFingerprint { get; init; } = "";
    public DateTime BuildTime { get; init; }

    /// <summary>Vingerafdruk van de broncode (.cs, .cshtml, .csproj, appsettings); werkt ook zonder git.</summary>
    public string SourceFingerprint { get; init; } = "";
    public int SourceFiles { get; init; }

    public string Summary =>
        $"{Label} | commit {GitCommit} ({GitCommitMessage}){(LocalChanges > 0 ? $" + {LocalChanges} lokale wijziging(en)" : "")} | " +
        $"{AssemblyName} {AssemblyVersion} | build {BuildFingerprint} ({BuildTime:yyyy-MM-dd HH:mm:ss})";

    public static SutVersion Detect(Assembly sutAssembly, string sutDir, string label)
    {
        var dll = sutAssembly.Location;
        string fingerprint;
        using (var stream = File.OpenRead(dll))
            fingerprint = Convert.ToHexString(SHA256.HashData(stream))[..12].ToLowerInvariant();

        // Wijzigingen aan de testomgeving zelf (map Tests\ en de uitsluiting in het csproj) tellen niet als wijziging aan de software.
        var changed = Git(sutDir, "status --porcelain")
            .Split('\n', StringSplitOptions.RemoveEmptyEntries)
            .Select(l => l.TrimEnd())
            .Where(l => !l.Contains("Tests/"))
            .ToList();

        var sources = SourceFilesOf(sutDir);
        string sourceHash;
        using (var sha = SHA256.Create())
        {
            foreach (var file in sources)
            {
                var name = System.Text.Encoding.UTF8.GetBytes(Path.GetRelativePath(sutDir, file).Replace('\\', '/'));
                sha.TransformBlock(name, 0, name.Length, null, 0);
                var content = File.ReadAllBytes(file);
                sha.TransformBlock(content, 0, content.Length, null, 0);
            }
            sha.TransformFinalBlock(Array.Empty<byte>(), 0, 0);
            sourceHash = Convert.ToHexString(sha.Hash!)[..12].ToLowerInvariant();
        }

        return new SutVersion
        {
            SourceFingerprint = sourceHash,
            SourceFiles = sources.Count,
            Label = label,
            GitCommit = Git(sutDir, "rev-parse --short HEAD").Trim() is { Length: > 0 } c ? c : "onbekend",
            GitCommitMessage = Git(sutDir, "log -1 --format=%s").Trim(),
            GitCommitDate = Git(sutDir, "log -1 --format=%ci").Trim(),
            GitBranch = Git(sutDir, "rev-parse --abbrev-ref HEAD").Trim(),
            LocalChanges = changed.Count,
            LocalChangedFiles = changed,
            AssemblyName = sutAssembly.GetName().Name ?? "",
            AssemblyVersion = sutAssembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion
                              ?? sutAssembly.GetName().Version?.ToString() ?? "",
            BuildFingerprint = fingerprint,
            BuildTime = File.GetLastWriteTime(dll)
        };
    }

    private static List<string> SourceFilesOf(string sutDir)
    {
        var skip = new[] { "bin", "obj", "Tests", ".vs", ".git", "wwwroot" };
        return Directory.EnumerateFiles(sutDir, "*", SearchOption.AllDirectories)
            .Where(f => !Path.GetRelativePath(sutDir, f).Split(Path.DirectorySeparatorChar).Any(skip.Contains))
            .Where(f => f.EndsWith(".cs") || f.EndsWith(".cshtml") || f.EndsWith(".csproj") || Path.GetFileName(f).StartsWith("appsettings"))
            .OrderBy(f => f, StringComparer.Ordinal)
            .ToList();
    }

    private static string Git(string dir, string args)
    {
        try
        {
            var psi = new ProcessStartInfo("git", $"-C \"{dir}\" {args}")
            {
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };
            using var p = Process.Start(psi)!;
            var output = p.StandardOutput.ReadToEnd();
            p.WaitForExit(10_000);
            return p.ExitCode == 0 ? output : "";
        }
        catch
        {
            return "";
        }
    }
}
