using System.Security.Cryptography;
using System.Text;
using LU2_software_testen.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace MMA.Tests.Infrastructure;

public sealed record TestAccount(int Id, string Username, string Password, string Email, UserRoleType Role);

[CollectionDefinition(Name)]
public sealed class MmaCollection : ICollectionFixture<TestEnvironment>
{
    // Alle testcases delen één applicatie-instantie en database en draaien na elkaar.
    public const string Name = "Medicine Management Application";
}

/// <summary>
/// De testomgeving voor één testrun: start de applicatie met een lege testdatabase, zet de vaste
/// testaccounts klaar, verzorgt de logging en schrijft na afloop het testrapport.
/// </summary>
public sealed class TestEnvironment : IAsyncLifetime
{
    private int _userCounter;
    private string _sutDir = "";
    private string _connectionString = "";
    private AppHost? _appHost;
    private readonly SemaphoreSlim _appHostLock = new(1, 1);

    public TestSettings Settings { get; } = JsonFiles.Load<TestSettings>("testsettings.json");
    public TestDataFile Data { get; } = JsonFiles.Load<TestDataFile>(Path.Combine("TestData", "testdata.json"));
    public AcceptanceCatalog Catalog { get; } = JsonFiles.Load<AcceptanceCatalog>(Path.Combine("TestData", "acceptatiecriteria.json"));
    public DefectRegister Defects { get; private set; } = new();

    public string RunId { get; } = Environment.GetEnvironmentVariable("MMA_RUN_ID") is { Length: > 0 } id
        ? id
        : DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss");

    public string DatabaseName { get; private set; } = "";
    public MmaApplicationFactory Factory { get; private set; } = null!;
    public TestRunLog Log { get; private set; } = null!;
    public SutVersion Sut { get; private set; } = null!;
    public Dictionary<string, TestAccount> Accounts { get; } = new();

    public TestAccount Beheerder => Accounts["beheerder"];
    public TestAccount Huisarts => Accounts["huisarts"];
    public TestAccount Specialist => Accounts["specialist"];
    public TestAccount Apotheker => Accounts["apotheker"];
    public TestAccount Verzekeraar => Accounts["verzekeraar"];

    public string ResultsRoot => Path.Combine(Paths.TestsRoot, Settings.Results.FolderName);

    public async Task InitializeAsync()
    {
        var sutDir = _sutDir = Paths.SutDir(Settings.Sut.ProjectFile);
        DatabaseName = $"{Settings.Database.NamePrefix}_{RunId.Replace("-", "").Replace("_", "")}";
        var connectionString = _connectionString = string.Format(Settings.Database.ConnectionStringTemplate, DatabaseName);

        Log = new TestRunLog(RunId, Path.Combine(ResultsRoot, RunId));
        Sut = SutVersion.Detect(typeof(AppDbContext).Assembly, sutDir, Settings.Sut.VersionLabel);
        Log.Header(Sut, DatabaseName);

        var defectsFile = Path.Combine(AppContext.BaseDirectory, "TestData", "bevindingen.json");
        if (File.Exists(defectsFile)) Defects = JsonFiles.Load<DefectRegister>(Path.Combine("TestData", "bevindingen.json"));

        // Applicatie starten: Program.cs voert de migraties en de eigen seed-data (rollen, admin, medicijnen) uit.
        Factory = new MmaApplicationFactory(connectionString, Settings.Sut.Environment);
        _ = Factory.Server;

        await WithDbAsync(async db =>
        {
            var actual = db.Database.GetConnectionString() ?? "";
            if (!actual.Contains(DatabaseName))
                throw new InvalidOperationException($"De applicatie gebruikt niet de testdatabase maar: {actual}");
            Log.Line($"Applicatie gestart; testdatabase {DatabaseName} aangemaakt en gevuld door de applicatie.");
            Log.Line($"Seed-data applicatie: {await db.UserRoles.CountAsync()} rollen, {await db.Users.CountAsync()} gebruiker(s), {await db.Medicines.CountAsync()} medicijnen.");
        });

        foreach (var (key, account) in Data.Accounts)
        {
            var role = Enum.Parse<UserRoleType>(account.Role);
            var id = account.SeededBySut
                ? await WithDbAsync(db => db.Users.Where(u => u.Username == account.Username).Select(u => u.UserID).SingleAsync())
                : await InsertUserAsync(account.Username, account.Password, account.Email, account.Phone, role);
            Accounts[key] = new TestAccount(id, account.Username, account.Password, account.Email, role);
            Log.Line($"Testaccount '{key}': {account.Username} (id {id}, rol {role}{(account.SeededBySut ? ", aangemaakt door applicatie" : "")})");
        }
        Log.Line();
    }

    public async Task DisposeAsync()
    {
        Log.Finish();
        try
        {
            ReportWriter.Write(this);
        }
        finally
        {
            if (!Settings.Database.KeepAfterRun)
                await WithDbAsync(db => db.Database.EnsureDeletedAsync());
            _appHost?.Dispose();
            await Factory.DisposeAsync();
            Log.Dispose();
        }
    }

    // ---------- sessies ----------

    /// <summary>
    /// Adres van de applicatie als echte webserver voor Selenium. Wordt pas gestart bij de eerste browsertest
    /// en gebruikt dezelfde testdatabase en testaccounts als de rest van de run.
    /// </summary>
    public async Task<string> AppUrlAsync()
    {
        await _appHostLock.WaitAsync();
        try
        {
            _appHost ??= await AppHost.StartAsync(_sutDir, typeof(AppDbContext).Assembly.GetName().Name!, _connectionString,
                Settings.Sut.Environment, Log.ResultsDir, text => Log.Line("[omgeving] " + text));
            return _appHost.BaseUrl;
        }
        finally
        {
            _appHostLock.Release();
        }
    }

    public MmaClient NewSession(TestRecord record, string name) =>
        new(Factory.CreateBrowserClient(), text => Log.Step(record, "HTTP", text), name);

    // ---------- testdata klaarzetten (direct in de database, alleen voor de 'Gegeven'-situatie) ----------

    public async Task<TestAccount> CreateUserAsync(string prefix, UserRoleType role)
    {
        var n = Interlocked.Increment(ref _userCounter);
        var username = $"{prefix}_{n:000}";
        var template = Data.NieuweGebruiker;
        var email = $"{username}@{template.EmailDomain}";
        var id = await InsertUserAsync(username, template.Password, email, template.Phone, role);
        return new TestAccount(id, username, template.Password, email, role);
    }

    public async Task<int> MedicineIdAsync(string tradeName) =>
        await WithDbAsync(db => db.Medicines.Where(m => m.TradeName == tradeName && !m.IsDeleted).OrderBy(m => m.MedicineID).Select(m => m.MedicineID).FirstAsync());

    /// <summary>Zet een eigen medicijn klaar (unieke handelsnaam), zodat wijzigen/verwijderen de seed-data niet raakt.</summary>
    public async Task<(int Id, string TradeName)> ArrangeMedicineAsync(string prefix, string substance = "Testosubstantie", string strength = "10mg")
    {
        var tradeName = $"{prefix}_{Interlocked.Increment(ref _userCounter):000}";
        var id = await WithDbAsync(async db =>
        {
            var m = new Medicine
            {
                TradeName = tradeName,
                ActiveSubstances = new List<string> { substance },
                Strength = strength,
                DosageForm = (int)DosageFormType.Tablet,
                StockStatus = (int)StockStatusType.Available
            };
            db.Medicines.Add(m);
            await db.SaveChangesAsync();
            return m.MedicineID;
        });
        return (id, tradeName);
    }

    public async Task<Medicine?> MedicineAsync(int id) =>
        await WithDbAsync(db => db.Medicines.AsNoTracking().FirstOrDefaultAsync(m => m.MedicineID == id));

    public async Task<Medicine?> MedicineByNameAsync(string tradeName) =>
        await WithDbAsync(db => db.Medicines.AsNoTracking().FirstOrDefaultAsync(m => m.TradeName == tradeName));

    public async Task<int> ArrangePrescriptionAsync(TestAccount patient, TestAccount prescriber, DateTime start, DateTime end,
        params (string TradeName, int Quantity, string Instructions)[] medicines)
    {
        var ids = new List<int>();
        foreach (var m in medicines) ids.Add(await MedicineIdAsync(m.TradeName));

        return await WithDbAsync(async db =>
        {
            var p = new Prescription
            {
                PatientID = patient.Id,
                PrescriberID = prescriber.Id,
                PrescriptionDate = DateTime.Today,
                PrescriptionStartDate = start,
                PrescriptionEndDate = end,
                Description = "Klaargezet door testomgeving"
            };
            db.Prescriptions.Add(p);
            await db.SaveChangesAsync();
            for (var i = 0; i < medicines.Length; i++)
                db.PrescriptionMedicines.Add(new PrescriptionMedicine
                {
                    PrescriptionID = p.Id,
                    MedicineID = ids[i],
                    Quantity = medicines[i].Quantity,
                    Instructions = medicines[i].Instructions
                });
            await db.SaveChangesAsync();
            return p.Id;
        });
    }

    // ---------- database controleren ----------

    public async Task<T> WithDbAsync<T>(Func<AppDbContext, Task<T>> action)
    {
        using var scope = Factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        return await action(db);
    }

    public async Task WithDbAsync(Func<AppDbContext, Task> action) =>
        await WithDbAsync(async db => { await action(db); return true; });

    public async Task<List<Prescription>> PrescriptionsOfAsync(int patientId) =>
        await WithDbAsync(db => db.Prescriptions.Where(p => p.PatientID == patientId).AsNoTracking().ToListAsync());

    public async Task<List<PrescriptionMedicine>> PrescriptionLinesAsync(int prescriptionId) =>
        await WithDbAsync(db => db.PrescriptionMedicines.Where(pm => pm.PrescriptionID == prescriptionId).AsNoTracking().ToListAsync());

    public async Task<UserRoleType?> RoleOfAsync(int userId) =>
        await WithDbAsync(async db =>
        {
            var u = await db.Users.AsNoTracking().FirstOrDefaultAsync(x => x.UserID == userId);
            return u == null ? (UserRoleType?)null : (UserRoleType)u.UserRoleID;
        });

    // ---------- logbestand van de applicatie ----------

    /// <summary>Het logbestand van vandaag, zoals de applicatie het schrijft (Utils/Logger.cs).</summary>
    public string TodaysLogFileName => $"log_{DateTime.Now:yyyyMMdd}.txt";

    public string TodaysLogFilePath => Path.Combine(AppContext.BaseDirectory, "Logs", TodaysLogFileName);

    public int LogLineCount() => File.Exists(TodaysLogFilePath) ? ReadLogLines().Length : 0;

    public string[] ReadLogLines()
    {
        using var stream = new FileStream(TodaysLogFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        using var reader = new StreamReader(stream);
        return reader.ReadToEnd().Split(Environment.NewLine, StringSplitOptions.RemoveEmptyEntries);
    }

    private async Task<int> InsertUserAsync(string username, string password, string email, string phone, UserRoleType role) =>
        await WithDbAsync(async db =>
        {
            var user = new User
            {
                Username = username,
                PasswordHash = HashLikeApplication(password),
                Email = email,
                PhoneNumber = phone,
                UserRoleID = (int)role
            };
            db.Users.Add(user);
            await db.SaveChangesAsync();
            return user.UserID;
        });

    /// <summary>Zelfde hash als de applicatie (Login/Register): SHA-256, Base64.</summary>
    public static string HashLikeApplication(string password) =>
        Convert.ToBase64String(SHA256.HashData(Encoding.UTF8.GetBytes(password)));
}
