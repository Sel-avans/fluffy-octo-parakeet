using Xunit.Abstractions;
using Xunit.Sdk;

namespace MMA.Tests.Infrastructure;

public enum Soort
{
    Positief,
    Negatief,
    Alternatief,
    /// <summary>Verkennende test buiten de acceptatiecriteria; legt gedrag vast zonder te falen.</summary>
    Observatie
}

/// <summary>
/// Koppelt een testmethode aan een testcase-ID en een acceptatiecriterium.
/// Is ook een xUnit-trait, zodat je kunt filteren: dotnet test --filter "AC=AC-4.1" of "Story=25".
/// Gebruik criterium "EXTRA" voor aanvullende tests buiten de acceptatiecriteria (geef dan Story op).
/// </summary>
[TraitDiscoverer("MMA.Tests.Infrastructure.TestcaseTraitDiscoverer", "MMA.Tests")]
[AttributeUsage(AttributeTargets.Method)]
public sealed class TestcaseAttribute : Attribute, ITraitAttribute
{
    public TestcaseAttribute(string id, string criterium, string titel)
    {
        Id = id;
        Criterium = criterium;
        Titel = titel;
    }

    public string Id { get; }
    public string Criterium { get; }
    public string Titel { get; }
    public Soort Soort { get; set; } = Soort.Positief;
    public string Scenario { get; set; } = "";

    /// <summary>Storynummer (deel 1). Wordt afgeleid uit het criterium als dat de vorm AC-x.y heeft.</summary>
    public int Story { get; set; }

    public int StoryNumber => Story != 0 ? Story : DeriveStory(Criterium);

    public static int DeriveStory(string criterium)
    {
        var part = criterium.StartsWith("AC-") ? criterium[3..].Split('.')[0] : "";
        return int.TryParse(part, out var n) ? n : 0;
    }
}

public sealed class TestcaseTraitDiscoverer : ITraitDiscoverer
{
    public IEnumerable<KeyValuePair<string, string>> GetTraits(IAttributeInfo traitAttribute)
    {
        var args = traitAttribute.GetConstructorArguments().Cast<string>().ToList();
        var story = traitAttribute.GetNamedArgument<int>(nameof(TestcaseAttribute.Story));
        if (story == 0) story = TestcaseAttribute.DeriveStory(args[1]);

        yield return new("TC", args[0]);
        yield return new("AC", args[1]);
        yield return new("Story", story.ToString());
        yield return new("Soort", traitAttribute.GetNamedArgument<Soort>(nameof(TestcaseAttribute.Soort)).ToString());
    }
}
