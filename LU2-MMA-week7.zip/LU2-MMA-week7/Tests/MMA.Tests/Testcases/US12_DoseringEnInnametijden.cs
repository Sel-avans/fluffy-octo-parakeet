using MMA.Tests.Infrastructure;
using Xunit;

namespace MMA.Tests.Testcases;

/// <summary>Opdracht nr. 8 / deel 1 nr. 12: Als arts wil ik dosering en innametijden per patiënt kunnen instellen.</summary>
public sealed class US12_DoseringEnInnametijden(TestEnvironment env) : MmaTestBase(env)
{
    private const string Instructie = "1 tablet van 500mg, 3x per dag om 08:00, 14:00 en 20:00, na het eten";

    [Fact, Testcase("TC-12.1-01", "AC-12.1", "Arts legt dosering, frequentie, innametijden en periode vast; alles wordt ongewijzigd opgeslagen",
        Scenario = "TS-12.1 Dosering en innametijden vastleggen (hoofdflow)")]
    public Task TC_12_1_01() => Run(async t =>
    {
        var patient = await t.NewPatient("dosering");
        var doctor = await t.LoggedInAs(Env.Huisarts);
        var start = DateTime.Today;
        var end = DateTime.Today.AddDays(10);
        var id = await Env.MedicineIdAsync(t.Data.Medicijn("pijnstiller"));
        var input = new PrescriptionInput { PatientId = patient.Id.ToString(), Start = start, End = end, Description = "Pijnbestrijding" };

        t.Step("Scherm 'Add Medicine' bevat velden voor hoeveelheid en instructies");
        await doctor.StartPrescriptionAsync(input);
        var form = await doctor.GetAsync("/Prescriptions/AddMedicineToPrescription");
        var fields = form.QA("input, select").Select(e => e.GetAttribute("name")).Where(n => n != null).ToList();
        t.Info("Invoervelden: " + string.Join(", ", fields));
        t.Check(fields.Contains("Quantity") && fields.Contains("Instructions"), "Velden voor dosering aanwezig", "Quantity en Instructions", string.Join(", ", fields));

        t.Step($"Medicijn toevoegen met instructie \"{Instructie}\" en bevestigen");
        await doctor.AddMedicineAsync(id.ToString(), "30", Instructie);
        await doctor.ConfirmPrescriptionAsync(input);

        var stored = await Env.PrescriptionsOfAsync(patient.Id);
        t.Check(stored.Count == 1, "Voorschrift opgeslagen", "1", stored.Count.ToString());
        var p = stored[0];
        t.Check(p.PrescriptionStartDate == start && p.PrescriptionEndDate == end, "Periode opgeslagen",
            $"{start:yyyy-MM-dd} t/m {end:yyyy-MM-dd}", $"{p.PrescriptionStartDate:yyyy-MM-dd} t/m {p.PrescriptionEndDate:yyyy-MM-dd}");
        var line = (await Env.PrescriptionLinesAsync(p.Id)).Single();
        t.Check(line.Quantity == 30, "Hoeveelheid opgeslagen", "30", line.Quantity.ToString());
        t.Check(line.Instructions == Instructie, "Dosering/frequentie/innametijden opgeslagen", Instructie, line.Instructions);
    });

    [Fact, Testcase("TC-12.1-02", "AC-12.1", "Dosering is per patiënt in te stellen: twee patiënten krijgen hetzelfde medicijn met een andere dosering",
        Soort = Soort.Alternatief, Scenario = "TS-12.2 Dosering per patiënt")]
    public Task TC_12_1_02() => Run(async t =>
    {
        var p1 = await t.NewPatient("dosis_p1");
        var p2 = await t.NewPatient("dosis_p2");
        var id = await Env.MedicineIdAsync(t.Data.Medicijn("ontstekingsremmer"));
        var doctor = await t.LoggedInAs(Env.Specialist);

        t.Step("Patiënt 1: 1x per dag om 08:00; patiënt 2: 3x per dag om 08:00, 14:00, 20:00");
        await doctor.PrescribeAsync(new PrescriptionInput { PatientId = p1.Id.ToString() }, new MedicineLine(id, 10, "1 tablet 1x per dag om 08:00"));
        await doctor.PrescribeAsync(new PrescriptionInput { PatientId = p2.Id.ToString() }, new MedicineLine(id, 30, "1 tablet 3x per dag om 08:00, 14:00, 20:00"));

        var l1 = (await Env.PrescriptionLinesAsync((await Env.PrescriptionsOfAsync(p1.Id)).Single().Id)).Single();
        var l2 = (await Env.PrescriptionLinesAsync((await Env.PrescriptionsOfAsync(p2.Id)).Single().Id)).Single();
        t.Check(l1.Instructions == "1 tablet 1x per dag om 08:00" && l1.Quantity == 10, "Instelling patiënt 1", "10 / 1x per dag om 08:00", $"{l1.Quantity} / {l1.Instructions}");
        t.Check(l2.Instructions == "1 tablet 3x per dag om 08:00, 14:00, 20:00" && l2.Quantity == 30, "Instelling patiënt 2", "30 / 3x per dag", $"{l2.Quantity} / {l2.Instructions}");
    });

    [Fact, Testcase("TC-12.2-01", "AC-12.2", "Opgeslagen dosering en innametijden zijn zichtbaar in het medicatieoverzicht van de patiënt",
        Scenario = "TS-12.3 Instellingen zichtbaar voor patiënt")]
    public Task TC_12_2_01() => Run(async t =>
    {
        var patient = await t.NewPatient("zichtbaar");
        var trade = t.Data.Medicijn("pijnstiller");
        var doctor = await t.LoggedInAs(Env.Huisarts);
        t.Step("Arts legt voorschrift vast via het scherm");
        await doctor.PrescribeAsync(new PrescriptionInput { PatientId = patient.Id.ToString(), End = DateTime.Today.AddDays(5) },
            new MedicineLine(await Env.MedicineIdAsync(trade), 15, Instructie));

        var s = await t.LoggedInAs(patient);
        var overview = await s.GetMyPrescriptionsAsync();
        var row = overview.Find(trade);
        t.Check(row != null, "Medicijn in overzicht patiënt", trade, row?.Medicine ?? "niet gevonden");
        t.Check(row!.Instructions == Instructie, "Dosering en innametijden zichtbaar", Instructie, row.Instructions);
        t.Check(row.Strength == "500mg", "Sterkte zichtbaar", "500mg", row.Strength);
    });

    [Fact, Testcase("TC-12.2-02", "AC-12.2", "De ingestelde periode (start- en einddatum) is zichtbaar voor de patiënt",
        Soort = Soort.Alternatief, Scenario = "TS-12.3 Instellingen zichtbaar voor patiënt")]
    public Task TC_12_2_02() => Run(async t =>
    {
        var patient = await t.NewPatient("periode_zicht");
        var trade = t.Data.Medicijn("maagbeschermer");
        var start = DateTime.Today;
        var end = DateTime.Today.AddDays(28);
        var doctor = await t.LoggedInAs(Env.Huisarts);
        await doctor.PrescribeAsync(new PrescriptionInput { PatientId = patient.Id.ToString(), Start = start, End = end },
            new MedicineLine(await Env.MedicineIdAsync(trade), 28, "1 capsule per dag voor het ontbijt"));

        var s = await t.LoggedInAs(patient);
        var row = (await s.GetMyPrescriptionsAsync()).Find(trade);
        t.Check(row != null, "Medicijn in overzicht", trade, row?.Medicine ?? "niet gevonden");
        t.Check(row!.Start == start.ToShortDateString() && row.End == end.ToShortDateString(), "Periode zichtbaar",
            $"{start.ToShortDateString()} - {end.ToShortDateString()}", $"{row.Start} - {row.End}");
    });

    [Fact, Testcase("EXT-12-01", ReportWriter.Extra, "Innametijden worden als vrije tekst ingevoerd zonder controle op geldigheid",
        Story = 12, Soort = Soort.Observatie, Scenario = "Verkennend: structuur en validatie van innametijden")]
    public Task EXT_12_01() => Run(async t =>
    {
        var patient = await t.NewPatient("vrije_tekst");
        var doctor = await t.LoggedInAs(Env.Huisarts);
        var input = new PrescriptionInput { PatientId = patient.Id.ToString() };
        await doctor.StartPrescriptionAsync(input);
        var form = await doctor.GetAsync("/Prescriptions/AddMedicineToPrescription");
        var timeFields = form.QA("input[type=time], select[name*=Frequen], input[name*=Frequen], input[name*=Time]").Count();
        t.Observe($"Aparte velden voor frequentie/innametijd: {timeFields}. Alleen 'Quantity' (getal) en 'Instructions' (vrije tekst, max. 300 tekens in de browser).");

        var longText = new string('x', 450);
        await doctor.AddMedicineAsync((await Env.MedicineIdAsync(t.Data.Medicijn("pijnstiller"))).ToString(), "1", "om 25:99 uur innemen " + longText);
        await doctor.ConfirmPrescriptionAsync(input);
        var stored = await Env.PrescriptionsOfAsync(patient.Id);
        var length = stored.Count == 0 ? 0 : (await Env.PrescriptionLinesAsync(stored[0].Id)).Single().Instructions.Length;
        t.Observe(stored.Count == 0
            ? "Ongeldige innametijd en te lange tekst worden door de server geweigerd."
            : $"Ongeldige innametijd ('25:99') en een instructie van {length} tekens (meer dan de 300 van het scherm) worden zonder melding opgeslagen.");
    });
}
