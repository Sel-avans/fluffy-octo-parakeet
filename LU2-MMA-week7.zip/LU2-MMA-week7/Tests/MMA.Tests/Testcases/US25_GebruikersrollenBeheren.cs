using LU2_software_testen.Models;
using MMA.Tests.Infrastructure;
using Xunit;

namespace MMA.Tests.Testcases;

/// <summary>Opdracht nr. 20 / deel 1 nr. 25: Als beheerder wil ik gebruikersrollen kunnen beheren (patiënt, arts, apotheker).</summary>
public sealed class US25_GebruikersrollenBeheren(TestEnvironment env) : MmaTestBase(env)
{
    private static string SelectedRole(HtmlPage usersPage, string username)
    {
        var row = usersPage.QA("table tbody tr").FirstOrDefault(tr => tr.QuerySelector("td")?.TextContent.Trim() == username);
        return row?.QuerySelector("select option[selected]")?.GetAttribute("value") ?? "(gebruiker niet in lijst)";
    }

    [Fact, Testcase("TC-25.1-01", "AC-25.1", "Beheerder kent een gebruiker de rol huisarts toe",
        Scenario = "TS-25.1 Rol toekennen en wijzigen (hoofdflow)")]
    public Task TC_25_1_01() => Run(async t =>
    {
        var user = await t.NewPatient("rol_toekennen");
        var admin = await t.LoggedInAs(Env.Beheerder);

        t.Step("Gebruikersbeheer openen");
        var page = await admin.GetAsync("/Users");
        t.Check(page.StatusCode == 200, "Gebruikersbeheer bereikbaar voor beheerder", "200", page.Describe());
        t.Check(SelectedRole(page, user.Username) == "patient", "Huidige rol in overzicht", "patient", SelectedRole(page, user.Username));

        t.Step("Rol wijzigen naar generalPractitioner");
        var result = await admin.ChangeRoleAsync(user.Id, "generalPractitioner");
        t.Check(result.IsRedirect, "Wijziging verwerkt", "doorverwijzing terug naar overzicht", result.Describe());

        t.Step("Overzicht en database controleren");
        page = await admin.GetAsync("/Users");
        t.Check(SelectedRole(page, user.Username) == "generalPractitioner", "Nieuwe rol in overzicht", "generalPractitioner", SelectedRole(page, user.Username));
        var role = await Env.RoleOfAsync(user.Id);
        t.Check(role == UserRoleType.generalPractitioner, "Rol in database", "generalPractitioner", role?.ToString() ?? "-");
    });

    [Fact, Testcase("TC-25.1-02", "AC-25.1", "Beheerder kan de drie rollen uit de opdracht (patiënt, arts, apotheker) toekennen",
        Scenario = "TS-25.1 Rol toekennen en wijzigen (hoofdflow)")]
    public Task TC_25_1_02() => Run(async t =>
    {
        var user = await t.NewPatient("rol_wisselen");
        var admin = await t.LoggedInAs(Env.Beheerder);

        var page = await admin.GetAsync("/Users");
        var options = page.QA("select[name=NewRole]").First().QuerySelectorAll("option").Select(o => o.GetAttribute("value")).ToList();
        t.Info("Rollen in keuzelijst: " + string.Join(", ", options));
        foreach (var r in new[] { "patient", "generalPractitioner", "specialist", "apothecary" })
            t.Check(options.Contains(r), $"Rol '{r}' kiesbaar", "aanwezig", options.Contains(r) ? "aanwezig" : "ontbreekt");

        foreach (var r in new[] { "apothecary", "specialist", "patient" })
        {
            t.Step($"Rol wijzigen naar {r}");
            await admin.ChangeRoleAsync(user.Id, r);
            var actual = await Env.RoleOfAsync(user.Id);
            t.Check(actual?.ToString() == r, $"Rol na wijziging naar {r}", r, actual?.ToString() ?? "-");
        }
    });

    [Fact, Testcase("TC-25.1-03", "AC-25.1", "Beheerder kan een rol intrekken",
        Soort = Soort.Alternatief, Scenario = "TS-25.2 Rol intrekken")]
    public Task TC_25_1_03() => Run(async t =>
    {
        await t.NewPatient("rol_intrekken");
        var admin = await t.LoggedInAs(Env.Beheerder);

        t.Step("Gebruikersbeheer openen en zoeken naar een manier om de rol in te trekken");
        var page = await admin.GetAsync("/Users");
        var roleValues = Enum.GetNames<UserRoleType>();
        var options = page.QA("select[name=NewRole]").First().QuerySelectorAll("option").Select(o => o.GetAttribute("value") ?? "").ToList();
        var revokeOption = options.Any(o => !roleValues.Contains(o));
        var revokeControl = page.QA("button, a, input[type=submit]")
            .Any(e => e.TextContent.Contains("intrek", StringComparison.OrdinalIgnoreCase) || e.TextContent.Contains("revoke", StringComparison.OrdinalIgnoreCase)
                      || e.TextContent.Contains("remove role", StringComparison.OrdinalIgnoreCase));
        t.Info("Beschikbare acties per gebruiker: rol wijzigen (keuzelijst met " + options.Count + " rollen) en gebruiker verwijderen.");
        t.Check(revokeOption || revokeControl, "Mogelijkheid om een rol in te trekken (zonder de gebruiker te verwijderen)",
            "optie 'geen rol' of knop 'rol intrekken'", "niet aanwezig; elke gebruiker moet altijd één van de zes rollen hebben");
    });

    [Fact, Testcase("TC-25.1-04", "AC-25.1", "Ongeldige rol wordt geweigerd en de rol blijft ongewijzigd",
        Soort = Soort.Negatief, Scenario = "TS-25.3 Ongeldige invoer bij rolwijziging")]
    public Task TC_25_1_04() => Run(async t =>
    {
        var user = await t.NewPatient("rol_ongeldig");
        var admin = await t.LoggedInAs(Env.Beheerder);

        t.Step("Rolwijziging versturen met een niet-bestaande rol");
        var result = await admin.ChangeRoleAsync(user.Id, "superuser");
        t.Check(result.StatusCode == 400, "Verzoek geweigerd", "400 Bad Request", result.Describe());
        var role = await Env.RoleOfAsync(user.Id);
        t.Check(role == UserRoleType.patient, "Rol ongewijzigd", "patient", role?.ToString() ?? "-");
    });

    [Fact, Testcase("TC-25.1-05", "AC-25.1", "Beheerder kan de eigen beheerdersrol niet wijzigen (ook niet via een direct verzoek)",
        Soort = Soort.Alternatief, Scenario = "TS-25.4 Eigen rol beschermd")]
    public Task TC_25_1_05() => Run(async t =>
    {
        var admin2 = await t.NewUser("beheerder_eigenrol", UserRoleType.administrator);
        var session = await t.LoggedInAs(admin2);

        t.Step("In het scherm: keuzelijst van de eigen regel is uitgeschakeld");
        var page = await session.GetAsync("/Users");
        var ownRow = page.QA("table tbody tr").First(tr => tr.QuerySelector("td")?.TextContent.Trim() == admin2.Username);
        t.Check(ownRow.QuerySelector("select")?.HasAttribute("disabled") == true, "Eigen rol niet te kiezen in scherm", "uitgeschakeld", "uitgeschakeld");

        t.Step("Rolwijziging voor het eigen account direct naar de server sturen (formulier omzeild)");
        await session.ChangeRoleAsync(admin2.Id, "patient");
        var role = await Env.RoleOfAsync(admin2.Id);
        t.Check(role == UserRoleType.administrator, "Eigen rol ongewijzigd in database", "administrator", role?.ToString() ?? "-");
    });

    [Fact, Testcase("TC-25.1-06", "AC-25.1", "Gebruikers zonder beheerdersrol kunnen geen rollen beheren",
        Soort = Soort.Negatief, Scenario = "TS-25.5 Onbevoegde gebruiker")]
    public Task TC_25_1_06() => Run(async t =>
    {
        var target = await t.NewPatient("rol_doelwit");

        t.Step("Anoniem: gebruikersbeheer openen");
        var anon = t.Session("anoniem");
        t.CheckRedirectedAwayFrom(await anon.GetAsync("/Users"), "/Users", "Anoniem geen toegang tot gebruikersbeheer");

        foreach (var account in new[] { Env.Huisarts, Env.Apotheker })
        {
            var s = await t.LoggedInAs(account);
            t.Step($"{account.Role}: gebruikersbeheer openen en rolwijziging versturen");
            t.CheckRedirectedAwayFrom(await s.GetAsync("/Users"), "/Users", $"{account.Role} geen toegang tot gebruikersbeheer");
            await s.PostFormAsync("/Users?handler=ChangeRole",
                new Dictionary<string, string> { ["UserId"] = target.Id.ToString(), ["NewRole"] = "administrator" }, tokenFrom: "/");
            var role = await Env.RoleOfAsync(target.Id);
            t.Check(role == UserRoleType.patient, $"Rol niet gewijzigd door {account.Role}", "patient", role?.ToString() ?? "-");
        }
    });

    [Fact, Testcase("TC-25.2-01", "AC-25.2", "Nieuwe rechten gelden na opnieuw inloggen; de lopende sessie houdt de oude rechten",
        Scenario = "TS-25.6 Moment waarop rechten ingaan")]
    public Task TC_25_2_01() => Run(async t =>
    {
        var user = await t.NewPatient("rechten_wissel");
        var userSession = await t.LoggedInAs(user, "gebruiker-sessie-1");
        var admin = await t.LoggedInAs(Env.Beheerder);

        t.Step("Beheerder wijzigt rol van patient naar generalPractitioner");
        await admin.ChangeRoleAsync(user.Id, "generalPractitioner");

        t.Step("Lopende sessie van de gebruiker: nog steeds patiëntrechten");
        var stillPatient = await userSession.GetAsync("/Prescriptions/MyPrescriptions");
        t.Check(stillPatient.StatusCode == 200, "Lopende sessie heeft nog patiëntrechten (conform AC: pas na volgende inlog)", "200 medicatieoverzicht", stillPatient.Describe());

        t.Step("Gebruiker logt uit en opnieuw in");
        await userSession.LogoutAsync();
        var login = await userSession.LoginAsync(user);
        t.Check(login.Location?.Contains("MyPrescriptions") != true, "Na inloggen niet meer naar patiëntoverzicht", "andere startpagina", login.Location ?? "-");

        var home = await userSession.BrowseAsync("/");
        var menu = home.Q("[name=menu_prescriptions]") != null;
        t.Check(menu, "Menu 'Prescriptions' (arts) zichtbaar", "zichtbaar", menu ? "zichtbaar" : "niet zichtbaar");
        var patientPage = await userSession.GetAsync("/Prescriptions/MyPrescriptions");
        t.CheckRedirectedAwayFrom(patientPage, "/Prescriptions/MyPrescriptions", "Patiëntoverzicht niet meer toegankelijk");
    });

    [Fact, Testcase("TC-25.2-02", "AC-25.2", "Na een rolwijziging naar beheerder krijgt de gebruiker na inloggen toegang tot gebruikersbeheer",
        Scenario = "TS-25.6 Moment waarop rechten ingaan")]
    public Task TC_25_2_02() => Run(async t =>
    {
        var user = await t.NewUser("promotie", UserRoleType.apothecary);
        var before = await t.LoggedInAs(user, "voor-wijziging");
        t.CheckRedirectedAwayFrom(await before.GetAsync("/Users"), "/Users", "Voor de wijziging geen toegang tot gebruikersbeheer");

        var admin = await t.LoggedInAs(Env.Beheerder);
        t.Step("Beheerder wijzigt rol naar administrator");
        await admin.ChangeRoleAsync(user.Id, "administrator");

        var after = await t.LoggedInAs(user, "na-wijziging");
        var page = await after.GetAsync("/Users");
        t.Check(page.StatusCode == 200, "Na opnieuw inloggen toegang tot gebruikersbeheer", "200", page.Describe());
    });

    [Fact, Testcase("TC-25.2-03", "AC-25.2", "Verwijderde gebruiker kan bij de volgende inlog niet meer inloggen",
        Soort = Soort.Alternatief, Scenario = "TS-25.7 Gebruiker verwijderd")]
    public Task TC_25_2_03() => Run(async t =>
    {
        var user = await t.NewPatient("verwijderd");
        var admin = await t.LoggedInAs(Env.Beheerder);

        t.Step("Beheerder verwijdert de gebruiker");
        await admin.DeleteUserAsync(user.Id);
        t.Check(await Env.RoleOfAsync(user.Id) == null, "Gebruiker verwijderd uit database", "verwijderd", "verwijderd");

        t.Step("Gebruiker probeert in te loggen");
        var s = t.Session(user.Username);
        var login = await s.LoginAsync(user);
        t.Check(login.Location?.Contains("loginError") == true, "Inloggen geweigerd", "loginError", login.Describe());
    });

    [Fact, Testcase("EXT-25-01", ReportWriter.Extra, "Sessie van een verwijderde beheerder blijft geldig tot uitloggen",
        Story = 25, Soort = Soort.Observatie, Scenario = "Verkennend: intrekken van rechten in lopende sessies")]
    public Task EXT_25_01() => Run(async t =>
    {
        var admin2 = await t.NewUser("beheerder_weg", UserRoleType.administrator);
        var session = await t.LoggedInAs(admin2);
        var admin = await t.LoggedInAs(Env.Beheerder);
        await admin.DeleteUserAsync(admin2.Id);

        var page = await session.GetAsync("/Users");
        t.Observe($"Verwijderde beheerder opent gebruikersbeheer met de bestaande sessie: {page.Describe()}"
                  + (page.StatusCode == 200 ? " (toegang blijft bestaan; de cookie is persistent en wordt niet opnieuw gecontroleerd)" : ""));
    });
}
