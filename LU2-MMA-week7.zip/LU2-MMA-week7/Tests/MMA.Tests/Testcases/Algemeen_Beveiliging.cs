using MMA.Tests.Infrastructure;
using Xunit;

namespace MMA.Tests.Testcases;

/// <summary>Aanvullende tests die niet bij één story horen: algemene toegangsbeveiliging en stabiliteit.</summary>
public sealed class Algemeen_Beveiliging(TestEnvironment env) : MmaTestBase(env)
{
    [Fact, Testcase("EXT-0-01", ReportWriter.Extra, "Pagina 'Database Status' is zonder inloggen bereikbaar",
        Soort = Soort.Negatief, Scenario = "Aanvullend: beheerpagina's afgeschermd")]
    public Task EXT_0_01() => Run(async t =>
    {
        var page = await t.Session("anoniem").GetAsync("/Admin/DatabaseStatus");
        t.Check(page.IsRedirect || page.StatusCode is 401 or 403 or 404, "Beheerpagina afgeschermd", "doorverwijzing naar inlogpagina",
            $"{page.Describe()}{(page.Contains("Record Count") ? " met tabeloverzicht en aantallen" : "")}");
    });

    [Fact, Testcase("EXT-0-02", ReportWriter.Extra, "Link 'Privacy' in de voettekst werkt",
        Soort = Soort.Negatief, Scenario = "Aanvullend: stabiliteit en navigatie")]
    public Task EXT_0_02() => Run(async t =>
    {
        var page = await t.Session("anoniem").GetAsync("/Home/Privacy");
        t.Check(page.StatusCode == 200, "Privacypagina", "200", page.Describe());
    });
}
