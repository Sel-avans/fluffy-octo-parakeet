using MMA.Tests.Infrastructure;
using Xunit;

namespace MMA.Tests.Testcases;

/// <summary>Week 7, opdracht nr. 12 / deel 1 nr. 16: Als apotheker wil ik de voorgeschreven medicatie van een patiënt kunnen inzien.</summary>
public sealed class US16_VoorschriftenInzienApotheker(TestEnvironment env) : MmaTestBase(env)
{
    [Fact, Testcase("TC-16.1-01", "AC-16.1", "Apotheker opent een patiënt en ziet het actuele voorschrift met naam, sterkte, hoeveelheid en instructies",
        Scenario = "TS-16.1 Voorschrift van een patiënt inzien (hoofdflow)")]
    public Task TC_16_1_01() => Run(async t =>
    {
        var patient = await t.NewPatient("apo_inzien");
        var trade = t.Data.Medicijn("antibioticum");
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today, DateTime.Today.AddDays(7), (trade, 21, "1 capsule 3x per dag om 08:00, 14:00, 20:00"));
        var apo = await t.LoggedInAs(Env.Apotheker);

        t.Step("Menu 'Patients' openen");
        var home = await apo.BrowseAsync("/");
        t.Check(home.Q("[name=menu_patients]") != null, "Menu 'Patients' voor apotheker", "zichtbaar", home.Q("[name=menu_patients]") != null ? "zichtbaar" : "niet zichtbaar");
        var list = await apo.GetPatientsAsync();
        t.Check(list.Contains(patient), "Patiënt in overzicht", patient.Username, list.Contains(patient) ? "aanwezig" : "ontbreekt");

        t.Step("Voorschriften van de patiënt openen");
        var details = await apo.GetPatientDetailsAsync(patient.Id);
        t.Check(details.Page.StatusCode == 200, "Scherm patiëntdetails", "200", details.Page.Describe());
        var line = details.Find(trade);
        t.Check(line != null, "Medicijn zichtbaar", trade, details.MedicineNames);
        t.Check(line!.Strength == "500mg", "Sterkte", "500mg", line.Strength);
        t.Check(line.Quantity == "21", "Hoeveelheid", "21", line.Quantity);
        t.Check(line.Instructions == "1 capsule 3x per dag om 08:00, 14:00, 20:00", "Dosering en innametijden", "1 capsule 3x per dag om 08:00, 14:00, 20:00", line.Instructions);
    });

    [Fact, Testcase("TC-16.1-02", "AC-16.1", "Patiënt met twee actuele voorschriften: de apotheker ziet beide",
        Soort = Soort.Alternatief, Scenario = "TS-16.2 Meerdere actuele voorschriften")]
    public Task TC_16_1_02() => Run(async t =>
    {
        var patient = await t.NewPatient("apo_twee");
        var a = t.Data.Medicijn("ontstekingsremmer");
        var b = t.Data.Medicijn("maagbeschermer");
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today.AddDays(-3), DateTime.Today.AddDays(10), (a, 30, "1 tablet 3x per dag"));
        await Env.ArrangePrescriptionAsync(patient, Env.Specialist, DateTime.Today, DateTime.Today.AddDays(28), (b, 28, "1 capsule voor het ontbijt"));
        t.Info($"Gegeven: twee actuele voorschriften ({a} van de huisarts, {b} van de specialist)");

        var apo = await t.LoggedInAs(Env.Apotheker);
        var details = await apo.GetPatientDetailsAsync(patient.Id);
        t.Info($"Kop toont 'Active Prescriptions ({details.PrescriptionCount})'");
        t.Check(details.HasMedicine(a) && details.HasMedicine(b), "Beide voorschriften zichtbaar", $"{a} en {b}", details.MedicineNames);
    });

    [Fact, Testcase("TC-16.1-03", "AC-16.1", "Voorschrift met meerdere medicijnen (via het scherm van de arts): alle medicijnen zichtbaar",
        Soort = Soort.Alternatief, Scenario = "TS-16.2 Meerdere actuele voorschriften")]
    public Task TC_16_1_03() => Run(async t =>
    {
        var patient = await t.NewPatient("apo_meer");
        var a = t.Data.Medicijn("ontstekingsremmer");
        var b = t.Data.Medicijn("maagbeschermer");
        var doctor = await t.LoggedInAs(Env.Huisarts);
        t.Step("Arts legt via het scherm één voorschrift met twee medicijnen vast");
        await doctor.PrescribeAsync(new PrescriptionInput { PatientId = patient.Id.ToString() },
            new MedicineLine(await Env.MedicineIdAsync(a), 30, "1 tablet 3x per dag"),
            new MedicineLine(await Env.MedicineIdAsync(b), 14, "1 capsule voor het ontbijt"));

        var details = await (await t.LoggedInAs(Env.Apotheker)).GetPatientDetailsAsync(patient.Id);
        t.Check(details.HasMedicine(a) && details.HasMedicine(b), "Beide medicijnen zichtbaar", $"{a} en {b}", details.MedicineNames);
    });

    [Fact, Testcase("TC-16.1-04", "AC-16.1", "Voorschrift met een medicijn dat later uit het assortiment is verwijderd, blijft leesbaar voor de apotheker",
        Soort = Soort.Alternatief, Scenario = "TS-16.3 Voorschrift met verwijderd medicijn")]
    public Task TC_16_1_04() => Run(async t =>
    {
        var patient = await t.NewPatient("apo_verwijderd");
        var med = await Env.ArrangeMedicineAsync("Verdwijnmedicijn");
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today, DateTime.Today.AddDays(7), (med.TradeName, 10, "1 tablet per dag"));
        var apo = await t.LoggedInAs(Env.Apotheker);

        t.Step($"Apotheker verwijdert medicijn {med.TradeName} uit het assortiment");
        await apo.DeleteMedicineAsync(med.Id);

        t.Step("Apotheker opent de voorschriften van de patiënt");
        var details = await apo.GetPatientDetailsAsync(patient.Id);
        t.Check(details.Page.StatusCode == 200, "Scherm patiëntdetails", "200 met het voorschrift", details.Page.Describe());
        t.Check(details.HasMedicine(med.TradeName), "Voorgeschreven medicijn zichtbaar (eventueel gemarkeerd als niet meer leverbaar)", med.TradeName, details.MedicineNames);
    });

    [Fact, Testcase("TC-16.1-05", "AC-16.1", "Patiënt zonder actuele voorschriften: duidelijke melding",
        Soort = Soort.Alternatief, Scenario = "TS-16.4 Geen voorschriften")]
    public Task TC_16_1_05() => Run(async t =>
    {
        var patient = await t.NewPatient("apo_leeg");
        var details = await (await t.LoggedInAs(Env.Apotheker)).GetPatientDetailsAsync(patient.Id);
        var shown = details.Page.Contains("currently has no active prescriptions");
        t.Check(details.Page.StatusCode == 200 && shown, "Melding geen voorschriften", "'This patient currently has no active prescriptions.'", shown ? "getoond" : details.Page.Describe());
    });

    [Fact, Testcase("TC-16.1-06", "AC-16.1", "Alleen de apotheker kan patiëntvoorschriften opvragen",
        Soort = Soort.Negatief, Scenario = "TS-16.5 Onbevoegde gebruiker")]
    public Task TC_16_1_06() => Run(async t =>
    {
        var patient = await t.NewPatient("apo_afgeschermd");
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today, DateTime.Today.AddDays(7), (t.Data.Medicijn("pijnstiller"), 10, "1 tablet per dag"));
        var other = await t.NewPatient("andere_patient");
        var open = new List<string>();
        foreach (var (name, session) in new (string, MmaClient)[]
                 {
                     ("anoniem", t.Session("anoniem")),
                     ("beheerder", await t.LoggedInAs(Env.Beheerder)),
                     ("huisarts", await t.LoggedInAs(Env.Huisarts)),
                     ("zorgverzekeraar", await t.LoggedInAs(Env.Verzekeraar)),
                     ("andere patiënt", await t.LoggedInAs(other))
                 })
        {
            var list = await session.GetAsync("/Patients/Index");
            var details = await session.GetAsync($"/Patients/Details?patientId={patient.Id}");
            t.Info($"{name}: overzicht {list.Describe()}, details {details.Describe()}");
            if (list.StatusCode == 200 || details.StatusCode == 200) open.Add(name);
        }
        t.Check(open.Count == 0, "Patiëntvoorschriften afgeschermd", "alleen apotheker", open.Count == 0 ? "geen toegang voor anderen" : "toegang voor: " + string.Join(", ", open));
    });

    [Fact, Testcase("TC-16.2-01", "AC-16.2", "Zoeken op naam vindt de patiënt; zorgverleners en beheerders staan niet in de lijst",
        Scenario = "TS-16.6 Patiënt zoeken (hoofdflow)")]
    public Task TC_16_2_01() => Run(async t =>
    {
        var patient = await t.NewPatient("zoek_naam");
        var apo = await t.LoggedInAs(Env.Apotheker);

        var all = await apo.GetPatientsAsync();
        var staff = new[] { Env.Beheerder, Env.Huisarts, Env.Specialist, Env.Apotheker, Env.Verzekeraar }.Where(all.Contains).Select(a => a.Username).ToList();
        t.Check(staff.Count == 0, "Alleen patiënten in de lijst", "geen medewerkers", staff.Count == 0 ? "alleen patiënten" : string.Join(", ", staff));

        t.Step($"Zoeken op '{patient.Username}'");
        var found = await apo.GetPatientsAsync(patient.Username);
        t.Check(found.Rows.Count == 1 && found.Contains(patient), "Zoekresultaat", patient.Username, found.Names);
    });

    [Fact, Testcase("TC-16.2-02", "AC-16.2", "Zoeken op e-mailadres vindt de patiënt; zoekterm zonder resultaat geeft een melding",
        Soort = Soort.Alternatief, Scenario = "TS-16.6 Patiënt zoeken (hoofdflow)")]
    public Task TC_16_2_02() => Run(async t =>
    {
        var patient = await t.NewPatient("zoek_mail");
        var apo = await t.LoggedInAs(Env.Apotheker);
        var byMail = await apo.GetPatientsAsync(patient.Email.ToUpperInvariant());
        t.Check(byMail.Contains(patient), "Zoeken op e-mail (hoofdletterongevoelig)", patient.Username, byMail.Names);
        var none = await apo.GetPatientsAsync("bestaat-niet-" + Guid.NewGuid().ToString("N")[..6]);
        t.Check(none.Rows.Count == 0 && none.Page.Contains("No patients found matching"), "Zoekterm zonder resultaat", "melding 'No patients found matching'", none.Names);
    });

    [Fact, Testcase("TC-16.2-03", "AC-16.2", "Alleen actuele voorschriften: verlopen voorschrift niet zichtbaar, voorschrift dat vandaag eindigt wel",
        Soort = Soort.Alternatief, Scenario = "TS-16.7 Grenzen van 'actueel'")]
    public Task TC_16_2_03() => Run(async t =>
    {
        var patient = await t.NewPatient("apo_actueel");
        var expired = t.Data.Medicijn("ontstekingsremmer");
        var endsToday = t.Data.Medicijn("maagbeschermer");
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today.AddDays(-10), DateTime.Today.AddDays(-1), (expired, 10, "verlopen"));
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today.AddDays(-10), DateTime.Today, (endsToday, 10, "eindigt vandaag"));
        var details = await (await t.LoggedInAs(Env.Apotheker)).GetPatientDetailsAsync(patient.Id);
        t.Check(!details.HasMedicine(expired), "Verlopen voorschrift", "niet zichtbaar", details.HasMedicine(expired) ? "zichtbaar" : "niet zichtbaar");
        t.Check(details.HasMedicine(endsToday), "Voorschrift met einddatum vandaag", "zichtbaar", details.HasMedicine(endsToday) ? "zichtbaar" : "niet zichtbaar");
    });

    [Fact, Testcase("TC-16.2-04", "AC-16.2", "Bij patiënt A verschijnen geen voorschriften van patiënt B",
        Soort = Soort.Negatief, Scenario = "TS-16.8 Juiste patiënt")]
    public Task TC_16_2_04() => Run(async t =>
    {
        var a = await t.NewPatient("apo_a");
        var b = await t.NewPatient("apo_b");
        var tradeA = t.Data.Medicijn("pijnstiller");
        var tradeB = t.Data.Medicijn("antibioticum");
        await Env.ArrangePrescriptionAsync(a, Env.Huisarts, DateTime.Today, DateTime.Today.AddDays(7), (tradeA, 10, "A"));
        await Env.ArrangePrescriptionAsync(b, Env.Huisarts, DateTime.Today, DateTime.Today.AddDays(7), (tradeB, 21, "B"));
        var details = await (await t.LoggedInAs(Env.Apotheker)).GetPatientDetailsAsync(a.Id);
        t.Check(details.HasMedicine(tradeA) && !details.HasMedicine(tradeB), "Alleen voorschriften van patiënt A", tradeA, details.MedicineNames);
    });

    [Fact, Testcase("TC-16.2-05", "AC-16.2", "Details opvragen voor een gebruiker die geen patiënt is of niet bestaat geeft 'niet gevonden'",
        Soort = Soort.Negatief, Scenario = "TS-16.8 Juiste patiënt")]
    public Task TC_16_2_05() => Run(async t =>
    {
        var apo = await t.LoggedInAs(Env.Apotheker);
        var doctor = await apo.GetAsync($"/Patients/Details?patientId={Env.Huisarts.Id}");
        var missing = await apo.GetAsync("/Patients/Details?patientId=999999");
        t.Check(doctor.StatusCode == 404, "Details van een huisarts", "404", doctor.Describe());
        t.Check(missing.StatusCode == 404, "Details van een niet-bestaand ID", "404", missing.Describe());
    });

    [Fact, Testcase("TC-16.2-06", "AC-16.2", "Het voorschriftenoverzicht is alleen-lezen voor de apotheker",
        Soort = Soort.Negatief, Scenario = "TS-16.9 Apotheker wijzigt niets")]
    public Task TC_16_2_06() => Run(async t =>
    {
        var patient = await t.NewPatient("apo_lezen");
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today, DateTime.Today.AddDays(7), (t.Data.Medicijn("pijnstiller"), 10, "1 tablet per dag"));
        var details = await (await t.LoggedInAs(Env.Apotheker)).GetPatientDetailsAsync(patient.Id);
        var forms = details.Page.QA("main form").Count();
        var inputs = details.Page.QA("main input:not([type=hidden]), main textarea, main select").Count();
        t.Check(forms == 0 && inputs == 0, "Formulieren of invoervelden", "geen", $"{forms} formulieren, {inputs} velden");
    });

    [Fact, Testcase("EXT-16-01", ReportWriter.Extra, "Patiëntenoverzicht van de apotheker: zoekveld en getoonde gegevens",
        Story = 16, Soort = Soort.Observatie, Scenario = "Verkennend: bruikbaarheid en dataminimalisatie")]
    public Task EXT_16_01() => Run(async t =>
    {
        await t.NewPatient("apo_obs");
        var page = (await (await t.LoggedInAs(Env.Apotheker)).GetPatientsAsync()).Page;
        var placeholder = page.Q("#searchName")?.GetAttribute("placeholder") ?? "";
        var columns = page.QA("table thead th").Select(th => th.TextContent.Trim()).ToList();
        t.Observe($"Zoekveld belooft '{placeholder}', maar het systeem kent alleen een gebruikersnaam en e-mailadres (geen voor- en achternaam).");
        t.Observe($"Kolommen in het overzicht: {string.Join(", ", columns)}. Alle patiënten van het systeem zijn zichtbaar, niet alleen die van de eigen apotheek.");
    });
}
