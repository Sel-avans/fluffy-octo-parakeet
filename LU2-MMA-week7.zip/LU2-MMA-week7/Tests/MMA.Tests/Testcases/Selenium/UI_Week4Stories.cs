using LU2_software_testen.Models;
using MMA.Tests.Infrastructure;
using OpenQA.Selenium;
using Xunit;

namespace MMA.Tests.Testcases.Selenium;

/// <summary>
/// Selenium-testcases (echte browser) voor de stories van week 4. Ze lopen de schermen door zoals een gebruiker:
/// klikken, typen en kiezen, inclusief JavaScript en browservalidatie.
/// </summary>
public sealed class UI_Week4Stories(TestEnvironment env) : MmaTestBase(env)
{
    private static IWebElement UserRow(BrowserSession b, string username) =>
        b.FindXPath($"//table//tr[td[1][normalize-space()='{username}']]");

    // ---------- Story 25: gebruikersrollen beheren ----------

    [Fact, Testcase("UI-25.1-01", "AC-25.1", "Browser: beheerder kiest in gebruikersbeheer een nieuwe rol en klikt op Change",
        Scenario = "TS-25.1 Rol toekennen en wijzigen (hoofdflow)")]
    public Task UI_25_1_01() => Run(async t =>
    {
        var user = await t.NewPatient("ui_rol");
        var b = await t.BrowserLoggedInAs(Env.Beheerder);
        t.Step("Menu 'Users' openen");
        b.ClickAndWait("[name=menu_users]", "menu Users");
        t.Check(b.Text("h2") == "User Management", "Scherm gebruikersbeheer", "User Management", b.Text("h2"));

        t.Step($"Bij {user.Username} de rol 'specialist' kiezen en op Change klikken");
        var row = UserRow(b, user.Username);
        new OpenQA.Selenium.Support.UI.SelectElement(row.FindElement(By.Name("NewRole"))).SelectByValue("specialist");
        b.ClickAndWait(row.FindElement(By.XPath(".//button[normalize-space()='Change']")), "Change");

        var selected = UserRow(b, user.Username).FindElement(By.CssSelector("select option:checked")).GetDomProperty("value");
        t.Check(selected == "specialist", "Rol in overzicht na opslaan", "specialist", selected ?? "-");
        t.Check(await Env.RoleOfAsync(user.Id) == UserRoleType.specialist, "Rol in database", "specialist", (await Env.RoleOfAsync(user.Id)).ToString()!);
    });

    [Fact, Testcase("UI-25.2-01", "AC-25.2", "Browser: na een rolwijziging en opnieuw inloggen toont het menu de nieuwe rechten",
        Scenario = "TS-25.6 Moment waarop rechten ingaan")]
    public Task UI_25_2_01() => Run(async t =>
    {
        var user = await t.NewUser("ui_rechten", UserRoleType.apothecary);
        var u = await t.BrowserLoggedInAs(user, "gebruiker");
        t.Check(u.Exists("[name=menu_medicine]") && !u.Exists("[name=menu_prescriptions]"), "Menu vóór de wijziging", "Medicines, geen Prescriptions",
            u.Exists("[name=menu_prescriptions]") ? "Prescriptions zichtbaar" : "Medicines");

        await (await t.LoggedInAs(Env.Beheerder)).ChangeRoleAsync(user.Id, "generalPractitioner");
        t.Step("Rol is gewijzigd naar huisarts; zelfde browser opnieuw laden");
        u.Open("/");
        t.Check(u.Exists("[name=menu_medicine]"), "Lopende sessie houdt oude rechten", "Medicines nog zichtbaar", u.Exists("[name=menu_medicine]") ? "zichtbaar" : "niet zichtbaar");

        t.Step("Uitloggen en opnieuw inloggen");
        u.Logout();
        u.Login(user.Username, user.Password);
        t.Check(u.Exists("[name=menu_prescriptions]") && !u.Exists("[name=menu_medicine]"), "Menu na opnieuw inloggen", "Prescriptions, geen Medicines",
            u.Exists("[name=menu_prescriptions]") ? "Prescriptions" : "geen Prescriptions");
    });

    // ---------- Story 4: inloggen ----------

    [Fact, Testcase("UI-4.1-01", "AC-4.1", "Browser: patiënt logt in op de startpagina en komt op het eigen medicatieoverzicht",
        Scenario = "TS-4.1 Inloggen met geldige gegevens (hoofdflow)")]
    public Task UI_4_1_01() => Run(async t =>
    {
        var a = await t.NewPatient("ui_inlog_a");
        var bPatient = await t.NewPatient("ui_inlog_b");
        await Env.ArrangePrescriptionAsync(a, Env.Huisarts, DateTime.Today, DateTime.Today.AddDays(7), (t.Data.Medicijn("pijnstiller"), 10, "1 tablet per dag"));
        await Env.ArrangePrescriptionAsync(bPatient, Env.Huisarts, DateTime.Today, DateTime.Today.AddDays(7), (t.Data.Medicijn("antibioticum"), 21, "3x per dag"));
        var b = await t.BrowserLoggedInAs(a);
        t.Check(b.Path.StartsWith("/Prescriptions/MyPrescriptions"), "Pagina na inloggen", "/Prescriptions/MyPrescriptions", b.Path);
        var meds = b.Rows("table table").Select(r => r[0]).ToList();
        t.Check(meds.Contains("Panadol") && !meds.Contains("Amoxicillin"), "Alleen eigen medicatie", "Panadol, geen Amoxicillin", string.Join(", ", meds));
    });

    [Fact, Testcase("UI-4.2-01", "AC-4.2", "Browser: onjuist wachtwoord geeft een foutmelding die verdwijnt zodra de gebruiker opnieuw typt",
        Soort = Soort.Negatief, Scenario = "TS-4.4 Inloggen met onjuiste gegevens")]
    public Task UI_4_2_01() => Run(async t =>
    {
        var patient = await t.NewPatient("ui_fout");
        var b = await t.Browser("anoniem");
        b.Login(patient.Username, "verkeerd");
        t.Check(b.Exists("#login-error") && b.Text("#login-error") == "Username/password not recognized", "Foutmelding",
            "Username/password not recognized", b.Text("#login-error"));
        t.Check(b.LoggedInUser == "" && b.Exists("button[name=btn-login]"), "Niet ingelogd", "inlogformulier zichtbaar, geen gebruiker", b.LoggedInUser);
        t.Step("In het veld Username klikken");
        b.Click("#Username", "veld Username");
        t.Check(!b.Exists("#login-error"), "Melding verdwijnt bij focus", "verborgen", b.Exists("#login-error") ? "zichtbaar" : "verborgen");
    });

    // ---------- Story 11 en 12: voorschrijven, dosering en innametijden ----------

    private static async Task PrescribeViaScreens(TestCaseContext t, BrowserSession b, TestAccount patient,
        params (string Medicine, string Quantity, string Instructions)[] lines)
    {
        t.Step("Menu 'Prescriptions' > 'New Prescription'");
        b.ClickAndWait("[name=menu_prescriptions]", "menu Prescriptions");
        b.ClickAndWait(b.ButtonWithText("New Prescription"), "New Prescription");
        b.Select("#patientSelect", patient.Id.ToString(), "Patient");
        b.Type("#descBox", "Voorschrift via browser", "Description");
        foreach (var (medicine, quantity, instructions) in lines)
        {
            b.ClickAndWait(b.ButtonWithText("Add Medicine"), "Add Medicine");
            b.SelectText("#SelectedMedicineId", medicine, "Medicine");
            b.Type("#Quantity", quantity, "Quantity");
            b.Type("#Instructions", instructions, "Instructions");
            b.ClickAndWait("button[name=action][value=add]", "Add");
        }
        await Task.CompletedTask;
    }

    [Fact, Testcase("UI-11.1-01", "AC-11.1", "Browser: huisarts stelt via de schermen een voorschrift op en krijgt een bevestiging",
        Scenario = "TS-11.1 Voorschrift vastleggen (hoofdflow)")]
    public Task UI_11_1_01() => Run(async t =>
    {
        var patient = await t.NewPatient("ui_voorschrift");
        var b = await t.BrowserLoggedInAs(Env.Huisarts);
        await PrescribeViaScreens(t, b, patient, ("Panadol", "20", "1 tablet 3x per dag"));
        var added = b.Rows("table.table-bordered").Select(r => r[0]).ToList();
        t.Check(added.Contains("Panadol"), "Medicijn in het voorschrift (scherm)", "Panadol", string.Join(", ", added));
        b.ClickAndWait(b.ButtonWithText("Create Prescription"), "Create Prescription");
        t.Check(b.Text("#successMessage") == "Prescription successfully created", "Bevestiging", "Prescription successfully created", b.Text("#successMessage"));
        var stored = await Env.PrescriptionsOfAsync(patient.Id);
        t.Check(stored.Count == 1 && stored[0].PrescriberID == Env.Huisarts.Id, "Voorschrift in patiëntdossier", $"1 voorschrift van {Env.Huisarts.Username}",
            $"{stored.Count} voorschrift(en)");
    });

    [Fact, Testcase("UI-11.2-01", "AC-11.2", "Browser: hoeveelheid 0 wordt door het formulier tegengehouden",
        Soort = Soort.Negatief, Scenario = "TS-11.6 Ongeldige dosering")]
    public Task UI_11_2_01() => Run(async t =>
    {
        var patient = await t.NewPatient("ui_nul");
        var b = await t.BrowserLoggedInAs(Env.Huisarts);
        b.Open("/Prescriptions/New");
        b.Select("#patientSelect", patient.Id.ToString(), "Patient");
        b.ClickAndWait(b.ButtonWithText("Add Medicine"), "Add Medicine");
        b.SelectText("#SelectedMedicineId", "Panadol", "Medicine");
        b.Type("#Quantity", "0", "Quantity");
        b.Type("#Instructions", "1 tablet per dag", "Instructions");
        b.Click("button[name=action][value=add]", "Add");
        var message = b.Find("#Quantity").GetDomProperty("validationMessage") ?? "";
        t.Check(b.Path.StartsWith("/Prescriptions/AddMedicineToPrescription") && message.Length > 0, "Formulier niet verstuurd",
            "blijft op Add Medicine met browsermelding", $"{b.Path}, melding '{message}'");
    });

    [Fact, Testcase("UI-11.2-02", "AC-11.2", "Browser: voorschrift zonder medicijn wordt niet opgeslagen en de arts ziet waarom",
        Soort = Soort.Negatief, Scenario = "TS-11.5 Verplichte velden ontbreken")]
    public Task UI_11_2_02() => Run(async t =>
    {
        var patient = await t.NewPatient("ui_zonder_med");
        var b = await t.BrowserLoggedInAs(Env.Huisarts);
        b.Open("/Prescriptions/New");
        b.Select("#patientSelect", patient.Id.ToString(), "Patient");
        b.Type("#descBox", "Zonder medicijn", "Description");
        b.ClickAndWait(b.ButtonWithText("Create Prescription"), "Create Prescription");
        var stored = await Env.PrescriptionsOfAsync(patient.Id);
        var visible = b.All(".text-danger, .validation-summary-errors").Select(e => e.Text.Trim()).Where(x => x.Length > 0).ToList();
        t.Check(stored.Count == 0, "Niet opgeslagen", "0 voorschriften", stored.Count.ToString());
        t.Check(visible.Count > 0, "Melding zichtbaar voor de arts", "melding dat een medicijn nodig is", visible.Count > 0 ? string.Join(" / ", visible) : "geen melding");
    });

    [Fact, Testcase("UI-12.1-01", "AC-12.1", "Browser: arts vult dosering, frequentie en innametijden in; die worden ongewijzigd opgeslagen",
        Scenario = "TS-12.1 Dosering en innametijden vastleggen (hoofdflow)")]
    public Task UI_12_1_01() => Run(async t =>
    {
        const string instructie = "1 tablet, 2x per dag om 08:00 en 20:00, bij het eten";
        var patient = await t.NewPatient("ui_dosering");
        var b = await t.BrowserLoggedInAs(Env.Specialist);
        await PrescribeViaScreens(t, b, patient, ("Ibuprofen", "14", instructie));
        b.ClickAndWait(b.ButtonWithText("Create Prescription"), "Create Prescription");
        var stored = await Env.PrescriptionsOfAsync(patient.Id);
        var line = stored.Count == 1 ? (await Env.PrescriptionLinesAsync(stored[0].Id)).Single() : null;
        t.Check(line != null && line.Quantity == 14 && line.Instructions == instructie, "Opgeslagen dosering en innametijden",
            $"14 / {instructie}", line == null ? "niet opgeslagen" : $"{line.Quantity} / {line.Instructions}");
    });

    [Fact, Testcase("UI-12.2-01", "AC-12.2", "Browser: de patiënt ziet de ingestelde dosering en innametijden in het overzicht",
        Scenario = "TS-12.3 Instellingen zichtbaar voor patiënt")]
    public Task UI_12_2_01() => Run(async t =>
    {
        const string instructie = "1 capsule 's ochtends om 07:30, nuchter";
        var patient = await t.NewPatient("ui_zichtbaar");
        var doctor = await t.BrowserLoggedInAs(Env.Huisarts);
        await PrescribeViaScreens(t, doctor, patient, ("Omeprazole", "28", instructie));
        doctor.ClickAndWait(doctor.ButtonWithText("Create Prescription"), "Create Prescription");

        var p = await t.BrowserLoggedInAs(patient);
        var row = p.Rows("table table").FirstOrDefault(r => r[0] == "Omeprazole");
        t.Check(row != null && row[2] == instructie, "Instructies zichtbaar voor patiënt", instructie, row == null ? "medicijn niet zichtbaar" : row[2]);
    });

    // ---------- Story 5: medicatie inzien ----------

    [Fact, Testcase("UI-5.1-01", "AC-5.1", "Browser: patiënt ziet een tabel met medicijn, sterkte, instructies en periode",
        Scenario = "TS-5.1 Actuele medicatie bekijken (hoofdflow)")]
    public Task UI_5_1_01() => Run(async t =>
    {
        var patient = await t.NewPatient("ui_inzien");
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today, DateTime.Today.AddDays(7), (t.Data.Medicijn("antibioticum"), 21, "1 capsule 3x per dag"));
        var b = await t.BrowserLoggedInAs(patient);
        var headers = b.All("table table thead th").Select(h => h.Text.Trim()).Distinct().ToList();
        t.Check(new[] { "Medicine", "Strength", "Instructions", "Start Date", "End Date" }.All(headers.Contains), "Kolommen",
            "Medicine, Strength, Instructions, Start Date, End Date", string.Join(", ", headers));
        var row = b.Rows("table table").FirstOrDefault();
        t.Check(row != null && row[0] == "Amoxicillin" && row[1] == "500mg" && row[2] == "1 capsule 3x per dag", "Regel", "Amoxicillin / 500mg / 1 capsule 3x per dag",
            row == null ? "geen regel" : string.Join(" / ", row.Take(3)));
    });

    [Fact, Testcase("UI-5.2-01", "AC-5.2", "Browser: voorschrift met twee medicijnen van de arts verschijnt volledig bij de patiënt",
        Scenario = "TS-5.5 Nieuw voorschrift verschijnt bij patiënt (end-to-end)")]
    public Task UI_5_2_01() => Run(async t =>
    {
        var patient = await t.NewPatient("ui_e2e");
        var doctor = await t.BrowserLoggedInAs(Env.Huisarts);
        await PrescribeViaScreens(t, doctor, patient, ("Ibuprofen", "30", "1 tablet 3x per dag"), ("Omeprazole", "14", "1 capsule voor het ontbijt"));
        doctor.ClickAndWait(doctor.ButtonWithText("Create Prescription"), "Create Prescription");
        var p = await t.BrowserLoggedInAs(patient);
        var meds = p.Rows("table table").Select(r => r[0]).ToList();
        t.Check(meds.Contains("Ibuprofen") && meds.Contains("Omeprazole"), "Beide medicijnen zichtbaar", "Ibuprofen en Omeprazole", string.Join(", ", meds));
    });

    // ---------- Story 26: logbestanden ----------

    [Fact, Testcase("UI-26.1-01", "AC-26.1", "Browser: beheerder kiest het logbestand van vandaag en ziet de regel van een zojuist gewijzigde rol",
        Scenario = "TS-26.2 Acties terugvinden in het log")]
    public Task UI_26_1_01() => Run(async t =>
    {
        var user = await t.NewPatient("ui_log");
        var b = await t.BrowserLoggedInAs(Env.Beheerder);
        b.ClickAndWait("[name=menu_users]", "menu Users");
        var row = UserRow(b, user.Username);
        new OpenQA.Selenium.Support.UI.SelectElement(row.FindElement(By.Name("NewRole"))).SelectByValue("apothecary");
        b.ClickAndWait(row.FindElement(By.XPath(".//button[normalize-space()='Change']")), "Change (rol naar apothecary)");

        t.Step("Menu 'Log files', bestand van vandaag kiezen in de keuzelijst");
        b.ClickAndWait("[name=menu_log_files]", "menu Log files");
        b.Type("#logFileDropdown", Env.TodaysLogFileName[..^4], "zoekveld logbestanden");
        b.Click(b.FindXPath($"//div[@id='dropdownList']/button[normalize-space()='{Env.TodaysLogFileName}']"), Env.TodaysLogFileName);
        var loaded = b.WaitUntil(() => b.Value("#logContent").Contains($"Role of {user.Id} was changed"));
        var line = b.Value("#logContent").Split('\n').FirstOrDefault(l => l.Contains($"Role of {user.Id} was changed"))?.Trim() ?? "";
        t.Check(loaded, "Logregel zichtbaar in het scherm", $"regel 'Role of {user.Id} was changed'", line.Length > 0 ? line : "niet gevonden");
        t.Check(System.Text.RegularExpressions.Regex.IsMatch(line, $@"^\d{{2}}:\d{{2}}:\d{{2}}: UserID {Env.Beheerder.Id}: "), "Tijdstip en gebruiker in de regel",
            $"HH:mm:ss: UserID {Env.Beheerder.Id}: ...", line);
        t.Check(b.Find("#downloadBtn").Enabled, "Downloadknop actief", "actief", b.Find("#downloadBtn").Enabled ? "actief" : "uitgeschakeld");
    });

    [Fact, Testcase("UI-26.2-01", "AC-26.2", "Browser: het logvenster is alleen-lezen; typen verandert de inhoud niet",
        Soort = Soort.Negatief, Scenario = "TS-26.5 Logregels zijn alleen-lezen")]
    public Task UI_26_2_01() => Run(async t =>
    {
        var b = await t.BrowserLoggedInAs(Env.Beheerder);
        b.ClickAndWait("[name=menu_log_files]", "menu Log files");
        b.Type("#logFileDropdown", Env.TodaysLogFileName[..^4], "zoekveld logbestanden");
        b.Click(b.FindXPath($"//div[@id='dropdownList']/button[normalize-space()='{Env.TodaysLogFileName}']"), Env.TodaysLogFileName);
        b.WaitUntil(() => b.Value("#logContent").Length > 0);
        var before = b.Value("#logContent");
        t.Step("Proberen tekst in het logvenster te typen en te wissen");
        var area = b.Find("#logContent");
        try { area.SendKeys(Keys.Control + "a"); area.SendKeys(Keys.Delete); area.SendKeys("gewist"); } catch (WebDriverException) { }
        var after = b.Value("#logContent");
        t.Check(after == before, "Inhoud van het logvenster", "ongewijzigd", after == before ? "ongewijzigd" : "gewijzigd");
        t.Check(!b.All("main button, main input[type=submit]").Any(e => e.Text.Contains("Save") || e.Text.Contains("Delete")), "Knoppen om op te slaan of te verwijderen", "geen", "geen");
    });
}
