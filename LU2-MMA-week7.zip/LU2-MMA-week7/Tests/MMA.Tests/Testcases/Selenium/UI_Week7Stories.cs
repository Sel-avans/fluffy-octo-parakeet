using MMA.Tests.Infrastructure;
using OpenQA.Selenium;
using Xunit;

namespace MMA.Tests.Testcases.Selenium;

/// <summary>Selenium-testcases (echte browser) voor de stories van week 7: apotheker bekijkt voorschriften en beheert medicijnen.</summary>
public sealed class UI_Week7Stories(TestEnvironment env) : MmaTestBase(env)
{
    // ---------- Story 16: voorgeschreven medicatie inzien ----------

    [Fact, Testcase("UI-16.1-01", "AC-16.1", "Browser: apotheker opent via 'Patients' > 'View Prescriptions' het voorschrift van een patiënt",
        Scenario = "TS-16.1 Voorschrift van een patiënt inzien (hoofdflow)")]
    public Task UI_16_1_01() => Run(async t =>
    {
        var patient = await t.NewPatient("ui_apo");
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today, DateTime.Today.AddDays(7), (t.Data.Medicijn("antibioticum"), 21, "1 capsule 3x per dag"));
        var b = await t.BrowserLoggedInAs(Env.Apotheker);
        t.Step("Menu 'Patients' openen en bij de patiënt op 'View Prescriptions' klikken");
        b.ClickAndWait("[name=menu_patients]", "menu Patients");
        b.ClickAndWait($"a[href='/Patients/Details?patientId={patient.Id}']", $"View Prescriptions ({patient.Username})");
        t.Check(b.Text("h1") == "Patient Prescription Details", "Scherm patiëntdetails", "Patient Prescription Details", b.Text("h1"));
        var row = b.Rows(".prescription-card table").FirstOrDefault();
        t.Check(row != null && row[0] == "Amoxicillin" && row[1] == "500mg" && row[2] == "21" && row[3] == "1 capsule 3x per dag",
            "Medicijn, sterkte, hoeveelheid, instructies", "Amoxicillin / 500mg / 21 / 1 capsule 3x per dag", row == null ? "geen regel" : string.Join(" / ", row));
    });

    [Fact, Testcase("UI-16.1-02", "AC-16.1", "Browser: apotheker ziet bij een patiënt met twee actuele voorschriften beide voorschriften",
        Soort = Soort.Alternatief, Scenario = "TS-16.2 Meerdere actuele voorschriften")]
    public Task UI_16_1_02() => Run(async t =>
    {
        var patient = await t.NewPatient("ui_apo_twee");
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today.AddDays(-3), DateTime.Today.AddDays(10), (t.Data.Medicijn("ontstekingsremmer"), 30, "1 tablet 3x per dag"));
        await Env.ArrangePrescriptionAsync(patient, Env.Specialist, DateTime.Today, DateTime.Today.AddDays(28), (t.Data.Medicijn("maagbeschermer"), 28, "1 capsule voor het ontbijt"));
        var b = await t.BrowserLoggedInAs(Env.Apotheker);
        b.Open($"/Patients/Details?patientId={patient.Id}");
        var header = b.All(".card-header h5").Select(h => h.Text.Trim()).FirstOrDefault(h => h.StartsWith("Active Prescriptions")) ?? "";
        var meds = b.Rows(".prescription-card table").Select(r => r[0]).ToList();
        t.Info($"Kop: '{header}'");
        t.Check(meds.Contains("Ibuprofen") && meds.Contains("Omeprazole"), "Beide voorschriften zichtbaar", "Ibuprofen en Omeprazole", string.Join(", ", meds));
    });

    [Fact, Testcase("UI-16.2-01", "AC-16.2", "Browser: apotheker zoekt een patiënt op naam en opent het juiste voorschrift door op de rij te klikken",
        Scenario = "TS-16.6 Patiënt zoeken (hoofdflow)")]
    public Task UI_16_2_01() => Run(async t =>
    {
        var patient = await t.NewPatient("ui_zoek");
        var other = await t.NewPatient("ui_zoek_ander");
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today, DateTime.Today.AddDays(7), (t.Data.Medicijn("pijnstiller"), 10, "1 tablet per dag"));
        await Env.ArrangePrescriptionAsync(other, Env.Huisarts, DateTime.Today, DateTime.Today.AddDays(7), (t.Data.Medicijn("antibioticum"), 21, "3x per dag"));
        var b = await t.BrowserLoggedInAs(Env.Apotheker);
        b.ClickAndWait("[name=menu_patients]", "menu Patients");
        b.Type("#searchName", patient.Username, "zoekveld");
        b.ClickAndWait(b.ButtonWithText("Search"), "Search");
        var names = b.Rows("table").Select(r => r[1]).ToList();
        t.Check(names.Count == 1 && names[0] == patient.Username, "Zoekresultaat", patient.Username, string.Join(", ", names));
        t.Step("Op de rij van de patiënt klikken");
        b.ClickAndWait("table tbody tr", "rij " + patient.Username);
        var meds = b.Rows(".prescription-card table").Select(r => r[0]).ToList();
        t.Check(b.Path.Contains($"patientId={patient.Id}") && meds.SequenceEqual(new[] { "Panadol" }), "Voorschrift van de juiste patiënt", "Panadol",
            $"{b.Path}: {string.Join(", ", meds)}");
    });

    // ---------- Story 28: medicijnen beheren ----------

    [Fact, Testcase("UI-28.1-01", "AC-28.1", "Browser: apotheker voegt via 'Create New Medicine' een medicijn toe",
        Scenario = "TS-28.1 Medicijn toevoegen (hoofdflow)")]
    public Task UI_28_1_01() => Run(async t =>
    {
        var name = "UiNieuw_" + Guid.NewGuid().ToString("N")[..6];
        var b = await t.BrowserLoggedInAs(Env.Apotheker);
        b.ClickAndWait("[name=menu_medicine]", "menu Medicines");
        b.ClickAndWait(b.ButtonWithText("Create New Medicine"), "Create New Medicine");
        var fields = b.All("main input:not([type=hidden]), main select").Select(e => e.GetAttribute("name")).ToList();
        t.Info("Velden op het scherm: " + string.Join(", ", fields));
        b.Type("#Medicine_TradeName", name, "Trade Name");
        b.Type("#ActiveSubstancesInput", "Paracetamol", "Active Substances");
        b.ClickAndWait(b.ButtonWithText("Create"), "Create");
        var visible = b.All(".text-danger").Select(e => e.Text.Trim()).Where(x => x.Length > 0).ToList();
        if (visible.Count > 0) t.Info("Meldingen: " + string.Join(" / ", visible));
        t.Check(b.Path.StartsWith("/Medicine") && !b.Path.Contains("Create") && b.Rows("table.medicine-table").Any(r => r[0] == name),
            "Medicijn in het overzicht na Create", name, $"{b.Path}, {(visible.Count > 0 ? string.Join(" / ", visible) : "geen melding")}");
    });

    [Fact, Testcase("UI-28.1-02", "AC-28.1", "Browser: apotheker zoekt een medicijn, opent het via de rij en wijzigt sterkte en voorraadstatus",
        Scenario = "TS-28.4 Medicijn wijzigen (hoofdflow)")]
    public Task UI_28_1_02() => Run(async t =>
    {
        var med = await Env.ArrangeMedicineAsync("UiWijzig");
        var b = await t.BrowserLoggedInAs(Env.Apotheker);
        b.ClickAndWait("[name=menu_medicine]", "menu Medicines");
        b.Type("#tradeNameInput", med.TradeName, "Trade Name filter");
        b.ClickAndWait(b.ButtonWithText("Search"), "Search (Trade Name)");
        b.ClickAndWait("table.medicine-table tbody tr", "rij " + med.TradeName);
        b.ClickAndWait(b.ButtonWithText("Edit"), "Edit");

        t.Step("Sterkte naar 25mg en voorraad naar 'Gelimiteerd'; eerst Cancel om de waarschuwing te controleren");
        b.Type("#strength", "25mg", "Strength");
        b.Select("#stockStatus", "2", "Stock Status");
        b.Click("#btnCancel", "Cancel");
        t.Check(b.WaitUntil(() => b.Exists("#discardModal")), "Waarschuwing bij niet-opgeslagen wijzigingen", "dialoog 'Unsaved Changes'",
            b.Exists("#discardModal") ? "getoond" : "niet getoond");
        b.Click(b.FindXPath("//div[@id='discardModal']//button[normalize-space()='Keep Editing']"), "Keep Editing");
        b.WaitUntil(() => !b.Exists("#discardModal"));
        b.ClickAndWait(b.ButtonWithText("Save"), "Save");

        var details = b.Find("dl, .container, main").Text;
        t.Check(details.Contains("25mg"), "Details na opslaan", "sterkte 25mg", details.Contains("25mg") ? "25mg" : "oude waarde");
        var stored = await Env.MedicineAsync(med.Id);
        t.Check(stored!.Strength == "25mg" && stored.StockStatus == 2, "Database", "25mg, voorraad 2", $"{stored.Strength}, voorraad {stored.StockStatus}");
    });

    [Fact, Testcase("UI-28.1-03", "AC-28.1", "Browser: apotheker verwijdert een medicijn via de bevestigingsdialoog; het verdwijnt uit het overzicht",
        Scenario = "TS-28.5 Medicijn verwijderen (hoofdflow)")]
    public Task UI_28_1_03() => Run(async t =>
    {
        var med = await Env.ArrangeMedicineAsync("UiVerwijder");
        var b = await t.BrowserLoggedInAs(Env.Apotheker);
        b.Open($"/Medicine/Edit/{med.Id}");
        b.Click("#btnDelete", "Delete");
        t.Check(b.WaitUntil(() => b.Exists("#deleteModal")), "Bevestigingsdialoog", "getoond", b.Exists("#deleteModal") ? "getoond" : "niet getoond");
        t.Info("Tekst dialoog: " + b.Text("#deleteModal .modal-body"));
        b.ClickAndWait(b.FindXPath("//div[@id='deleteModal']//form//button[normalize-space()='Delete']"), "Delete (bevestigen)");
        var names = b.Rows("table.medicine-table").Select(r => r[0]).ToList();
        t.Check(b.Path.StartsWith("/Medicine") && !names.Contains(med.TradeName), "Medicijn uit het overzicht", "afwezig", names.Contains(med.TradeName) ? "nog aanwezig" : "afwezig");
    });

    [Fact, Testcase("UI-28.2-01", "AC-28.2", "Browser: huisarts ziet geen menu 'Medicines' en krijgt 'Access Denied' bij het openen van het medicijnoverzicht",
        Soort = Soort.Negatief, Scenario = "TS-28.7 Alleen apotheker")]
    public Task UI_28_2_01() => Run(async t =>
    {
        var b = await t.BrowserLoggedInAs(Env.Huisarts);
        t.Check(!b.Exists("[name=menu_medicine]"), "Menu 'Medicines'", "niet zichtbaar", b.Exists("[name=menu_medicine]") ? "zichtbaar" : "niet zichtbaar");
        b.Open("/Medicine/Index");
        t.Check(b.Text("h4").Contains("Access Denied") && !b.Exists("table.medicine-table"), "Medicijnoverzicht via de URL", "Access Denied",
            $"{b.Path} \"{b.Text("h4")}\"");
    });
}
