using LU2_software_testen.Models;
using MMA.Tests.Infrastructure;
using Xunit;

namespace MMA.Tests.Testcases;

/// <summary>Opdracht nr. 7 / deel 1 nr. 11: Als arts wil ik medicatie kunnen voorschrijven aan een patiënt.</summary>
public sealed class US11_MedicatieVoorschrijven(TestEnvironment env) : MmaTestBase(env)
{
    private async Task<(PrescriptionInput input, MedicineLine line)> Standard(TestAccount patient, string medicineKey = "pijnstiller")
    {
        var id = await Env.MedicineIdAsync(Env.Data.Medicijn(medicineKey));
        var input = new PrescriptionInput { PatientId = patient.Id.ToString(), Description = "Testvoorschrift" };
        return (input, new MedicineLine(id, 20, "1 tablet, 3x per dag, na het eten"));
    }

    private async Task PrescribeAndVerify(TestCaseContext t, TestAccount prescriber)
    {
        var patient = await t.NewPatient("voorschrift");
        var (input, line) = await Standard(patient);
        var doctor = await t.LoggedInAs(prescriber);

        t.Step("Nieuw voorschrift openen, patiënt kiezen, medicijn toevoegen en bevestigen");
        var result = await doctor.PrescribeAsync(input, line);
        t.Check(result.IsRedirect && result.Location?.EndsWith("/Prescriptions") == true, "Voorschrift bevestigd", "doorverwijzing naar /Prescriptions", result.Describe());
        var overview = await doctor.GetAsync(result.Location!);
        t.Check(overview.Contains("Prescription successfully created"), "Bevestigingsmelding", "Prescription successfully created",
            overview.Q("#successMessage")?.TextContent.Trim() ?? "geen melding");

        t.Step("Patiëntdossier in database controleren");
        var stored = await Env.PrescriptionsOfAsync(patient.Id);
        t.Check(stored.Count == 1, "Aantal voorschriften bij patiënt", "1", stored.Count.ToString());
        var p = stored[0];
        t.Check(p.PrescriberID == prescriber.Id, "Voorschrijver vastgelegd", prescriber.Id.ToString(), p.PrescriberID.ToString());
        t.Check(p.PrescriptionDate == DateTime.Today, "Voorschrijfdatum", DateTime.Today.ToString("yyyy-MM-dd"), p.PrescriptionDate.ToString("yyyy-MM-dd"));
        var lines = await Env.PrescriptionLinesAsync(p.Id);
        t.Check(lines.Count == 1 && lines[0].MedicineID == line.MedicineId, "Medicijn in voorschrift", $"medicijn {line.MedicineId}",
            string.Join(", ", lines.Select(l => $"medicijn {l.MedicineID}")));
    }

    [Fact, Testcase("TC-11.1-01", "AC-11.1", "Huisarts schrijft een medicijn voor; voorschrift wordt opgeslagen in het patiëntdossier",
        Scenario = "TS-11.1 Voorschrift vastleggen (hoofdflow)")]
    public Task TC_11_1_01() => Run(t => PrescribeAndVerify(t, Env.Huisarts));

    [Fact, Testcase("TC-11.1-02", "AC-11.1", "Specialist schrijft een medicijn voor; voorschrift wordt opgeslagen",
        Scenario = "TS-11.1 Voorschrift vastleggen (hoofdflow)")]
    public Task TC_11_1_02() => Run(t => PrescribeAndVerify(t, Env.Specialist));

    [Fact, Testcase("TC-11.1-03", "AC-11.1", "Voorschrift met meerdere medicijnen wordt volledig opgeslagen",
        Soort = Soort.Alternatief, Scenario = "TS-11.2 Voorschrift met meerdere medicijnen")]
    public Task TC_11_1_03() => Run(async t =>
    {
        var patient = await t.NewPatient("meerdere");
        var input = new PrescriptionInput { PatientId = patient.Id.ToString(), Description = "Combinatie" };
        var lines = new[]
        {
            new MedicineLine(await Env.MedicineIdAsync(t.Data.Medicijn("ontstekingsremmer")), 30, "1 tablet 3x per dag"),
            new MedicineLine(await Env.MedicineIdAsync(t.Data.Medicijn("maagbeschermer")), 14, "1 capsule voor het ontbijt")
        };
        var doctor = await t.LoggedInAs(Env.Huisarts);
        t.Step("Voorschrift met twee medicijnen vastleggen");
        await doctor.PrescribeAsync(input, lines);

        var stored = await Env.PrescriptionsOfAsync(patient.Id);
        t.Check(stored.Count == 1, "Eén voorschrift opgeslagen", "1", stored.Count.ToString());
        var saved = await Env.PrescriptionLinesAsync(stored[0].Id);
        t.Check(saved.Count == 2, "Aantal medicijnen in voorschrift", "2", saved.Count.ToString());
    });

    [Fact, Testcase("TC-11.1-04", "AC-11.1", "Bij het kiezen van een patiënt worden alleen patiënten aangeboden",
        Soort = Soort.Negatief, Scenario = "TS-11.3 Juiste patiënt selecteren")]
    public Task TC_11_1_04() => Run(async t =>
    {
        await t.NewPatient("keuzelijst");
        var doctor = await t.LoggedInAs(Env.Huisarts);
        var page = await doctor.GetAsync("/Prescriptions/New");
        var options = page.QA("#patientSelect option").Select(o => o.TextContent.Trim()).Where(o => !o.StartsWith("--")).ToList();
        var nonPatients = new[] { Env.Beheerder, Env.Huisarts, Env.Specialist, Env.Apotheker, Env.Verzekeraar }
            .Where(a => options.Any(o => o.StartsWith(a.Username + " "))).Select(a => $"{a.Username} ({a.Role})").ToList();
        t.Info($"Keuzelijst bevat {options.Count} personen");
        t.Check(nonPatients.Count == 0, "Alleen patiënten kiesbaar", "geen beheerder/artsen/apotheker/verzekeraar",
            nonPatients.Count == 0 ? "alleen patiënten" : "ook: " + string.Join(", ", nonPatients));
    });

    [Fact, Testcase("TC-11.1-05", "AC-11.1", "Voorschrijven aan een gebruiker die geen patiënt is wordt geweigerd",
        Soort = Soort.Negatief, Scenario = "TS-11.3 Juiste patiënt selecteren")]
    public Task TC_11_1_05() => Run(async t =>
    {
        var notAPatient = await t.NewUser("geen_patient", UserRoleType.apothecary);
        var (input, line) = await Standard(notAPatient);
        var doctor = await t.LoggedInAs(Env.Huisarts);
        t.Step($"Voorschrift vastleggen voor {notAPatient.Username} (rol apotheker)");
        await doctor.PrescribeAsync(input, line);
        var stored = await Env.PrescriptionsOfAsync(notAPatient.Id);
        t.Check(stored.Count == 0, "Geen voorschrift opgeslagen voor niet-patiënt", "0", stored.Count.ToString());
    });

    [Fact, Testcase("TC-11.1-06", "AC-11.1", "Anonieme bezoeker kan geen voorschrift openen of opslaan",
        Soort = Soort.Negatief, Scenario = "TS-11.4 Onbevoegde gebruiker")]
    public Task TC_11_1_06() => Run(async t =>
    {
        var patient = await t.NewPatient("anoniem_doel");
        var (input, line) = await Standard(patient);
        var anon = t.Session("anoniem");

        t.Step("Anoniem het scherm 'New Prescription' openen");
        var page = await anon.GetAsync("/Prescriptions/New");
        var pageBlocked = page.IsRedirect || page.StatusCode is 401 or 403;

        t.Step("Anoniem een volledig voorschrift versturen");
        await anon.PrescribeAsync(input, line);
        var stored = await Env.PrescriptionsOfAsync(patient.Id);
        if (stored.Count > 0) t.Info($"Opgeslagen voorschrift {stored[0].Id} met PrescriberID {stored[0].PrescriberID}");

        t.Check(pageBlocked, "Scherm voorschrijven afgeschermd", "doorverwijzing naar inlogpagina", page.Describe());
        t.Check(stored.Count == 0, "Geen voorschrift opgeslagen", "0", stored.Count.ToString());
    });

    [Fact, Testcase("TC-11.1-07", "AC-11.1", "Beheerder, apotheker en zorgverzekeraar kunnen geen medicatie voorschrijven",
        Soort = Soort.Negatief, Scenario = "TS-11.4 Onbevoegde gebruiker")]
    public Task TC_11_1_07() => Run(async t =>
    {
        var results = new List<string>();
        foreach (var account in new[] { Env.Beheerder, Env.Apotheker, Env.Verzekeraar })
        {
            var patient = await t.NewPatient("onbevoegd_doel");
            var (input, line) = await Standard(patient);
            var s = await t.LoggedInAs(account);
            t.Step($"{account.Role} verstuurt een voorschrift");
            await s.PrescribeAsync(input, line);
            var count = (await Env.PrescriptionsOfAsync(patient.Id)).Count;
            t.Info($"{account.Role}: {count} voorschrift(en) opgeslagen");
            if (count > 0) results.Add(account.Role.ToString());
        }
        t.Check(results.Count == 0, "Geen voorschrift door niet-artsen", "geen", results.Count == 0 ? "geen" : "opgeslagen door: " + string.Join(", ", results));
    });

    [Fact, Testcase("TC-11.1-08", "AC-11.1", "Patiënt kan geen voorschrift opstellen",
        Soort = Soort.Negatief, Scenario = "TS-11.4 Onbevoegde gebruiker")]
    public Task TC_11_1_08() => Run(async t =>
    {
        var patient = await t.NewPatient("zelf_voorschrijven");
        var s = await t.LoggedInAs(patient);
        var page = await s.GetAsync("/Prescriptions/New");
        t.CheckRedirectedAwayFrom(page, "/Prescriptions/New", "Patiënt opent scherm voorschrijven");
    });

    [Fact, Testcase("TC-11.2-01", "AC-11.2", "Voorschrift zonder medicijn kan niet worden opgeslagen",
        Soort = Soort.Negatief, Scenario = "TS-11.5 Verplichte velden ontbreken")]
    public Task TC_11_2_01() => Run(async t =>
    {
        var patient = await t.NewPatient("zonder_medicijn");
        var doctor = await t.LoggedInAs(Env.Huisarts);
        var input = new PrescriptionInput { PatientId = patient.Id.ToString() };
        t.Step("Voorschrift bevestigen zonder medicijn toe te voegen");
        var result = await doctor.ConfirmPrescriptionAsync(input);
        t.Check(result.StatusCode == 200 && result.Contains("At least one medicine must be added"), "Foutmelding",
            "melding 'At least one medicine must be added'", result.Describe());
        t.Check((await Env.PrescriptionsOfAsync(patient.Id)).Count == 0, "Niets opgeslagen", "0", (await Env.PrescriptionsOfAsync(patient.Id)).Count.ToString());
    });

    [Fact, Testcase("TC-11.2-02", "AC-11.2", "Voorschrift zonder patiënt kan niet worden opgeslagen",
        Soort = Soort.Negatief, Scenario = "TS-11.5 Verplichte velden ontbreken")]
    public Task TC_11_2_02() => Run(async t =>
    {
        var doctor = await t.LoggedInAs(Env.Huisarts);
        var before = await Env.WithDbAsync(db => Task.FromResult(db.Prescriptions.Count()));
        var input = new PrescriptionInput { PatientId = "" };
        var line = new MedicineLine(await Env.MedicineIdAsync(t.Data.Medicijn("pijnstiller")), 10, "1 tablet per dag");
        t.Step("Medicijn toevoegen maar geen patiënt kiezen en bevestigen");
        var result = await doctor.PrescribeAsync(input, line);
        var message = result.Q("span[data-valmsg-for='Prescription.PatientID']")?.TextContent.Trim() ?? "";
        t.Check(result.StatusCode == 200 && message.Length > 0, "Foutmelding bij veld Patient", "melding bij het patiëntveld",
            message.Length > 0 ? $"'{message}'" : result.Describe());
        var after = await Env.WithDbAsync(db => Task.FromResult(db.Prescriptions.Count()));
        t.Check(after == before, "Niets opgeslagen", before.ToString(), after.ToString());
    });

    [Fact, Testcase("TC-11.2-03", "AC-11.2", "Medicijn toevoegen zonder een medicijn te kiezen wordt geweigerd",
        Soort = Soort.Negatief, Scenario = "TS-11.5 Verplichte velden ontbreken")]
    public Task TC_11_2_03() => Run(async t =>
    {
        var patient = await t.NewPatient("geen_keuze");
        var doctor = await t.LoggedInAs(Env.Huisarts);
        var input = new PrescriptionInput { PatientId = patient.Id.ToString() };
        await doctor.StartPrescriptionAsync(input);
        t.Step("Toevoegen met leeg medicijnveld");
        var add = await doctor.AddMedicineAsync("", "10", "1 tablet per dag");
        t.Check(add.StatusCode == 200, "Formulier opnieuw getoond (niet toegevoegd)", "200 met validatie", add.Describe());
        var confirm = await doctor.ConfirmPrescriptionAsync(input);
        t.Check(confirm.StatusCode == 200 && (await Env.PrescriptionsOfAsync(patient.Id)).Count == 0, "Voorschrift niet op te slaan", "niet opgeslagen", confirm.Describe());
    });

    [Fact, Testcase("TC-11.2-04", "AC-11.2", "Medicijn zonder dosering (instructies) wordt geweigerd",
        Soort = Soort.Negatief, Scenario = "TS-11.5 Verplichte velden ontbreken")]
    public Task TC_11_2_04() => Run(async t =>
    {
        var patient = await t.NewPatient("geen_dosering");
        var doctor = await t.LoggedInAs(Env.Huisarts);
        var input = new PrescriptionInput { PatientId = patient.Id.ToString() };
        await doctor.StartPrescriptionAsync(input);
        var id = await Env.MedicineIdAsync(t.Data.Medicijn("pijnstiller"));
        t.Step("Medicijn toevoegen met lege instructies");
        var add = await doctor.AddMedicineAsync(id.ToString(), "10", "");
        t.Check(add.StatusCode == 200, "Formulier opnieuw getoond (niet toegevoegd)", "200 met validatie", add.Describe());
        await doctor.ConfirmPrescriptionAsync(input);
        var count = (await Env.PrescriptionsOfAsync(patient.Id)).Count;
        t.Check(count == 0, "Voorschrift niet opgeslagen", "0", count.ToString());
    });

    [Fact, Testcase("TC-11.2-05", "AC-11.2", "Hoeveelheid leeg, 0 of negatief wordt geweigerd",
        Soort = Soort.Negatief, Scenario = "TS-11.6 Ongeldige dosering")]
    public Task TC_11_2_05() => Run(async t =>
    {
        var id = await Env.MedicineIdAsync(t.Data.Medicijn("pijnstiller"));
        var accepted = new List<string>();
        foreach (var quantity in new[] { "", "0", "-5" })
        {
            var patient = await t.NewPatient("hoeveelheid");
            var doctor = await t.LoggedInAs(Env.Huisarts, $"huisarts-hoeveelheid'{quantity}'");
            var input = new PrescriptionInput { PatientId = patient.Id.ToString() };
            await doctor.StartPrescriptionAsync(input);
            t.Step($"Medicijn toevoegen met hoeveelheid '{quantity}' en bevestigen");
            await doctor.AddMedicineAsync(id.ToString(), quantity, "1 tablet per dag");
            await doctor.ConfirmPrescriptionAsync(input);
            var stored = await Env.PrescriptionsOfAsync(patient.Id);
            if (stored.Count == 0)
            {
                t.Info($"Hoeveelheid '{quantity}': geweigerd, niet opgeslagen");
                continue;
            }
            var saved = (await Env.PrescriptionLinesAsync(stored[0].Id)).Select(l => l.Quantity);
            t.Info($"Hoeveelheid '{quantity}': opgeslagen met hoeveelheid {string.Join(",", saved)}");
            accepted.Add($"'{quantity}'");
        }
        t.Check(accepted.Count == 0, "Ongeldige hoeveelheden geweigerd", "alle drie geweigerd",
            accepted.Count == 0 ? "alle drie geweigerd" : "geaccepteerd: " + string.Join(", ", accepted));
    });

    [Fact, Testcase("TC-11.2-06", "AC-11.2", "Einddatum vóór of gelijk aan de startdatum wordt geweigerd",
        Soort = Soort.Negatief, Scenario = "TS-11.7 Ongeldige periode")]
    public Task TC_11_2_06() => Run(async t =>
    {
        var patient = await t.NewPatient("periode");
        var doctor = await t.LoggedInAs(Env.Huisarts);
        var input = new PrescriptionInput { PatientId = patient.Id.ToString(), Start = DateTime.Today, End = DateTime.Today };
        var line = new MedicineLine(await Env.MedicineIdAsync(t.Data.Medicijn("pijnstiller")), 10, "1 tablet per dag");
        t.Step("Voorschrift met einddatum gelijk aan startdatum bevestigen");
        var result = await doctor.PrescribeAsync(input, line);
        t.Check(result.StatusCode == 200 && result.Contains("end date must be at least one day after"), "Foutmelding periode",
            "melding over einddatum", result.Describe());
        t.Check((await Env.PrescriptionsOfAsync(patient.Id)).Count == 0, "Niets opgeslagen", "0", (await Env.PrescriptionsOfAsync(patient.Id)).Count.ToString());
    });

    [Fact, Testcase("TC-11.2-07", "AC-11.2", "Voorschrift met een geldig medicijn en een medicijn met hoeveelheid 0: de arts krijgt een melding, er wordt niets stil weggelaten (toegevoegd in week 7)",
        Soort = Soort.Negatief, Scenario = "TS-11.6 Ongeldige dosering")]
    public Task TC_11_2_07() => Run(async t =>
    {
        var patient = await t.NewPatient("deels_ongeldig");
        var doctor = await t.LoggedInAs(Env.Huisarts);
        var input = new PrescriptionInput { PatientId = patient.Id.ToString() };
        var valid = await Env.MedicineIdAsync(t.Data.Medicijn("pijnstiller"));
        var invalid = await Env.MedicineIdAsync(t.Data.Medicijn("antibioticum"));
        await doctor.StartPrescriptionAsync(input);
        t.Step("Panadol met hoeveelheid 10 en Amoxicillin met hoeveelheid 0 toevoegen en bevestigen");
        await doctor.AddMedicineAsync(valid.ToString(), "10", "1 tablet per dag");
        await doctor.AddMedicineAsync(invalid.ToString(), "0", "1 capsule 3x per dag");
        var result = await doctor.ConfirmPrescriptionAsync(input);
        var stored = await Env.PrescriptionsOfAsync(patient.Id);
        var lines = stored.Count == 0 ? new List<PrescriptionMedicine>() : await Env.PrescriptionLinesAsync(stored[0].Id);
        t.Info($"Antwoord {result.Describe()}; opgeslagen: {(stored.Count == 0 ? "niets" : string.Join(", ", lines.Select(l => $"medicijn {l.MedicineID} x{l.Quantity}")))}");
        var silentlyDropped = stored.Count == 1 && lines.Count == 1;
        t.Check(!silentlyDropped && (stored.Count == 0 || lines.Count == 2) , "Ongeldige regel niet stil weggelaten",
            "geweigerd met melding (of beide regels zichtbaar gecorrigeerd)", silentlyDropped ? "voorschrift opgeslagen zonder Amoxicillin, zonder melding" : "geweigerd");
    });

    [Fact, Testcase("EXT-11-03", ReportWriter.Extra, "Hetzelfde medicijn twee keer toevoegen aan één voorschrift (gedrag sinds week 7)",
        Story = 11, Soort = Soort.Observatie, Scenario = "Verkennend: wijzigingen in het voorschrijven t.o.v. week 4")]
    public Task EXT_11_03() => Run(async t =>
    {
        var patient = await t.NewPatient("dubbel");
        var doctor = await t.LoggedInAs(Env.Huisarts);
        var id = await Env.MedicineIdAsync(t.Data.Medicijn("pijnstiller"));
        await doctor.PrescribeAsync(new PrescriptionInput { PatientId = patient.Id.ToString() },
            new MedicineLine(id, 10, "1 tablet 's ochtends"), new MedicineLine(id, 5, "1 tablet 's avonds"));
        var stored = await Env.PrescriptionsOfAsync(patient.Id);
        var lines = stored.Count == 0 ? new List<PrescriptionMedicine>() : await Env.PrescriptionLinesAsync(stored[0].Id);
        t.Observe(lines.Count == 1
            ? $"Twee regels Panadol (10 en 5) worden zonder melding samengevoegd tot één regel: hoeveelheid {lines[0].Quantity}, instructies '{lines[0].Instructions}'."
            : $"Resultaat: {lines.Count} regel(s) opgeslagen.");
    });

    [Fact, Testcase("EXT-11-02", ReportWriter.Extra, "Omschrijving blijkt verplicht, terwijl het scherm dat niet aangeeft",
        Story = 11, Soort = Soort.Observatie, Scenario = "Verkennend: verplichte velden in het scherm")]
    public Task EXT_11_02() => Run(async t =>
    {
        var patient = await t.NewPatient("zonder_omschrijving");
        var doctor = await t.LoggedInAs(Env.Huisarts);
        var input = new PrescriptionInput { PatientId = patient.Id.ToString(), Description = "" };
        var result = await doctor.PrescribeAsync(input, new MedicineLine(await Env.MedicineIdAsync(t.Data.Medicijn("pijnstiller")), 10, "1 tablet per dag"));
        var message = result.Q("span[data-valmsg-for='Prescription.Description']")?.TextContent.Trim() ?? "";
        var saved = (await Env.PrescriptionsOfAsync(patient.Id)).Count;
        var marked = result.Q("label[for='Prescription_Description']")?.TextContent.Trim() ?? "";
        t.Observe($"Voorschrift met lege omschrijving: {(saved == 0 ? "niet opgeslagen" : "opgeslagen")}, melding '{message}'. Label in het scherm: '{marked}' (geen markering als verplicht veld).");
    });

    [Fact, Testcase("EXT-11-01", ReportWriter.Extra, "Overzicht 'Prescriptions' toont namen, e-mailadressen en telefoonnummers van alle gebruikers zonder in te loggen",
        Story = 11, Soort = Soort.Negatief, Scenario = "Aanvullend: privacy (AVG) en toegangsbeveiliging")]
    public Task EXT_11_01() => Run(async t =>
    {
        var anon = t.Session("anoniem");
        var page = await anon.GetAsync("/Prescriptions");
        var rows = page.QA("#userTableBody tr").Count();
        t.Info($"Antwoord {page.Describe()}, {rows} gebruikers in de tabel");
        t.Check(page.IsRedirect || rows == 0, "Persoonsgegevens afgeschermd voor anonieme bezoeker", "doorverwijzing naar inlogpagina",
            $"{page.Describe()} met {rows} gebruikers (naam, e-mail, telefoon)");
    });
}
