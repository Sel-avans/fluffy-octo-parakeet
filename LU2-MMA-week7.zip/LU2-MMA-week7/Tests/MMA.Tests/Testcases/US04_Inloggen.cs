using MMA.Tests.Infrastructure;
using Xunit;

namespace MMA.Tests.Testcases;

/// <summary>Opdracht nr. 4 / deel 1 nr. 4: Als patiënt wil ik kunnen inloggen met mijn persoonlijke gegevens.</summary>
public sealed class US04_Inloggen(TestEnvironment env) : MmaTestBase(env)
{
    private const string ErrorText = "Username/password not recognized";

    [Fact, Testcase("TC-4.1-01", "AC-4.1", "Patiënt logt in met geldige gegevens en ziet alleen het eigen medicatieoverzicht",
        Scenario = "TS-4.1 Inloggen met geldige gegevens (hoofdflow)")]
    public Task TC_4_1_01() => Run(async t =>
    {
        var patientA = await t.NewPatient("inlog_a");
        var patientB = await t.NewPatient("inlog_b");
        var tradeA = t.Data.Medicijn("pijnstiller");
        var tradeB = t.Data.Medicijn("antibioticum");
        await Env.ArrangePrescriptionAsync(patientA, Env.Huisarts, DateTime.Today, DateTime.Today.AddDays(7), (tradeA, 10, "1 tablet 3x per dag"));
        await Env.ArrangePrescriptionAsync(patientB, Env.Huisarts, DateTime.Today, DateTime.Today.AddDays(7), (tradeB, 21, "1 capsule 3x per dag"));
        t.Info($"Gegeven: {patientA.Username} heeft {tradeA}, {patientB.Username} heeft {tradeB}");

        var s = t.Session(patientA.Username);
        t.Step("Inloggen als patiënt A");
        var login = await s.LoginAsync(patientA);
        t.Check(login.IsRedirect && login.Location == "/Prescriptions/MyPrescriptions", "Doorverwijzing na inloggen",
            "/Prescriptions/MyPrescriptions", login.Describe());

        var overview = await s.GetMyPrescriptionsAsync();
        t.Check(overview.Page.LoggedInUser == patientA.Username, "Ingelogde gebruiker in navigatie", patientA.Username, overview.Page.LoggedInUser);
        t.Check(overview.HasMedicine(tradeA), "Eigen medicatie zichtbaar", tradeA, string.Join(", ", overview.Rows.Select(r => r.Medicine)));
        t.Check(!overview.HasMedicine(tradeB), "Medicatie van andere patiënt niet zichtbaar", $"geen {tradeB}", string.Join(", ", overview.Rows.Select(r => r.Medicine)));
    });

    [Fact, Testcase("TC-4.1-02", "AC-4.1", "Ingelogde patiënt kan geen andere schermen openen en komt terug op het eigen overzicht",
        Soort = Soort.Alternatief, Scenario = "TS-4.2 Patiënt navigeert buiten het eigen overzicht")]
    public Task TC_4_1_02() => Run(async t =>
    {
        var patient = await t.NewPatient("inlog_nav");
        var s = await t.LoggedInAs(patient);
        foreach (var url in new[] { "/", "/Users", "/LogFiles", "/Prescriptions", "/Prescriptions/New", "/Medicine" })
        {
            t.Step($"Patiënt opent {url}");
            var page = await s.BrowseAsync(url);
            var heading = page.Q("h2")?.TextContent.Trim() ?? "";
            t.Check(heading == "My Current Prescriptions", $"Eindpagina na openen {url}", "eigen medicatieoverzicht", heading.Length > 0 ? heading : page.Describe());
        }
    });

    [Fact, Testcase("TC-4.1-03", "AC-4.1", "Na uitloggen is het medicatieoverzicht niet meer bereikbaar",
        Soort = Soort.Alternatief, Scenario = "TS-4.3 Uitloggen (exitsituatie)")]
    public Task TC_4_1_03() => Run(async t =>
    {
        var patient = await t.NewPatient("inlog_uit");
        var s = await t.LoggedInAs(patient);
        t.Step("Uitloggen");
        var logout = await s.LogoutAsync();
        t.Check(logout.IsRedirect, "Uitloggen verwerkt", "doorverwijzing", logout.Describe());
        var page = await s.GetAsync("/Prescriptions/MyPrescriptions");
        t.Check(page.IsRedirect && page.Location?.Contains("/Account/Login") == true, "Overzicht na uitloggen",
            "doorverwijzing naar inlogpagina", page.Describe());
    });

    [Fact, Testcase("TC-4.2-01", "AC-4.2", "Onjuist wachtwoord: geen toegang en foutmelding",
        Soort = Soort.Negatief, Scenario = "TS-4.4 Inloggen met onjuiste gegevens")]
    public Task TC_4_2_01() => Run(async t =>
    {
        var patient = await t.NewPatient("fout_ww");
        await AssertRejected(t, patient.Username, "verkeerd-wachtwoord");
    });

    [Fact, Testcase("TC-4.2-02", "AC-4.2", "Onbekende gebruikersnaam: geen toegang en foutmelding",
        Soort = Soort.Negatief, Scenario = "TS-4.4 Inloggen met onjuiste gegevens")]
    public Task TC_4_2_02() => Run(t => AssertRejected(t, "bestaat_niet_" + Guid.NewGuid().ToString("N")[..6], "Patient#01"));

    [Fact, Testcase("TC-4.2-03", "AC-4.2", "Bijna juist wachtwoord (andere hoofdletters / extra spatie) geeft geen toegang",
        Soort = Soort.Negatief, Scenario = "TS-4.4 Inloggen met onjuiste gegevens")]
    public Task TC_4_2_03() => Run(async t =>
    {
        var patient = await t.NewPatient("bijna_goed");
        await AssertRejected(t, patient.Username, patient.Password.ToLowerInvariant());
        await AssertRejected(t, patient.Username, patient.Password + " ");
    });

    [Fact, Testcase("TC-4.2-04", "AC-4.2", "Lege velden: geen toegang en melding dat de velden verplicht zijn",
        Soort = Soort.Negatief, Scenario = "TS-4.5 Inloggen zonder gegevens")]
    public Task TC_4_2_04() => Run(async t =>
    {
        var s = t.Session("anoniem");
        t.Step("Inlogformulier versturen zonder gebruikersnaam en wachtwoord");
        var result = await s.LoginAsync("", "");
        var errors = result.QA(".field-validation-error, .validation-summary-errors, .text-danger")
            .Select(e => e.TextContent.Trim()).Where(x => x.Length > 0).ToList();
        t.Check(!result.IsRedirect || result.Location?.Contains("loginError") == true, "Geen toegang", "formulier opnieuw of loginError", result.Describe());
        t.Check(errors.Count > 0 || result.Location?.Contains("loginError") == true, "Foutmelding getoond", "melding verplichte velden", errors.Count > 0 ? string.Join(" / ", errors) : "geen melding");
        await AssertNoAccess(t, s);
    });

    [Fact, Testcase("TC-4.2-05", "AC-4.2", "SQL-injectie in gebruikersnaam geeft geen toegang",
        Soort = Soort.Negatief, Scenario = "TS-4.4 Inloggen met onjuiste gegevens")]
    public Task TC_4_2_05() => Run(t => AssertRejected(t, "admin' OR '1'='1' --", "x' OR '1'='1"));

    [Fact, Testcase("EXT-4-01", ReportWriter.Extra, "Geen blokkade na herhaald foutief inloggen",
        Story = 4, Soort = Soort.Observatie, Scenario = "Verkennend: criterium uit deel 1 dat niet in de oplevering is afgesproken")]
    public Task EXT_4_01() => Run(async t =>
    {
        var patient = await t.NewPatient("blokkade");
        var s = t.Session(patient.Username);
        for (var i = 1; i <= 6; i++) await s.LoginAsync(patient.Username, "fout" + i);
        var login = await s.LoginAsync(patient);
        t.Observe(login.Location == "/Prescriptions/MyPrescriptions"
            ? "Na 6 foutieve pogingen kan de patiënt direct inloggen: er is geen (tijdelijke) blokkade."
            : $"Na 6 foutieve pogingen wordt inloggen geweigerd ({login.Describe()}): er is een blokkade.");
    });

    private static async Task AssertRejected(TestCaseContext t, string username, string password)
    {
        var s = t.Session("anoniem");
        t.Step($"Inloggen met gebruikersnaam '{username}' en een onjuist wachtwoord");
        var result = await s.LoginAsync(username, password);
        t.Check(result.IsRedirect && result.Location?.Contains("loginError=True") == true, "Inloggen geweigerd", "doorverwijzing met loginError", result.Describe());

        var page = await s.BrowseAsync(result.Location!);
        var message = page.Q("#login-error")?.TextContent.Trim() ?? "";
        t.Check(message.Contains(ErrorText), "Foutmelding zichtbaar", ErrorText, message.Length > 0 ? message : "geen melding");
        await AssertNoAccess(t, s);
    }

    private static async Task AssertNoAccess(TestCaseContext t, MmaClient s)
    {
        var page = await s.GetAsync("/Prescriptions/MyPrescriptions");
        t.Check(page.IsRedirect && page.Location?.Contains("/Account/Login") == true, "Geen toegang tot medicatieoverzicht",
            "doorverwijzing naar inlogpagina", page.Describe());
    }
}
