using LU2_software_testen.Models;
using MMA.Tests.Infrastructure;
using Xunit;

namespace MMA.Tests.Testcases;

/// <summary>Week 7, deel 1 nr. 28 (nieuw): Als apotheker wil ik medicijnen kunnen toevoegen, bekijken, wijzigen en verwijderen.</summary>
public sealed class US28_MedicijnenBeheren(TestEnvironment env) : MmaTestBase(env)
{
    private static string Unique(string prefix) => $"{prefix}_{Guid.NewGuid().ToString("N")[..6]}";

    [Fact, Testcase("TC-28.1-01", "AC-28.1", "Apotheker voegt via het scherm een nieuw medicijn toe; het verschijnt in het overzicht en bij het voorschrijven",
        Scenario = "TS-28.1 Medicijn toevoegen (hoofdflow)")]
    public Task TC_28_1_01() => Run(async t =>
    {
        var apo = await t.LoggedInAs(Env.Apotheker);
        var name = Unique("Nieuwmedicijn");

        t.Step("Scherm 'Create Medicine' openen en de aangeboden velden vastleggen");
        var form = await apo.GetAsync("/Medicine/Create");
        var fields = form.QA("main input:not([type=hidden]), main select, main textarea").Select(e => e.GetAttribute("name")).ToList();
        t.Info("Invoervelden: " + string.Join(", ", fields));

        t.Step($"Medicijn '{name}' toevoegen met de velden die het scherm aanbiedt");
        var result = await apo.CreateMedicineAsync(name, "Paracetamol");
        var errors = result.QA(".field-validation-error, .validation-summary-errors li").Select(e => e.TextContent.Trim()).Where(e => e.Length > 0).ToList();
        if (errors.Count > 0) t.Info("Meldingen op het scherm: " + string.Join(" / ", errors));
        var stored = await Env.MedicineByNameAsync(name);
        t.Check(result.IsRedirect && stored != null, "Medicijn opgeslagen", "doorverwijzing naar overzicht, medicijn in database",
            $"{result.Describe()}, {(stored == null ? "niet opgeslagen" : "opgeslagen")}");

        var overview = await apo.GetMedicinesAsync();
        t.Check(overview.Contains(name), "Medicijn in overzicht", name, overview.Contains(name) ? "aanwezig" : "ontbreekt");
        var doctor = await t.LoggedInAs(Env.Huisarts);
        await doctor.StartPrescriptionAsync(new PrescriptionInput { PatientId = (await t.NewPatient("nieuw_med")).Id.ToString() });
        var prescribable = await doctor.PrescribableMedicinesAsync();
        t.Check(prescribable.Contains(name), "Medicijn kiesbaar bij voorschrijven", name, prescribable.Contains(name) ? "kiesbaar" : "niet kiesbaar");
    });

    [Fact, Testcase("TC-28.1-02", "AC-28.1", "Toevoegen zonder handelsnaam of zonder werkzame stof wordt geweigerd met een melding",
        Soort = Soort.Negatief, Scenario = "TS-28.2 Verplichte gegevens ontbreken")]
    public Task TC_28_1_02() => Run(async t =>
    {
        var apo = await t.LoggedInAs(Env.Apotheker);
        var before = await Env.WithDbAsync(db => Task.FromResult(db.Medicines.Count()));

        t.Step("Toevoegen zonder handelsnaam");
        var noName = await apo.CreateMedicineAsync("", "Paracetamol", new() { ["Medicine.Strength"] = "500mg" });
        var nameMsg = noName.Q("span[data-valmsg-for='Medicine.TradeName']")?.TextContent.Trim() ?? "";
        t.Check(noName.StatusCode == 200 && nameMsg.Length > 0, "Melding bij handelsnaam", "formulier met melding", nameMsg.Length > 0 ? $"'{nameMsg}'" : noName.Describe());

        t.Step("Toevoegen zonder werkzame stof");
        var noSubstance = await apo.CreateMedicineAsync(Unique("ZonderStof"), "", new() { ["Medicine.Strength"] = "500mg" });
        var subMsg = noSubstance.Q("span[data-valmsg-for='ActiveSubstancesInput']")?.TextContent.Trim() ?? "";
        t.Check(noSubstance.StatusCode == 200 && subMsg.Length > 0, "Melding bij werkzame stof", "formulier met melding", subMsg.Length > 0 ? $"'{subMsg}'" : noSubstance.Describe());

        var after = await Env.WithDbAsync(db => Task.FromResult(db.Medicines.Count()));
        t.Check(after == before, "Niets opgeslagen", before.ToString(), after.ToString());
    });

    [Fact, Testcase("TC-28.1-03", "AC-28.1", "Toevoegen zonder sterkte wordt geweigerd met een begrijpelijke melding",
        Soort = Soort.Negatief, Scenario = "TS-28.2 Verplichte gegevens ontbreken")]
    public Task TC_28_1_03() => Run(async t =>
    {
        var apo = await t.LoggedInAs(Env.Apotheker);
        var name = Unique("ZonderSterkte");
        var result = await apo.CreateMedicineAsync(name, "Ibuprofen");
        var visible = result.QA(".text-danger, .validation-summary-errors").Select(e => e.TextContent.Trim()).Where(e => e.Length > 0).ToList();
        var stored = await Env.MedicineByNameAsync(name);
        t.Check(stored == null, "Niet opgeslagen zonder sterkte", "niet opgeslagen", stored == null ? "niet opgeslagen" : $"opgeslagen met sterkte '{stored.Strength}'");
        t.Check(visible.Count > 0, "Melding zichtbaar voor de apotheker", "melding over de sterkte", visible.Count > 0 ? string.Join(" / ", visible) : "geen melding zichtbaar");
    });

    [Fact, Testcase("TC-28.1-04", "AC-28.1", "Details van een medicijn tonen handelsnaam, werkzame stof, sterkte en toedieningsvorm",
        Scenario = "TS-28.3 Medicijn bekijken")]
    public Task TC_28_1_04() => Run(async t =>
    {
        var med = await Env.ArrangeMedicineAsync("Bekijkmedicijn", "Metoprolol", "50mg");
        var apo = await t.LoggedInAs(Env.Apotheker);
        var page = await apo.GetAsync($"/Medicine/Details/{med.Id}");
        t.Check(page.StatusCode == 200, "Detailscherm", "200", page.Describe());
        foreach (var expected in new[] { med.TradeName, "Metoprolol", "50mg" })
            t.Check(page.Contains(expected), $"Gegeven '{expected}' zichtbaar", "zichtbaar", page.Contains(expected) ? "zichtbaar" : "ontbreekt");
        var form = page.QA("dt").Select(d => d.TextContent.Trim()).Zip(page.QA("dd").Select(d => d.TextContent.Trim())).FirstOrDefault(p => p.First == "Dosage Form").Second ?? "";
        t.Info($"Toedieningsvorm getoond als: '{form}'");
        t.Check(form == "Tablet", "Toedieningsvorm leesbaar", "Tablet", form);
    });

    [Fact, Testcase("TC-28.1-05", "AC-28.1", "Wijzigen van naam, sterkte en voorraadstatus is direct zichtbaar in overzicht, details en bij voorschrijven",
        Scenario = "TS-28.4 Medicijn wijzigen (hoofdflow)")]
    public Task TC_28_1_05() => Run(async t =>
    {
        var med = await Env.ArrangeMedicineAsync("Wijzigmedicijn");
        var newName = med.TradeName + "_nieuw";
        var apo = await t.LoggedInAs(Env.Apotheker);

        t.Step("Medicijn wijzigen: nieuwe naam, sterkte 20mg, voorraad 'Gelimiteerd'");
        var result = await apo.EditMedicineAsync(med.Id, newName, "Testosubstantie, Hulpstof", "20mg", "1", "2");
        t.Check(result.IsRedirect, "Wijziging opgeslagen", "doorverwijzing naar details", result.Describe());
        var stored = await Env.MedicineAsync(med.Id);
        t.Check(stored!.TradeName == newName && stored.Strength == "20mg" && stored.StockStatus == 2 && stored.ActiveSubstances.Count == 2,
            "Gegevens in database", $"{newName}, 20mg, voorraad 2, 2 stoffen",
            $"{stored.TradeName}, {stored.Strength}, voorraad {stored.StockStatus}, {stored.ActiveSubstances.Count} stoffen");

        var overview = await apo.GetMedicinesAsync(newName);
        var row = overview.Rows.FirstOrDefault(r => r.TradeName == newName);
        t.Check(row != null && row.StockStatus == "Gelimiteerd", "Overzicht toont nieuwe naam en voorraadstatus", $"{newName} / Gelimiteerd",
            row == null ? "niet gevonden" : $"{row.TradeName} / {row.StockStatus}");

        var doctor = await t.LoggedInAs(Env.Huisarts);
        await doctor.StartPrescriptionAsync(new PrescriptionInput { PatientId = (await t.NewPatient("gewijzigd_med")).Id.ToString() });
        var prescribable = await doctor.PrescribableMedicinesAsync();
        t.Check(prescribable.Contains(newName) && !prescribable.Contains(med.TradeName), "Keuzelijst bij voorschrijven", $"nieuwe naam {newName}",
            prescribable.Contains(newName) ? "nieuwe naam" : "oude of geen naam");
    });

    [Fact, Testcase("TC-28.1-06", "AC-28.1", "Wijzigen met lege handelsnaam, werkzame stof of sterkte wordt geweigerd; het medicijn blijft ongewijzigd",
        Soort = Soort.Negatief, Scenario = "TS-28.2 Verplichte gegevens ontbreken")]
    public Task TC_28_1_06() => Run(async t =>
    {
        var med = await Env.ArrangeMedicineAsync("Leegwijzigen", "Testosubstantie", "10mg");
        var apo = await t.LoggedInAs(Env.Apotheker);
        var accepted = new List<string>();
        foreach (var (field, name, sub, strength) in new[]
                 {
                     ("handelsnaam", "", "Testosubstantie", "10mg"),
                     ("werkzame stof", med.TradeName, "", "10mg"),
                     ("sterkte", med.TradeName, "Testosubstantie", "")
                 })
        {
            var result = await apo.EditMedicineAsync(med.Id, name, sub, strength);
            t.Info($"Lege {field}: {result.Describe()}");
            if (result.IsRedirect) accepted.Add(field);
        }
        var stored = await Env.MedicineAsync(med.Id);
        t.Check(accepted.Count == 0, "Lege verplichte velden geweigerd", "alle drie geweigerd", accepted.Count == 0 ? "alle drie geweigerd" : "geaccepteerd: " + string.Join(", ", accepted));
        t.Check(stored!.TradeName == med.TradeName && stored.Strength == "10mg", "Medicijn ongewijzigd", $"{med.TradeName} / 10mg", $"{stored.TradeName} / {stored.Strength}");
    });

    [Fact, Testcase("TC-28.1-07", "AC-28.1", "Verwijderd medicijn verdwijnt uit het overzicht en kan niet meer worden voorgeschreven (ook niet via een direct verzoek)",
        Scenario = "TS-28.5 Medicijn verwijderen (hoofdflow)")]
    public Task TC_28_1_07() => Run(async t =>
    {
        var med = await Env.ArrangeMedicineAsync("Verwijdermedicijn");
        var apo = await t.LoggedInAs(Env.Apotheker);
        t.Step($"Medicijn {med.TradeName} verwijderen via de knop Delete");
        var result = await apo.DeleteMedicineAsync(med.Id);
        t.Check(result.IsRedirect, "Verwijderen verwerkt", "doorverwijzing naar overzicht", result.Describe());
        var overview = await apo.GetMedicinesAsync();
        t.Check(!overview.Contains(med.TradeName), "Niet meer in overzicht", "afwezig", overview.Contains(med.TradeName) ? "nog aanwezig" : "afwezig");

        var patient = await t.NewPatient("verwijderd_voorschrijven");
        var doctor = await t.LoggedInAs(Env.Huisarts);
        var input = new PrescriptionInput { PatientId = patient.Id.ToString() };
        await doctor.StartPrescriptionAsync(input);
        var prescribable = await doctor.PrescribableMedicinesAsync();
        t.Check(!prescribable.Contains(med.TradeName), "Niet kiesbaar bij voorschrijven", "afwezig", prescribable.Contains(med.TradeName) ? "kiesbaar" : "afwezig");

        t.Step("Direct verzoek: verwijderd medicijn toch toevoegen aan een voorschrift");
        await doctor.AddMedicineAsync(med.Id.ToString(), "10", "1 tablet per dag");
        await doctor.ConfirmPrescriptionAsync(input);
        var stored = await Env.PrescriptionsOfAsync(patient.Id);
        t.Check(stored.Count == 0, "Voorschrift met verwijderd medicijn", "niet opgeslagen", stored.Count == 0 ? "niet opgeslagen" : "opgeslagen");
    });

    [Fact, Testcase("TC-28.1-08", "AC-28.1", "Na verwijderen van een medicijn blijven lopende voorschriften leesbaar voor patiënt en apotheker",
        Soort = Soort.Alternatief, Scenario = "TS-28.6 Gevolgen van verwijderen voor bestaande voorschriften")]
    public Task TC_28_1_08() => Run(async t =>
    {
        var patient = await t.NewPatient("na_verwijderen");
        var med = await Env.ArrangeMedicineAsync("Lopendmedicijn");
        var other = t.Data.Medicijn("maagbeschermer");
        await Env.ArrangePrescriptionAsync(patient, Env.Huisarts, DateTime.Today, DateTime.Today.AddDays(10), (med.TradeName, 10, "1 tablet per dag"), (other, 10, "1 capsule per dag"));
        var apo = await t.LoggedInAs(Env.Apotheker);
        t.Step($"Apotheker verwijdert {med.TradeName}");
        await apo.DeleteMedicineAsync(med.Id);

        var mine = await (await t.LoggedInAs(patient)).GetMyPrescriptionsAsync();
        t.Info($"Patiënt ziet: {string.Join(", ", mine.Rows.Select(r => r.Medicine))}");
        var details = await apo.GetPatientDetailsAsync(patient.Id);
        t.Info($"Apotheker: {details.Page.Describe()}, medicijnen {details.MedicineNames}");
        t.Check(mine.HasMedicine(med.TradeName) && mine.HasMedicine(other), "Patiënt ziet het volledige voorschrift", $"{med.TradeName} en {other}",
            string.Join(", ", mine.Rows.Select(r => r.Medicine)));
        t.Check(details.Page.StatusCode == 200 && details.HasMedicine(other), "Apotheker ziet het voorschrift", $"200 met {other}", $"{details.Page.Describe()} / {details.MedicineNames}");
    });

    [Fact, Testcase("TC-28.1-09", "AC-28.1", "Zoeken in het medicijnoverzicht op handelsnaam en op werkzame stof",
        Soort = Soort.Alternatief, Scenario = "TS-28.3 Medicijn bekijken")]
    public Task TC_28_1_09() => Run(async t =>
    {
        var apo = await t.LoggedInAs(Env.Apotheker);
        var byName = await apo.GetMedicinesAsync(tradeName: "Panad");
        t.Check(byName.Rows.Count >= 1 && byName.Rows.All(r => r.TradeName.Contains("Panad")), "Filter handelsnaam 'Panad'", "alleen Panadol", byName.Names);
        var bySubstance = await apo.GetMedicinesAsync(substance: "levothyrox");
        t.Check(bySubstance.Contains("Levothyroxine") && bySubstance.Contains("Synthroid"), "Filter werkzame stof 'levothyrox'", "Levothyroxine en Synthroid", bySubstance.Names);
        var none = await apo.GetMedicinesAsync(tradeName: "bestaatniet");
        t.Check(none.Rows.Count == 0 && none.Page.Contains("No medicines found"), "Geen resultaat", "melding 'No medicines found'", none.Names);
    });

    [Fact, Testcase("TC-28.2-01", "AC-28.2", "Anonieme bezoeker kan de medicijnschermen niet openen",
        Soort = Soort.Negatief, Scenario = "TS-28.7 Alleen apotheker")]
    public Task TC_28_2_01() => Run(async t =>
    {
        var med = await Env.ArrangeMedicineAsync("Anoniemmedicijn");
        var anon = t.Session("anoniem");
        foreach (var url in new[] { "/Medicine/Index", "/Medicine/Create", $"/Medicine/Details/{med.Id}", $"/Medicine/Edit/{med.Id}" })
            t.CheckRedirectedAwayFrom(await anon.GetAsync(url), url.Split('?')[0], $"Anoniem opent {url}");
    });

    [Fact, Testcase("TC-28.2-02", "AC-28.2", "Huisarts, beheerder, zorgverzekeraar en patiënt kunnen medicijnen niet bekijken, toevoegen, wijzigen of verwijderen",
        Soort = Soort.Negatief, Scenario = "TS-28.7 Alleen apotheker")]
    public Task TC_28_2_02() => Run(async t =>
    {
        var patient = await t.NewPatient("geen_apotheker");
        var problems = new List<string>();
        foreach (var account in new[] { Env.Huisarts, Env.Beheerder, Env.Verzekeraar, patient })
        {
            var med = await Env.ArrangeMedicineAsync("Rolmedicijn");
            var s = await t.LoggedInAs(account);
            var role = account.Role.ToString();
            foreach (var url in new[] { "/Medicine/Index", "/Medicine/Create", $"/Medicine/Details/{med.Id}", $"/Medicine/Edit/{med.Id}" })
            {
                var page = await s.GetAsync(url);
                if (page.StatusCode == 200) problems.Add($"{role} opent {url}");
            }
            t.Step($"{role}: toevoegen, wijzigen en verwijderen via directe verzoeken");
            var created = Unique("Onbevoegd");
            await s.CreateMedicineAsync(created, "X", new() { ["Medicine.Strength"] = "1mg" });
            await s.PostFormAsync($"/Medicine/Edit/{med.Id}?handler=Save", new Dictionary<string, string>
            {
                ["Medicine.MedicineID"] = med.Id.ToString(), ["Medicine.TradeName"] = "Gekaapt", ["ActiveSubstancesInput"] = "X", ["Medicine.Strength"] = "1mg"
            }, tokenFrom: "/");
            await s.PostFormAsync($"/Medicine/Edit/{med.Id}?handler=Delete", Array.Empty<KeyValuePair<string, string>>(), tokenFrom: "/");
            var after = await Env.MedicineAsync(med.Id);
            if (await Env.MedicineByNameAsync(created) != null) problems.Add($"{role} voegt toe");
            if (after!.TradeName != med.TradeName) problems.Add($"{role} wijzigt");
            if (after.IsDeleted) problems.Add($"{role} verwijdert");
        }
        t.Check(problems.Count == 0, "Medicijnbeheer afgeschermd voor andere rollen", "geen toegang en geen wijzigingen",
            problems.Count == 0 ? "geen toegang en geen wijzigingen" : string.Join("; ", problems));
    });

    [Fact, Testcase("TC-28.2-04", "AC-28.2", "Tweede bewerkpagina /Medicines/Edit (niet gelinkt) is niet bruikbaar voor anoniemen of andere rollen",
        Soort = Soort.Negatief, Scenario = "TS-28.7 Alleen apotheker")]
    public Task TC_28_2_04() => Run(async t =>
    {
        t.Info("Gevonden bij het inventariseren van alle pagina's: naast /Medicine/Edit bestaat /Medicines/Edit (met s), zonder [Authorize].");
        var problems = new List<string>();
        foreach (var (name, session) in new (string, MmaClient)[] { ("anoniem", t.Session("anoniem")), ("huisarts", await t.LoggedInAs(Env.Huisarts)) })
        {
            var med = await Env.ArrangeMedicineAsync("TweedeEdit", "Testosubstantie", "10mg");
            t.Step($"{name}: /Medicines/Edit/{med.Id} openen en een nieuwe naam en sterkte opslaan");
            var page = await session.GetAsync($"/Medicines/Edit/{med.Id}");
            if (page.StatusCode == 200) problems.Add($"{name} opent de pagina");
            if (page.AntiforgeryToken != null)
            {
                var result = await session.PostRawAsync($"/Medicines/Edit/{med.Id}", new Dictionary<string, string>
                {
                    ["Medicine.MedicineID"] = med.Id.ToString(), ["Medicine.TradeName"] = "Gewijzigd_door_" + name,
                    ["Medicine.ActiveSubstances"] = "Onbekend", ["Medicine.DosageForm"] = "3", ["Medicine.Strength"] = "999mg", ["Medicine.StockStatus"] = "1"
                }, page.AntiforgeryToken);
                t.Info($"{name}: opslaan gaf {result.Describe()}");
            }
            var after = await Env.MedicineAsync(med.Id);
            t.Info($"Medicijn na poging: {after!.TradeName} / {after.Strength}");
            if (after.TradeName != med.TradeName || after.Strength != "10mg") problems.Add($"{name} wijzigt het medicijn (nu '{after.TradeName}', {after.Strength})");
        }
        t.Check(problems.Count == 0, "Medicijnen alleen door apotheker te wijzigen", "geen toegang, medicijn ongewijzigd",
            problems.Count == 0 ? "geen toegang" : string.Join("; ", problems));
    });

    [Fact, Testcase("TC-28.2-03", "AC-28.2", "Menu 'Medicines' is alleen zichtbaar voor de apotheker",
        Soort = Soort.Alternatief, Scenario = "TS-28.7 Alleen apotheker")]
    public Task TC_28_2_03() => Run(async t =>
    {
        var apoHome = await (await t.LoggedInAs(Env.Apotheker)).BrowseAsync("/");
        t.Check(apoHome.Q("[name=menu_medicine]") != null, "Menu voor apotheker", "zichtbaar", apoHome.Q("[name=menu_medicine]") != null ? "zichtbaar" : "niet zichtbaar");
        foreach (var account in new[] { Env.Huisarts, Env.Beheerder, Env.Verzekeraar })
        {
            var home = await (await t.LoggedInAs(account)).BrowseAsync("/");
            t.Check(home.Q("[name=menu_medicine]") == null, $"Menu voor {account.Role}", "niet zichtbaar", home.Q("[name=menu_medicine]") == null ? "niet zichtbaar" : "zichtbaar");
        }
    });

    [Fact, Testcase("EXT-28-01", ReportWriter.Extra, "Verwijderd medicijn: detailscherm, herstellen en dubbele namen",
        Story = 28, Soort = Soort.Observatie, Scenario = "Verkennend: gedrag rond verwijderen en unieke namen")]
    public Task EXT_28_01() => Run(async t =>
    {
        var med = await Env.ArrangeMedicineAsync("Obsmedicijn");
        var apo = await t.LoggedInAs(Env.Apotheker);
        var editPage = await apo.GetAsync($"/Medicine/Edit/{med.Id}");
        var dialog = editPage.Q("#deleteModal .modal-body")?.TextContent.Trim() ?? "";
        await apo.DeleteMedicineAsync(med.Id);
        var stored = await Env.MedicineAsync(med.Id);
        var details = await apo.GetAsync($"/Medicine/Details/{med.Id}");
        t.Observe($"Bevestigingsvraag: '{dialog}'. In werkelijkheid blijft het medicijn in de database staan (IsDeleted = {stored?.IsDeleted}); er is geen scherm om het terug te zetten.");
        t.Observe($"Detailscherm van het verwijderde medicijn via de URL: {details.Describe()}{(details.Contains(med.TradeName) ? ", gegevens zichtbaar met knop Edit" : "")}.");

        var withStrength = Unique("MetSterkte");
        var direct = await apo.CreateMedicineAsync(withStrength, "Paracetamol", new() { ["Medicine.Strength"] = "500mg" });
        t.Observe($"Toevoegen met het veld Strength erbij (direct verzoek, het scherm biedt dit veld niet aan): {direct.Describe()}, " +
                  $"{(await Env.MedicineByNameAsync(withStrength) != null ? "wel opgeslagen; alleen het formulier mist dus het veld" : "ook niet opgeslagen")}.");

        // Eigen medicijnen gebruiken, zodat de seed-data (zoals Panadol) voor andere testcases uniek blijft
        var first = await Env.ArrangeMedicineAsync("Dubbelnaam");
        var dupe = await apo.EditMedicineAsync((await Env.ArrangeMedicineAsync("Dubbel")).Id, first.TradeName, "Testosubstantie", "10mg");
        var count = await Env.WithDbAsync(db => Task.FromResult(db.Medicines.Count(m => m.TradeName == first.TradeName && !m.IsDeleted)));
        t.Observe($"Een tweede medicijn hernoemen naar een bestaande naam ('{first.TradeName}'): {dupe.Describe()}; nu {count} actieve medicijnen met die naam.");
    });

    [Fact, Testcase("EXT-28-02", ReportWriter.Extra, "Toevoegen, wijzigen en verwijderen van medicijnen wordt niet gelogd",
        Story = 28, Soort = Soort.Observatie, Scenario = "Verkennend: audittrail")]
    public Task EXT_28_02() => Run(async t =>
    {
        var med = await Env.ArrangeMedicineAsync("Logmedicijn");
        var apo = await t.LoggedInAs(Env.Apotheker);
        var mark = Env.LogLineCount();
        await apo.EditMedicineAsync(med.Id, med.TradeName + "_x", "Testosubstantie", "10mg");
        await apo.DeleteMedicineAsync(med.Id);
        var lines = File.Exists(Env.TodaysLogFilePath) ? Env.ReadLogLines().Skip(mark).ToList() : new List<string>();
        t.Observe(lines.Count == 0
            ? "Wijzigen en verwijderen van een medicijn leveren geen logregel op; wie het assortiment aanpaste, is niet terug te vinden."
            : "Logregels: " + string.Join(" | ", lines));
    });
}
