using System.Text.RegularExpressions;
using LU2_software_testen.Models;
using MMA.Tests.Infrastructure;
using Xunit;

namespace MMA.Tests.Testcases;

/// <summary>Opdracht nr. 21 / deel 1 nr. 26: Als beheerder wil ik logbestanden kunnen raadplegen.</summary>
public sealed class US26_LogbestandenRaadplegen(TestEnvironment env) : MmaTestBase(env)
{
    private static readonly Regex LogLine = new(@"^(?<tijd>\d{2}:\d{2}:\d{2}): UserID (?<user>\S+): (?<actie>.+)$");

    /// <summary>Haalt de logregels op via het scherm van de beheerder (handler View), alleen de regels na 'mark'.</summary>
    private async Task<List<string>> NewLogLinesViaScreen(TestCaseContext t, MmaClient admin, int mark)
    {
        var view = await admin.GetAsync($"/LogFiles?handler=View&fileName={Env.TodaysLogFileName}");
        t.Check(view.StatusCode == 200, "Logbestand van vandaag te openen", "200", view.Describe());
        var lines = view.Body.Split(Environment.NewLine, StringSplitOptions.RemoveEmptyEntries).Skip(mark).ToList();
        foreach (var l in lines) t.Info("Nieuwe logregel: " + l);
        return lines;
    }

    private void CheckLine(TestCaseContext t, List<string> lines, string actionFragment, int expectedUserId, string what)
    {
        var line = lines.FirstOrDefault(l => l.Contains(actionFragment));
        t.Check(line != null, $"{what}: logregel aanwezig", $"regel met '{actionFragment}'", line ?? "geen regel");
        var m = LogLine.Match(line!);
        t.Check(m.Success, $"{what}: opbouw tijdstip / gebruiker / actie", "HH:mm:ss: UserID <id>: <actie>", line!);
        t.Check(m.Groups["user"].Value == expectedUserId.ToString(), $"{what}: uitvoerende gebruiker", $"UserID {expectedUserId}", $"UserID {m.Groups["user"].Value}");
        var time = TimeSpan.Parse(m.Groups["tijd"].Value);
        var delta = Math.Abs((DateTime.Now.TimeOfDay - time).TotalMinutes);
        t.Check(delta < 5, $"{what}: tijdstip klopt", "binnen 5 minuten van nu", m.Groups["tijd"].Value);
    }

    [Fact, Testcase("TC-26.1-01", "AC-26.1", "Beheerder opent de logbestanden en ziet het logbestand van vandaag",
        Scenario = "TS-26.1 Logbestanden openen (hoofdflow)")]
    public Task TC_26_1_01() => Run(async t =>
    {
        var admin = await t.LoggedInAs(Env.Beheerder);
        var home = await admin.BrowseAsync("/");
        t.Check(home.Q("[name=menu_log_files]") != null, "Menu 'Log files' voor beheerder", "zichtbaar", home.Q("[name=menu_log_files]") != null ? "zichtbaar" : "niet zichtbaar");
        var page = await admin.GetAsync("/LogFiles");
        t.Check(page.StatusCode == 200, "Scherm logbestanden", "200", page.Describe());
        var listed = page.Body.Contains($"\"{Env.TodaysLogFileName}\"");
        t.Check(listed, "Logbestand van vandaag in de lijst", Env.TodaysLogFileName, listed ? "aanwezig" : "ontbreekt");
        var download = await admin.GetAsync($"/LogFiles?handler=Download&fileName={Env.TodaysLogFileName}");
        t.Check(download.StatusCode == 200, "Logbestand te downloaden", "200", download.Describe());
    });

    [Fact, Testcase("TC-26.1-02", "AC-26.1", "Rolwijziging staat in het log met gebruiker, actie en tijdstip",
        Scenario = "TS-26.2 Acties terugvinden in het log")]
    public Task TC_26_1_02() => Run(async t =>
    {
        var user = await t.NewPatient("log_rol");
        var admin = await t.LoggedInAs(Env.Beheerder);
        var mark = Env.LogLineCount();
        t.Step("Beheerder wijzigt een rol");
        await admin.ChangeRoleAsync(user.Id, "specialist");
        var lines = await NewLogLinesViaScreen(t, admin, mark);
        CheckLine(t, lines, $"Role of {user.Id} was changed", Env.Beheerder.Id, "Rolwijziging");
    });

    [Fact, Testcase("TC-26.1-03", "AC-26.1", "Aanmaken van een voorschrift staat in het log met gebruiker, actie en tijdstip",
        Scenario = "TS-26.2 Acties terugvinden in het log")]
    public Task TC_26_1_03() => Run(async t =>
    {
        var patient = await t.NewPatient("log_voorschrift");
        var doctor = await t.LoggedInAs(Env.Huisarts);
        var mark = Env.LogLineCount();
        t.Step("Arts legt een voorschrift vast");
        await doctor.PrescribeAsync(new PrescriptionInput { PatientId = patient.Id.ToString() },
            new MedicineLine(await Env.MedicineIdAsync(t.Data.Medicijn("pijnstiller")), 10, "1 tablet per dag"));
        var admin = await t.LoggedInAs(Env.Beheerder);
        var lines = await NewLogLinesViaScreen(t, admin, mark);
        CheckLine(t, lines, $"was created for {patient.Id}", Env.Huisarts.Id, "Voorschrift");
    });

    [Fact, Testcase("TC-26.1-04", "AC-26.1", "Verwijderen van een gebruiker staat in het log met gebruiker, actie en tijdstip",
        Scenario = "TS-26.2 Acties terugvinden in het log")]
    public Task TC_26_1_04() => Run(async t =>
    {
        var user = await t.NewPatient("log_verwijder");
        var admin = await t.LoggedInAs(Env.Beheerder);
        var mark = Env.LogLineCount();
        t.Step("Beheerder verwijdert een gebruiker");
        await admin.DeleteUserAsync(user.Id);
        var lines = await NewLogLinesViaScreen(t, admin, mark);
        CheckLine(t, lines, $"{user.Id} was deleted", Env.Beheerder.Id, "Verwijdering");
    });

    [Fact, Testcase("TC-26.1-05", "AC-26.1", "Logregel van een rolwijziging is eenduidig: oude en nieuwe rol staan er beide als naam in",
        Soort = Soort.Alternatief, Scenario = "TS-26.3 Leesbaarheid voor audits")]
    public Task TC_26_1_05() => Run(async t =>
    {
        var user = await t.NewPatient("log_leesbaar");
        var admin = await t.LoggedInAs(Env.Beheerder);
        var mark = Env.LogLineCount();
        await admin.ChangeRoleAsync(user.Id, "apothecary");
        var line = (await NewLogLinesViaScreen(t, admin, mark)).FirstOrDefault(l => l.Contains($"Role of {user.Id}")) ?? "";
        t.Check(line.Contains("from patient to apothecary"), "Oude en nieuwe rol als naam", "'... from patient to apothecary'", line);
    });

    [Fact, Testcase("TC-26.1-06", "AC-26.1", "Alleen de beheerder kan logbestanden openen",
        Soort = Soort.Negatief, Scenario = "TS-26.4 Onbevoegde gebruiker")]
    public Task TC_26_1_06() => Run(async t =>
    {
        var open = new List<string>();
        var anon = t.Session("anoniem");
        foreach (var (name, session) in new (string, MmaClient)[]
                 {
                     ("anoniem", anon),
                     ("huisarts", await t.LoggedInAs(Env.Huisarts)),
                     ("apotheker", await t.LoggedInAs(Env.Apotheker)),
                     ("zorgverzekeraar", await t.LoggedInAs(Env.Verzekeraar))
                 })
        {
            t.Step($"{name}: logbestanden openen");
            var list = await session.GetAsync("/LogFiles");
            var view = await session.GetAsync($"/LogFiles?handler=View&fileName={Env.TodaysLogFileName}");
            t.Info($"{name}: lijst {list.Describe()}, inhoud {view.Describe()}");
            if (list.StatusCode == 200 || view.StatusCode == 200) open.Add(name);
        }
        t.Check(open.Count == 0, "Logbestanden afgeschermd voor niet-beheerders", "geen toegang",
            open.Count == 0 ? "geen toegang" : "toegang voor: " + string.Join(", ", open));
    });

    [Fact, Testcase("TC-26.2-01", "AC-26.2", "Het scherm biedt geen mogelijkheid om logregels te wijzigen of te verwijderen",
        Scenario = "TS-26.5 Logregels zijn alleen-lezen")]
    public Task TC_26_2_01() => Run(async t =>
    {
        var admin = await t.LoggedInAs(Env.Beheerder);
        var page = await admin.GetAsync("/LogFiles");
        var textarea = page.Q("#logContent");
        t.Check(textarea?.HasAttribute("readonly") == true, "Weergave van het log", "alleen-lezen (readonly)", textarea?.HasAttribute("readonly") == true ? "readonly" : "bewerkbaar");
        var forms = page.QA("main form").Count();
        var buttons = page.QA("main button").Select(b => b.Id ?? b.TextContent.Trim()).ToList();
        t.Info("Knoppen: " + string.Join(", ", buttons));
        t.Check(forms == 0, "Formulieren om op te slaan of te verwijderen", "geen", forms.ToString());
        t.Check(buttons.All(b => b == "downloadBtn"), "Alleen een downloadknop", "downloadBtn", string.Join(", ", buttons));
    });

    [Fact, Testcase("TC-26.2-02", "AC-26.2", "Pogingen om het logbestand via de server te wijzigen of te verwijderen hebben geen effect",
        Soort = Soort.Negatief, Scenario = "TS-26.5 Logregels zijn alleen-lezen")]
    public Task TC_26_2_02() => Run(async t =>
    {
        var admin = await t.LoggedInAs(Env.Beheerder);
        var before = Env.ReadLogLines();
        var token = (await admin.GetAsync("/LogFiles")).AntiforgeryToken;
        var file = Env.TodaysLogFileName;

        t.Step("POST, PUT en DELETE naar het scherm logbestanden");
        await admin.PostRawAsync($"/LogFiles?handler=Delete&fileName={file}", new Dictionary<string, string> { ["fileName"] = file }, token);
        await admin.PostRawAsync($"/LogFiles?handler=Save&fileName={file}", new Dictionary<string, string> { ["content"] = "gewist" }, token);
        await admin.SendAsync(HttpMethod.Put, $"/LogFiles?fileName={file}");
        await admin.SendAsync(HttpMethod.Delete, $"/LogFiles?handler=View&fileName={file}");

        var after = Env.ReadLogLines();
        var unchanged = after.Length >= before.Length && before.SequenceEqual(after.Take(before.Length));
        t.Check(File.Exists(Env.TodaysLogFilePath), "Logbestand bestaat nog", "aanwezig", File.Exists(Env.TodaysLogFilePath) ? "aanwezig" : "verwijderd");
        t.Check(unchanged, "Bestaande logregels ongewijzigd", $"{before.Length} regels ongewijzigd", unchanged ? "ongewijzigd" : $"gewijzigd ({after.Length} regels)");
    });

    [Fact, Testcase("EXT-26-01", ReportWriter.Extra, "Via het scherm logbestanden zijn willekeurige bestanden van de server te lezen (path traversal)",
        Story = 26, Soort = Soort.Negatief, Scenario = "Aanvullend: beveiliging van de bestandsweergave")]
    public Task EXT_26_01() => Run(async t =>
    {
        var anon = t.Session("anoniem");
        t.Step("Anoniem: bestandsnaam met ..\\ naar het configuratiebestand van de applicatie");
        var leaked = new List<string>();
        foreach (var path in new[] { "../appsettings.json", "../testsettings.json", "../../../../MMA.Tests.csproj" })
        {
            var page = await anon.GetAsync($"/LogFiles?handler=View&fileName={Uri.EscapeDataString(path)}");
            if (page.StatusCode == 200 && page.Body.Length > 0)
            {
                leaked.Add(path);
                t.Info($"Inhoud van {path} (eerste regel): {page.Body.Split('\n')[0].Trim()} ... ({page.Body.Length} tekens)");
            }
        }
        t.Check(leaked.Count == 0, "Bestanden buiten de logmap leesbaar", "nee (alleen logbestanden)",
            leaked.Count == 0 ? "nee" : "ja: " + string.Join(", ", leaked));
    });

    [Fact, Testcase("EXT-26-02", ReportWriter.Extra, "Inloggen (gelukt en mislukt) wordt niet gelogd",
        Story = 26, Soort = Soort.Observatie, Scenario = "Verkennend: volledigheid van de audittrail")]
    public Task EXT_26_02() => Run(async t =>
    {
        var patient = await t.NewPatient("log_inlog");
        var mark = Env.LogLineCount();
        await t.Session("fout").LoginAsync(patient.Username, "fout");
        await t.LoggedInAs(patient);
        var lines = Env.ReadLogLines().Skip(mark).ToList();
        t.Observe(lines.Count == 0
            ? "Een mislukte en een gelukte inlogpoging leveren geen enkele logregel op."
            : "Inlogpogingen gelogd: " + string.Join(" | ", lines));
        t.Observe("Logregels bevatten alleen het UserID, geen gebruikersnaam of rol; de datum staat alleen in de bestandsnaam.");
    });

    [Fact, Testcase("EXT-26-03", ReportWriter.Extra, "Registreren van een nieuwe patiënt wordt gelogd",
        Story = 26, Soort = Soort.Observatie, Scenario = "Verkennend: volledigheid van de audittrail")]
    public Task EXT_26_03() => Run(async t =>
    {
        var mark = Env.LogLineCount();
        var anon = t.Session("anoniem");
        var name = "registratie_" + Guid.NewGuid().ToString("N")[..6];
        var result = await anon.PostFormAsync("/Account/Register", new Dictionary<string, string>
        {
            ["Username"] = name, ["Email"] = name + "@test.local", ["Password"] = "Patient#01",
            ["Country"] = "Netherlands", ["PhoneNumber"] = "0612345678"
        });
        var id = await Env.WithDbAsync(db => Task.FromResult(db.Users.Where(u => u.Username == name).Select(u => (int?)u.UserID).FirstOrDefault()));
        var lines = Env.ReadLogLines().Skip(mark).ToList();
        t.Observe($"Registratie: {result.Describe()}, gebruiker id {id?.ToString() ?? "niet aangemaakt"} met rol {(id == null ? "-" : (await Env.RoleOfAsync(id.Value))?.ToString())}. " +
                  "Logregels: " + (lines.Count == 0 ? "geen" : string.Join(" | ", lines)));
    });
}
